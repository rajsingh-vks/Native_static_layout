import {Dimensions, StyleSheet} from 'react-native';
import appStyles from './appStyles';
import appColors from './appColors';
const {width, height} = Dimensions.get('window');

const styles = StyleSheet.create({

  // Common

  // Common

  // Theme bg Colors

  // Theme bg Colors

  // OnBoarding
    OnboardingContainer: {
      flex: 1,
    },
    OnboardingContainerImage: {
      flex: 1, 
    },
    OnBoardingSlideContainer: {
      alignItems: 'center'
    },
    OnBoardingImage: {
        height: '75%', 
        width, 
        resizeMode: 'contain'
    },
    OnBoardingtitle: {
        color: appColors.white,
        fontSize: 24,
        fontWeight: 'bold',
        marginTop: 20,
        maxWidth: '90%',
        textAlign: 'center',
        lineHeight: 32,
    },
    OnBoardingsubtitle: {
        color: appColors.white,
        fontSize: 14,
        marginTop: 20,
        maxWidth: '90%',
        textAlign: 'center',
        lineHeight: 20,
    },
    indicator: {
        height: 2.5,
        width: 10,
        backgroundColor: 'grey',
        marginHorizontal: 3,
        borderRadius: 2,
    },
    OnBoardingfooter: {
        height: height * 0.15,
        justifyContent: 'space-between',
        paddingHorizontal: 20,
    },
    IndicatorWrapper: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginTop: 20,
    },
    OnBoardingbtn: {
      flex: 1,
      height: 50,
      borderRadius: 5,
      backgroundColor: '#fff',
      justifyContent: 'center',
      alignItems: 'center',
    },
    OnBoardingbtntext: {
      fontWeight: 'bold', 
      fontSize: 15
    },
  // OnBoarding

  // Login
    authContainer: {
      flex: 1,
      padding: 15,
      backgroundColor: appColors.white
    },
    authImageWrapper: {
      height: '35%', 
      alignItems: 'center'
    },
    authImage: {
      height: '100%',
      resizeMode: 'contain'
    },
    auth: {
      marginTop: 20
    },
    authTitle: {
      fontSize: 24,
      fontWeight: 'bold',
      lineHeight: 32,
      color: appColors.themeBlueText
    },
    authsubtitle: {
        fontSize: 14,
        marginTop: 10,
    },
    radioWrapper: {
      flexDirection: 'row',
      alignItems: 'center',
      flex: 1,
      marginVertical: 10
    },
    radio: {
      height: 20,
      width: 20,
      borderColor: appColors.dark100,
      borderWidth: 2,
      borderRadius: 20,
      margin: 10
    },
    radioBg: {
      backgroundColor: appColors.themeBlueText,
      height: 10,
      width: 10,
      borderRadius: 30,
      margin: 3,
    },
    label: {
      color: '#001a66',
      fontSize: 16,
      fontWeight: 'bold',
      color: appColors.themeBlueText,
      textAlign: 'left',
      marginVertical: 5
    },
    inputwrapper: {
      height: 50,
      borderColor: appColors.gray,
      borderWidth: 1,
      borderRadius: 6,
    },
    inputArea: {
      flex: 1,
      borderColor: appColors.dark700,
      paddingHorizontal: 10,
      color: appColors.dark400,
    },
    Authbtn: {
      flex: 1,
      borderRadius: 6,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: appColors.themeBlueText,
    },
    Authbtntext: {
      color: appColors.white,
      fontWeight: 'bold', 
      fontSize: 16
    },

    authBottom: {
      flexDirection: 'row',
      alignItems: 'flex-end',
      justifyContent: 'center',
      marginVertical: '15'
    },
  // Login

  defaultBg: {
    backgroundColor: appColors.blueHeader
  },

  // DrawerLayout
  drawerLayout: {
    backgroundColor: appColors.white,
    position: 'relative'
  },
  drawerHeader: {
    borderBottomColor: appColors.gray,
    borderBottomWidth: 1,
    paddingBottom: 10
  },
  drawerClose: {
    position: 'absolute',
    right: 0,
    zIndex: 1
  },
  drawerNavigation: {
    paddingVertical: 15
  },
  navigation: {
    flexDirection: 'row',
    flex: 1
  },
  // DrawerLayout

  // Header
  header: {
    flexDirection: 'row',
    paddingHorizontal: 10,
    paddingVertical: 15
  },
  drawerTouch: {
    backgroundColor: '#2c3f83',
    width: 40,
    height: 40,
    borderRadius: 6,
  },
  drawerIcon: {
    fontSize: 25,
    color: appColors.white,
    margin: 'auto',
    textAlign: 'center'
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: 15,
  },
  headerTitle: {
    fontSize: 18,
    color: appColors.white,
    fontWeight: 'bold'
  },
  headerSubTitle: {
    fontSize: 12,
    color: appColors.gray
  },
  headerRight: {
    flexDirection: 'row'
  },
  // Header

  // Dashboard

  dashboard: {
    flex: 1,
    backgroundColor: appColors.grayScreen,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    paddingHorizontal: 5,
    paddingVertical: 15
  },
  dashboardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginHorizontal: 10,
  },
  dashboardSubTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginHorizontal: 10,
    marginTop: 15,
    marginBottom: 5
  },
  cardWrapper: {
    flexDirection: 'row'
  },
  cardFirst: {
     borderRadius: 10,
  },
  card: {
     flex: 1,
     margin: 10,
     borderRadius: 10,
     backgroundColor: appColors.red,
     height: 110,
     padding: 15,
     position: 'relative'
  },
  iconCircle: {
    backgroundColor: appColors.white,
    borderRadius: '50%',
    width: 50,
    height: 50
  },
  iconCard: {
    textAlign: 'center',
    flex: 1,
    verticalAlign: 'middle',
  },
  cardTitle: {
    fontWeight: 'bold', 
    fontSize: 16,
    marginTop: 10
  },
  absoluteLine: {
    position: 'absolute',
    right: '0%',
    top: '15',
    justifyContent: 'center',
    width: 8,
    height: '100%',
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10
  },
  subCard: {
    flexDirection: 'row',
    height: 'auto'
  },
  subCartTitle: {
    marginLeft: 20,
    fontSize: 20
  },
  adminCardWrapper: {
    backgroundColor: appColors.white,
    borderRadius: 10,
    margin: 10,
    // padding: 15
  },
  notification: {
    flexDirection: 'row',
    padding: 15
  },
  notificationBanner: {
    marginTop: 15,
    height: 200,
    width: '100%'
  }
});

export default styles;
