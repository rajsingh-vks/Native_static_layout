const appColors = {
  // Theme colors
  themeColor: '#359c71',
  themeColorBg: '#f0fff4',
  themeColor600: 'rgba(53, 156, 113, 0.6)',
  themeColor300: 'rgba(53, 156, 113, 0.3)',
  themeColor200: 'rgba(53, 156, 113, 0.2)',
  themeColor100: 'rgba(53, 156, 113, 0.1)',
  themeColor50: 'rgba(161, 222, 248, 0.1)',
  themeBlueText: '#001a66',
  // Ripple bg color
  rippleBgColor: 'rgba(53, 156, 113, 0.2)',

  // Light colors
  light: '#FFFFFF',
  grayScreen: '#f5f6f1',

  // Black colors
  dark100: '#000000',
  dark200: '#171717',
  dark300: '#2E2E2E',
  dark400: '#454545',
  dark500: '#5C5C5C',
  dark600: '#737373',
  dark700: '#8A8A8A',

  white: '#fff',
  info: '#00FFFF',
  green: '#359c71',
  yellow: '#e5a300',
  red: '#cf4236',
  blue: '#3e8ecb',
  gray: '#A6A8A9',
  placeholderColor: '#CDCDCD',
  borderColor: '#ccc',

  blueHeader: '#081d6e'
};

export default appColors;
