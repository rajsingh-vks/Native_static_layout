import * as React from 'react';
import { View, Text } from 'react-native';
import { Button } from '@react-navigation/elements';
import { useNavigation } from '@react-navigation/native';
import Onboarding from 'react-native-onboarding-swiper';


function OnboardingScreen () {
  const navigation = useNavigation();
    return (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Onboarding
                pages={[
                    {
                    backgroundColor: '#fff',
                    image: (
                        <View>
                            <Text>Testing</Text>
                        </View>
                    ),
                    title: 'Onboarding',
                    subtitle: 'Done with React Native Onboarding Swiper',
                    },
                    {
                    backgroundColor: '#fff',
                    image: (
                        <View>
                            <Text>Testing</Text>
                        </View>
                    ),
                    title: 'Onboarding2',
                    subtitle: 'Done with React Native Onboarding Swiper',
                    },
                ]}
                type={'fullscreen'}

            />
        </View>
    )
}

export default OnboardingScreen;