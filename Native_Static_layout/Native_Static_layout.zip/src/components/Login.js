import * as React from 'react';
import { View, Text, Image, TextInput, TouchableOpacity } from 'react-native';
import styles from '../utils/styles';

import { useNavigation } from '@react-navigation/native';
import { Label } from '@react-navigation/elements';


function Login() {
    const navigation = useNavigation();
    const [selectedRadio, setSelectedRadio] = React.useState(1)
    const [passVisible, setPassVisible] = React.useState(false);

    const [activeTab, setActiveTab] = React.useState('phone');

    const handleTabChange = (tab) => {
        setActiveTab(tab);
    };

    return (
        <View style={styles.authContainer}>
            <View style={styles.authImageWrapper}>
                <Image
                    source={require('../assets/images/ic_login.png')}
                    style={styles.authImage}
                />
            </View>
            <View style={styles.auth}>
                <Text style={styles.authTitle}>Welcome</Text>
                <Text style={styles.authsubtitle}>Sign in to continue</Text>

                <View style={{ flexDirection: 'row' }}>
                    <TouchableOpacity onPress={() => [handleTabChange('phone'), setSelectedRadio(1)]} style={styles.radioWrapper}>
                        <View style={styles.radio}>
                            {
                                selectedRadio === 1 ? <View style={styles.radioBg}></View> : null
                            }
                        </View>
                        <Text>With Phone Number</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => [handleTabChange('email'), setSelectedRadio(2)]} style={styles.radioWrapper}>
                        <View style={styles.radio}>
                            {
                                selectedRadio === 2 ? <View style={styles.radioBg}></View> : null
                            }
                        </View>
                        <Text>With Email</Text>
                    </TouchableOpacity>
                </View>

                {activeTab === 'phone' ? (
                    <View>
                     <View>
                         <Label style={styles.label}>Phone Number</Label>
                         <View style={[styles.inputwrapper, { marginBottom: 10 }]}>
                             <TextInput
                                 placeholder="Enter your phone number"
                                 placeholderTextColor="#CDCDCD"
                                 style={styles.inputArea}
                                 autoCapitalize="none"
                             />
                         </View>
                     </View>
                    </View>
                ) : (
                    <View>
                        <View>
                            <Label style={styles.label}>Email</Label>
                            <View style={[styles.inputwrapper, { marginBottom: 10 }]}>
                                <TextInput
                                    placeholder="Enter your email"
                                    placeholderTextColor="#CDCDCD"
                                    style={styles.inputArea}
                                    autoCapitalize="none"
                                />
                            </View>
                        </View>
                    </View>
                )}

                <View>
                    <Label style={styles.label}>Password</Label>
                    <View style={styles.inputwrapper}>
                        <TextInput
                            placeholder="Enter your password"
                            placeholderTextColor="#CDCDCD"
                            secureTextEntry={!passVisible}
                            style={styles.inputArea}
                        />
                    </View>
                </View>
                <View style={{ flexDirection: 'row', marginTop: 0, marginBottom: 10 }}>
                    <TouchableOpacity style={styles.radioWrapper}>
                        <Text style={[styles.label]}>Remember me</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={{ justifyContent: 'center' }} onPress={() => navigation.navigate('Forgot')}>
                        <Text style={[styles.label]}>Forgot Password</Text>
                    </TouchableOpacity>
                </View>
                <View style={{ height: 50 }}>
                    <TouchableOpacity
                        style={styles.Authbtn}
                        onPress={() => navigation.navigate('Tab')}>
                        <Text style={styles.Authbtntext}>
                            LOGIN
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.authBottom}>
                    <Text>Don't have an account</Text> 
                    <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
                      <Text style={{ fontWeight: 'bold', color: '#001a66' }}> Sign up</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    );
}

export default Login