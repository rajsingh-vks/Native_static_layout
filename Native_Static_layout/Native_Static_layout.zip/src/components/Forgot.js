import * as React from 'react';
import { View, Text } from 'react-native';
import styles from '../utils/styles';


import { useNavigation } from '@react-navigation/native';
import { Button, Label } from '@react-navigation/elements';

function Forgot() {
    const navigation = useNavigation();


    return (
        <View style={styles.LoginContainer}>
            <Text>Forgot</Text>
            <Button onPress={() => navigation.navigate('Login')}>Back to Login Page</Button>
        </View>
    );
}

export default Forgot