import * as React from 'react';
import { View, Text, TouchableOpacity, Image, ScrollView } from 'react-native';

import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from '../../utils/styles';

function Header() {
    const navigation = useNavigation();

    return (
        <View style={styles.header}>
            <TouchableOpacity
                style={styles.drawerTouch}
                onPress={() => navigation.openDrawer()}>
                <Icon
                    name='currency-eth'
                    style={styles.drawerIcon} />
            </TouchableOpacity>
            <View style={styles.headerContent}>
                <Text style={styles.headerSubTitle}>Good Morning</Text>
                <Text style={styles.headerTitle}>Yashwant Kumar</Text>
            </View>
            <View style={styles.headerRight}>
                <Icon
                    name='bell-badge-outline'
                    style={[styles.drawerIcon, { marginRight: 10 }]} />
                <TouchableOpacity
                    style={styles.drawerTouch}>
                    <Icon
                        name='account'
                        style={styles.drawerIcon} />
                </TouchableOpacity>
            </View>
        </View>
    );
}

export default Header