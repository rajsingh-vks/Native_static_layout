import * as React from 'react';
import { View, Text, TouchableOpacity, Image, ScrollView } from 'react-native';

import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from '../../utils/styles';
import Header from '../Header';

function Dashboard() {
    const navigation = useNavigation();

    return (
        <ScrollView style={styles.defaultBg}>
            <Header />
            <View style={styles.dashboard}>
                <Text style={styles.dashboardTitle}>Services</Text>
                <View style={styles.cardWrapper}>
                    <TouchableOpacity style={[styles.card, styles.cardFirst, { backgroundColor: '#ffe3e2' }]}>
                        <View style={styles.iconCircle}>
                            <Icon
                                name={'bus-clock'}
                                size={30}
                                style={[styles.iconCard, { color: '#f65052' }]}
                            />
                        </View>
                        <Text style={styles.cardTitle}>Dispatch</Text>
                        <View style={[styles.absoluteLine, { backgroundColor: '#ff5052' }]}></View>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.card, { backgroundColor: '#fdefcc' }]}>
                        <View style={styles.iconCircle}>
                            <Icon
                                name={'bus-double-decker'}
                                size={30}
                                style={[styles.iconCard, { color: '#fcb82f' }]}
                            />
                        </View>
                        <Text style={styles.cardTitle}>Vehicle Patrol</Text>
                        <View style={[styles.absoluteLine, { backgroundColor: '#fcbd24' }]}></View>
                    </TouchableOpacity>
                </View>
                <View style={styles.cardWrapper}>
                    <TouchableOpacity style={[styles.card, { backgroundColor: '#e4ebfe' }]}>
                        <View style={styles.iconCircle}>
                            <Icon
                                name={'file-document-outline'}
                                size={30}
                                style={[styles.iconCard, { color: '#346dfa' }]}
                            />
                        </View>
                        <Text style={styles.cardTitle}>Docs & Policies</Text>
                        <View style={[styles.absoluteLine, { backgroundColor: '#275ffc' }]}></View>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.card, { backgroundColor: '#c7eedc' }]}>
                        <View style={styles.iconCircle}>
                            <Icon
                                name={'calendar-clock'}
                                size={30}
                                style={[styles.iconCard, { color: '#00cb83' }]}
                            />
                        </View>
                        <Text style={styles.cardTitle}>Schedule</Text>
                        <View style={[styles.absoluteLine, { backgroundColor: '#02cc83' }]}></View>
                    </TouchableOpacity>
                </View>
                <View style={styles.cardWrapper}>
                    <TouchableOpacity style={[styles.card, styles.subCard, { backgroundColor: '#e1bee8' }]}>
                        <View style={styles.iconCircle}>
                            <Icon
                                name={'clock-outline'}
                                size={30}
                                style={[styles.iconCard, { color: '#1554f1' }]}
                            />
                        </View>
                        <Text style={[styles.cardTitle, styles.subCartTitle]}>Time Clock</Text>
                        <View style={[styles.absoluteLine, { backgroundColor: '#46158a' }]}></View>
                    </TouchableOpacity>
                </View>
                <Text style={styles.dashboardSubTitle}>Admin Notification</Text>
                <View style={styles.adminCardWrapper}>
                    <TouchableOpacity style={styles.notification}>
                        <View style={[styles.iconCircle, { backgroundColor: '#e2eaff' }]}>
                            <Icon
                                name={'account-cog'}
                                size={30}
                                style={[styles.iconCard, { color: '#1d61f4' }]}
                            />
                        </View>
                        <View>
                            <Text style={[styles.cardTitle, styles.subCartTitle, { marginTop: 0 }]}>National Utilities</Text>
                            <Text style={{ marginLeft: 20 }}>Posted 1hr ago</Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.notification}>
                        <View style={[styles.iconCircle, { backgroundColor: '#e2eaff' }]}>
                            <Icon
                                name={'account-cog'}
                                size={30}
                                style={[styles.iconCard, { color: '#1d61f4' }]}
                            />
                        </View>
                        <View>
                            <Text style={[styles.cardTitle, styles.subCartTitle, { marginTop: 0 }]}>National Utilities</Text>
                            <Text style={{ marginLeft: 20 }}>Posted 1hr ago</Text>
                        </View>
                    </TouchableOpacity>
                    <View style={{ backgroundColor: '#e1e1e1', height: 1 }}></View>
                    <Image
                        source={require('../../assets/images/ic_officer.png')}
                        style={styles.notificationBanner}
                    />
                </View>
            </View>
        </ScrollView>
    );
}

export default Dashboard