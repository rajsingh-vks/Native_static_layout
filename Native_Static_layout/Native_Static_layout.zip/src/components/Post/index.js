import * as React from 'react';
import { View, Text } from 'react-native';

import { useNavigation } from '@react-navigation/native';
import { Button } from '@react-navigation/elements';

function Post() {
    const navigation = useNavigation();

    return (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Text>Post Screen</Text>
            <Button onPress={() => navigation.navigate('Login')}>
                Go to Details
            </Button>
        </View>
    );
}

export default Post