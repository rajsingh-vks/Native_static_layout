import * as React from 'react';
import { View, Text, Image, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import styles from '../utils/styles';

import { useNavigation } from '@react-navigation/native';
import { Label } from '@react-navigation/elements';

function SignUp() {
    const navigation = useNavigation();
    const [passVisible, setPassVisible] = React.useState(false);


    return (
        <View style={styles.authContainer}>
            <ScrollView>
            <View style={[styles.authImageWrapper, {height: '28%'}]}>
                <Image
                    source={require('../assets/images/ic_login.png')}
                    style={styles.authImage}
                />
            </View>
            <View style={styles.auth}>
                <Text style={styles.authTitle}>Welcome</Text>
                <Text style={styles.authsubtitle}>Sign up to continue</Text>

                <View style={{ marginTop: 15 }}>
                    <Label style={styles.label}>UserName</Label>
                    <View style={[styles.inputwrapper, { marginBottom: 10 }]}>
                        <TextInput
                            placeholder="Enter your UserName"
                            placeholderTextColor="#CDCDCD"
                            style={styles.inputArea}
                            autoCapitalize="none"
                        />
                    </View>
                </View>
                <View>
                    <Label style={styles.label}>Email</Label>
                    <View style={[styles.inputwrapper, { marginBottom: 10 }]}>
                        <TextInput
                            placeholder="Enter your email"
                            placeholderTextColor="#CDCDCD"
                            style={styles.inputArea}
                            autoCapitalize="none"
                        />
                    </View>
                </View>
                <View>
                    <Label style={styles.label}>Phone Number</Label>
                    <View style={[styles.inputwrapper, { marginBottom: 10 }]}>
                        <TextInput
                            placeholder="Enter your phone number"
                            placeholderTextColor="#CDCDCD"
                            style={styles.inputArea}
                            autoCapitalize="none"
                        />
                    </View>
                </View>
                <View>
                    <Label style={styles.label}>Password</Label>
                    <View style={styles.inputwrapper}>
                        <TextInput
                            placeholder="Enter your password"
                            placeholderTextColor="#CDCDCD"
                            secureTextEntry={!passVisible}
                            style={styles.inputArea}
                        />
                    </View>
                </View>
                <View style={{ height: 50, marginTop: 25 }}>
                    <TouchableOpacity
                        style={styles.Authbtn}
                        onPress={() => navigation.replace('Tab')}>
                        <Text style={styles.Authbtntext}>
                            SIGN UP
                        </Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.authBottom}>
                    <Text>Already have an account?</Text> 
                    <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                    <Text style={{ fontWeight: 'bold', color: '#001a66' }}> Sign in</Text>
                    </TouchableOpacity>
                </View>
            </View>
            </ScrollView>
        </View>
    );
}

export default SignUp