export default {
    HOME: 'Home',
    FEED: 'Feed',
    PROFILE: 'Profile',
    POST: 'Post'
}