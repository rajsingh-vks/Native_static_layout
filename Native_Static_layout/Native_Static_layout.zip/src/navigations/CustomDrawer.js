import * as React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import {
    DrawerContentScrollView,
    DrawerItem,
    DrawerItemList,
} from '@react-navigation/drawer';
import NavigationString from './NavigationString';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import styles from '../utils/styles';

function CustomDrawer(props) {
    const { navigation } = props
    const moveToScreen = (screen) => {
        navigation.navigate(screen)
    }
    return (
        <DrawerContentScrollView style={styles.drawerLayout} {...props}>
            <View style={styles.drawerHeader}>
                <TouchableOpacity
                    style={styles.drawerClose}
                    onPress={() => navigation.closeDrawer()}>
                        <Icon
                            name={'close'}
                            size={24} />
                </TouchableOpacity>
                
                <View>
                    <Icon
                        name={'account'}
                        size={44} />
                    <Text style={{ fontWeight: '600' }}>User Name</Text>
                </View>
            </View>

            {/* <DrawerItemList {...props} /> */}

            <View style={styles.drawerNavigation}>
                <TouchableOpacity style={styles.navigation} onPress={() => navigation.navigate('Dashboard')}>
                    <Icon
                        name={'home'}
                        size={24} />
                    <Text>Home</Text>
                </TouchableOpacity>
            </View>

            {/* <DrawerItem
                label="Home"
                onPress={() => navigation.navigate(NavigationString.HOME)}
                icon={() => <Icon
                    name={'home'}
                    size={24}
                    style={[{ color: 'white' }]} />}
                labelStyle={{ color: 'white', fontWeight: '200' }}
            />
            <DrawerItem
                label="Profile"
                onPress={() => navigation.navigate(NavigationString.PROFILE)}
            />
            <DrawerItem
                label="Post"
                onPress={() => navigation.navigate(NavigationString.POST)}
            /> */}
        </DrawerContentScrollView>
    );
}

export default CustomDrawer