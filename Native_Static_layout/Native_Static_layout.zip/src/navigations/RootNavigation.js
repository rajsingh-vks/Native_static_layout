import * as React from 'react';
// import { createNativeStackNavigator } from '@react-navigation/native-stack';
import OnboardingScreen from '../onboarding';
import Login from '../components/Login';
import Forgot from '../components/Forgot';
import SignUp from '../components/SignUp';
import { createDrawerNavigator } from '@react-navigation/drawer';
import DrawerNavigation from './DrawerNavigation';

// const Stack = createNativeStackNavigator();

const Drawer = createDrawerNavigator();

function RootStack() {
  return (
    <>
      {/* <Stack.Navigator initialRouteName='Onboarding' screenOptions={{headerShown: false}}>
          <Stack.Screen name="Onboarding" component={OnboardingScreen} />
          <Stack.Screen name="Login" component={Login} />
          <Stack.Screen name="Forgot" component={Forgot} />
          <Stack.Screen name="SignUp" component={SignUp} />
          <Stack.Screen name="Tab" component={TabNavigation} />
          <Stack.Screen name="Dashboard" component={Dashboard} />
      </Stack.Navigator> */}

      <Drawer.Navigator 
          initialRouteName='Onboarding' 
          screenOptions={{headerShown: false}}
          >
          <Drawer.Screen name="Onboarding" component={OnboardingScreen} />
          <Drawer.Screen name="Login" component={Login} />
          <Drawer.Screen name="Forgot" component={Forgot} />
          <Drawer.Screen name="SignUp" component={SignUp} />
          <Drawer.Screen name="Tab" component={DrawerNavigation} />
      </Drawer.Navigator>
    </>
  );
}

export default RootStack;