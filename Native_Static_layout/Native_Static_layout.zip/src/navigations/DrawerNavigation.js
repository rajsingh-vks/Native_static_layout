import { createDrawerNavigator } from '@react-navigation/drawer';
import Dashboard from '../components/Dashboard';
import Account from '../components/Account';
import TabNavigation from './TabNavigation';
import CustomDrawer from './CustomDrawer';

const Drawer = createDrawerNavigator();

function DrawerNavigation() {
  return (
    <Drawer.Navigator drawerContent={(props) => <CustomDrawer {...props} />} screenOptions={{headerShown: false}}>
      <Drawer.Screen name="Dashboard" component={TabNavigation} />
      <Drawer.Screen name="Profile" component={Account} />
    </Drawer.Navigator>
  );
}

export default DrawerNavigation