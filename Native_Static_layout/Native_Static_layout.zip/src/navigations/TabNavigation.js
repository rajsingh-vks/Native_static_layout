import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Dashboard from '../components/Dashboard';
import Account from '../components/Account';
import Post from '../components/Post';
import Activity from '../components/Activity';
import Message from '../components/Message';
import Icon from 'react-native-vector-icons/Ionicons';

const Tab = createBottomTabNavigator();

function TabNavigation() {
    return (
        <Tab.Navigator 
          initialRouteName='Feed' 
          screenOptions={{ 
            headerShown: false,
            tabBarActiveTintColor: 'black',
            tabBarInactiveBackgroundColor: 'blue',
            tabBarInactiveTintColor: 'white'
        }}>
            <Tab.Screen name="Feed" component={Dashboard} 
            options={{ tabBarIcon: ({focused}) => {
                return(
                    <Icon
                        name={'home-outline'}
                        size={18}
                        color={focused ? 'Black' : 'white'}
                    />
                )
            } }} />
            <Tab.Screen name="Post Site" component={Post}
            options={{ tabBarIcon: ({focused}) => {
                return(
                    <Icon
                        name={'albums-outline'}
                        size={18}
                        color={focused ? 'Black' : 'white'}
                    />
                )
            } }} />
            <Tab.Screen name="Activity" component={Activity}
            options={{ tabBarIcon: ({focused}) => {
                return(
                    <Icon
                        name={'timer-outline'}
                        size={18}
                        color={focused ? 'Black' : 'white'}
                    />
                )
            } }} />
            <Tab.Screen name="Message" component={Message}
            options={{ tabBarIcon: ({focused}) => {
                return(
                    <Icon
                        name={'chatbubbles-outline'}
                        size={18}
                        color={focused ? 'Black' : 'white'}
                    />
                )
            } }} />
            <Tab.Screen name="Setting" component={Account}
            options={{ tabBarIcon: ({focused}) => {
                return(
                    <Icon
                        name={'ellipsis-vertical'}
                        size={18}
                        color={focused ? 'Black' : 'white'}
                    />
                )
            } }} />
        </Tab.Navigator>
    );
}

export default TabNavigation;