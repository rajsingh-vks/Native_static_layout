import React, { useState, useEffect } from 'react';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';

import constants from '../utils/constants';
import routes from './routes';
import DrawerNavigation from './DrawerNavigation';
import LogoutListner from '../components/LogoutListner';

const Drawer = createDrawerNavigator();
const Stack = createNativeStackNavigator();

function RootStack() {
  // const navigation = useNavigation();
  const [initRoute, setInitroute] = useState('Onboarding');

  return (
    <>
      <NavigationContainer>
        <Stack.Navigator
          detachInactiveScreensx={true}
          initialRouteName={initRoute}
          screenOptions={{
            headerShown: false,
            // animation: 'slide_from_right',
          }}>
          {routes.map((route, index) => (
            <Stack.Screen
              name={route.name}
              component={route.component}
              key={`index-route-${index}`}
            />
          ))}
        </Stack.Navigator>
        <LogoutListner />
      </NavigationContainer>
    </>
  );
}

export default RootStack;