import { createDrawerNavigator } from '@react-navigation/drawer';
import CustomDrawer from './CustomDrawer';
import TabNavigation from './TabNavigation';
import Company from "../components/Company"
import JoinCompany from '../components/Company/JoinCompany';
import CompanyDetails from '../components/Company/CompanyDetails';
import ChangePassword from '../components/ChangePassword';
import Settings from '../components/Setting';
import Profile from '../components/Profile';
import UpdateProfile from '../components/Profile/UpdateProfile';
import Post from '../components/PostSites';
import PostDetails from '../components/PostSites/PostDetails';

const Drawer = createDrawerNavigator();

function DrawerNavigation() {
  return (
    <Drawer.Navigator 
      drawerContent={(props) => <CustomDrawer {...props} />} 
      screenOptions={{headerShown: false, drawerStyle:{width:'80%'}}}
      initialRouteName="dashboard">
        <Drawer.Screen name="dashboard" component={TabNavigation} />
        <Drawer.Screen name="company" component={Company} />
        {/* 
        <Drawer.Screen name="joinCompany" component={JoinCompany} />
        <Drawer.Screen name="companyDetails" component={CompanyDetails} />
        <Drawer.Screen name="changePassword" component={ChangePassword} /> 
        <Drawer.Screen name="profile" component={Profile} />
        <Drawer.Screen name="updateProfile" component={UpdateProfile} />
        <Drawer.Screen name="settings" component={Settings} />
        <Drawer.Screen name="postSite" component={Post} />
        <Drawer.Screen name="postDetails" component={PostDetails} />      */}
    </Drawer.Navigator>
  );
}

export default DrawerNavigation