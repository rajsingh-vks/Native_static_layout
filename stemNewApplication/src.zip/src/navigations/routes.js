import OnboardingScreen from '../onboarding';
import SignUp from '../components/SignUp';
import Login from '../components/Login';
import Forgot from '../components/Forgot';
import UserOTP from '../components/UserOTP';
import VerifyOTP from '../components/VerifyOTP';
import ResetPassword from '../components/ResetPassword';
import Success from '../components/Success';
import DrawerNavigation from './DrawerNavigation';
import Company from "../components/Company";
import CompanyDetails from '../components/Company/CompanyDetails';
import JoinCompany from '../components/Company/JoinCompany';
import Settings from '../components/Setting';
import Profile from '../components/Profile';
import UpdateProfile from '../components/Profile/UpdateProfile';
import ChangePassword from '../components/ChangePassword';
import PostSites from '../components/PostSites';
import PostSiteDetails from '../components/PostSites/PostDetails';
import Reminder from "../components/Reminder";
import ReminderDetails from '../components/Reminder/ReminderDetails';
import AddEditReminder from '../components/Reminder/AddEditReminder';
import TimeRequest from "../components/TimeRequest";
import AddEditTimeRequest from '../components/TimeRequest/AddEditTimeRequest';
import TimeRequestDetails from '../components/TimeRequest/TimeRequestDetails';
import Scheduler from '../components/Scheduler';
import Shifts from '../components/Scheduler/Shifts';
import ShiftDetails from '../components/Scheduler/ShiftDetails';
import Confirmed from '../components/Scheduler/Confirmed';
import PostOrders from "../components/PostOrders/index";
import PostOrderDetails from "../components/PostOrders/PostOrderDetails";
import CheckList from "../components/CheckList";
import CheckListDetails from "../components/CheckList/CheckListDetails";
import CheckListStatusMark from '../components/CheckList/CheckListStatusMark';
import Availability from "../components/Availability";
import ManageLicense from "../components/ManageLicense";
import LicenseDetails from "../components/ManageLicense/LicenseDetails";
import addEditLicense from '../components/ManageLicense/AddEditLicense';
import Tasks from '../components/Tasks';
import TaskDetails from '../components/Tasks/TaskDetails';
import SiteTours from "../components/SiteTours";
import SiteTourDetails from '../components/SiteTours/SiteTourDetails';
import Visitors from '../components/Visitors';
import VisitorDetails from '../components/Visitors/VisitorDetails';
import AddEditVisitor from '../components/Visitors/AddEditVisitor';
import ScanTag from "../components/ScanTag";
import ConfirmedShifts from '../components/ConfirmedShifts';
import { Component } from 'react';
import Reports from '../components/Reports';
import CheckInReport from "../components/Reports/CheckIn";
import CheckListsReport from "../components/Reports/CheckLists";
import TasksReport from "../components/Reports/Tasks";
import SiteToursReport from "../components/Reports/SiteTours";
import ShiftsDetails from '../components/ShiftsDetails';
import ShiftsExchange from '../components/ShiftExchange';
import ShiftsExchangeRequest from '../components/ShiftExchangeRequest';
import ExchangeShift from '../components/ExchangeShift';
import SelectGuard from '../components/SelectGuard';
import Chat from '../components/Chat';
import Notification from '../components/Notification';
import AboutUs from '../components/AboutUs';
import ContactUs from '../components/ContactUs';


const routes = [
  {
    name: 'Onboarding',
    component: OnboardingScreen,
  },
  {
    name: 'Login',
    component: Login,
  },
  {
    name: 'SignUp',
    component: SignUp,
  },
  {
    name: 'Forgot',
    component: Forgot,
  },
  {
    name: 'UserOTP',
    component: UserOTP,
  },
  {
    name: 'VerifyOTP',
    component: VerifyOTP,
  },
  {
    name: 'ResetPassword',
    component: ResetPassword,
  },
  {
    name: 'Success',
    component: Success,
  },
  {
    name: 'DrawerNavigation',
    component: DrawerNavigation,
  },
  {
    name: 'company',
    component: Company,
  },
  {
    name: 'joinCompany',
    component: JoinCompany,
  },
  {
    name: 'companyDetails',
    component: CompanyDetails,
  },
  {
    name: 'settings',
    component: Settings,
  },
  {
    name: 'profile',
    component: Profile,
  },
  {
    name: 'updateProfile',
    component: UpdateProfile,
  },
  {
    name: 'changePassword',
    component: ChangePassword,
  },
  {
    name: 'postSites',
    component: PostSites,
  },
  {
    name: 'postDetails',
    component: PostSiteDetails,
  },
  {
    name: 'reminders',
    component: Reminder,
  },
  {
    name: 'addReminder',
    component: AddEditReminder,
  },
  {
    name: 'reminderDetails',
    component: ReminderDetails,
  },
  {
    name: 'updateReminder',
    component: AddEditReminder, 
  },
  {
    name: 'timeRequests',
    component: TimeRequest,
  },
  {
    name: 'addTimeRequest',
    component: AddEditTimeRequest,
  },
  {
    name: 'TimeRequestDetails',
    component: TimeRequestDetails,
  },
  {
    name: 'updateTimeRequest',
    component: AddEditTimeRequest,
  },
  {
    name: 'scheduler',
    component: Scheduler,
  },
  {
    name: 'shifts',
    component: Shifts,
  },
  {
    name: 'shiftDetails',
    component: ShiftDetails,
  },
  {
    name: 'confirmed',
    component: Confirmed,
  },
  {
    name: 'postOrders',
    component: PostOrders,
  },
  {
    name: 'postOrderDetails',
    component: PostOrderDetails,
  },
  {
    name:'checkList',
    component:CheckList,
  },
  {
    name:'checkListDetails',
    component:CheckListDetails,
  },
  {
    name:'checkListStatusMarker',
    component:CheckListStatusMark,
  },
  {
    name:'availability',
    component:Availability,
  },
  {
    name:'addEditLicense',
    component:addEditLicense,
  },
  {
    name:'manageLicense',
    component:ManageLicense,
  },
  {
    name:'licenseDetails',
    component:LicenseDetails,
  },
  {
    name:'tasks',
    component:Tasks,
  },
  {
    name:'taskDetails',
    component:TaskDetails,
  },
  {
    name:'siteTours',
    component:SiteTours,
  },
  {
    name:'siteToursDetails',
    component:SiteTourDetails,
  },
  {
    name:'visitors',
    component:Visitors
  },
  {
    name:'visitorDetails',
    component:VisitorDetails
  },{
    name:'addEditVisitor',
    component:AddEditVisitor
  },
  {
    name:'scanTag',
    component:ScanTag
  },
  {
    name:'confirmedShifts',
    component:ConfirmedShifts
  },
  {
    name:'reports',
    component:Reports
  },
  {
    name:'check-in-out-report',
    component:CheckInReport
  },
  {
    name:'checklists-report',
    component:CheckListsReport
  },
  {
    name:'site-tours-report',
    component:SiteToursReport
  },
  {
    name:'tasks-report',
    component:TasksReport
  },
  {
    name:'shiftsDetails',
    component:ShiftsDetails
  },
  {
    name:'shiftsExchange',
    component:ShiftsExchange
  },
  {
    name:'shiftsExchangeRequest',
    component:ShiftsExchangeRequest
  },
  {
    name:'exchangeShift',
    component:ExchangeShift
  },
  {
    name:'selectguard',
    component:SelectGuard
  },
  {
    name:'chat',
    component:Chat
  },
  {
    name:'notification',
    component:Notification
  },
  {
    name:'aboutus',
    component:AboutUs
  },
  {
    name:'contactus',
    component:ContactUs
  }
];
  
export default routes;
  