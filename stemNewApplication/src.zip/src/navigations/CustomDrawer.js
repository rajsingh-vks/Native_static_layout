import { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import {
  DrawerContentScrollView,
} from '@react-navigation/drawer';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/MaterialIcons';
import { useDispatch, useSelector } from 'react-redux';

import SpaceBox from '../components/Common/SpaceBox';
import api from '../services/api';
import { logout } from '../services/logout';
import { showPopup } from '../utils/appHelpers';
import appColors from '../utils/appColors';
import styles from '../utils/styles';
import { getUser } from '../redux/userSlice';
import { setSpinner } from '../redux/appSlice';

function CustomDrawer(props) {
  const { navigation } = props
  const user = useSelector(getUser);
  const dispatch = useDispatch();

  const handleLogout = async () => {
    if (user?.token) {
      dispatch(setSpinner(true)); // Start loading
      let formData = new FormData();
      formData.append('id', user?.id);

      try {
        const res = await api.userLogout();
        if (res?.status === 200) {
          navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
          logout();
        } else {
          showPopup('error', 'Something went wrong.');
        }
      } catch (error) {
        showPopup('error', error?.data?.message || 'Failed to logout.');
      } finally {
        dispatch(setSpinner(false));
      }
    }
  };

  return (
    <DrawerContentScrollView style={styles.drawerLayout} {...props}>
      <View style={[styles.drawerHeader, { marginVertical: 10 }]}>
        <TouchableOpacity
          style={[styles.drawerClose, { borderColor: '#ccc', borderWidth: 1, borderRadius: 7, padding: 2 }]}
          onPress={() => navigation.closeDrawer()}>
          <Icon name={'chevron-left'} size={20} color={appColors.themeBlueText} />
        </TouchableOpacity>

        <View style={{ flexDirection: 'row' }}>
          <View style={{ flex: 1, borderRadius: '15%', backgroundColor: '#ddd', justifyContent: 'center', alignItems: 'center', }}>
            <Icon name={'account'} size={45} color={appColors.themeBlueText} />
          </View>
          <View style={{ flex: 3.5, paddingHorizontal: 10 }}>
            <Text style={{ color: appColors.themeBlueText, fontSize: 17, fontWeight: '600', marginVertical: 1 }}>{user?.full_name ?? "Guest"}</Text>
            <Text style={{ color: appColors.themeBlueText, fontWeight: '400', marginVertical: 1 }}>{user?.email ?? ""}</Text>
            <Text style={{ color: appColors.themeBlueText, fontWeight: '400', marginVertical: 1 }}>+{user?.country_code ?? ""} {user?.mobile_no ?? ""}</Text>
          </View>
        </View>
      </View>

      {/* <DrawerItemList {...props} /> */}

      <View style={styles.drawerNavigation}>
        <View style={istyles.drawerSection}>
          <Text style={[istyles.drawerSectionHeader]}>MANAGE</Text>

          {(user?.company_id != null && user?.company_id !== '') &&
            <>
              <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => { navigation.closeDrawer(); navigation.navigate('dashboard') }}>
                <Icon name={'home-variant-outline'} size={22} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
                <Text style={[istyles.drawerItemLabel]}>Home</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => { navigation.closeDrawer(); navigation.navigate('company'); }}>
                <Icon2 name={'work-outline'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
                <Text style={[istyles.drawerItemLabel]}>Select Company</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => { navigation.closeDrawer(); navigation.navigate('reminders') }}>
                <Icon2 name={'checklist'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
                <Text style={[istyles.drawerItemLabel]}>Reminders</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => navigation.navigate('timeRequests')}>
                <Icon2 name={'timer'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
                <Text style={[istyles.drawerItemLabel]}>Time Off Request</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => { navigation.closeDrawer(); navigation.navigate('scheduler') }}>
                <Icon2 name={'calendar-month'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
                <Text style={[istyles.drawerItemLabel]}>Scheduler</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => { navigation.closeDrawer(); navigation.navigate('reports') }}>
                <Icon2 name={'assessment'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
                <Text style={[istyles.drawerItemLabel]}>Reports</Text>
              </TouchableOpacity>
              {/* <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => {navigation.closeDrawer();navigation.navigate('postOrders')}}>
                <Icon2 name={'signpost'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
                <Text style={[istyles.drawerItemLabel]}>Post orders</Text>
              </TouchableOpacity> */}
                  {/* <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => {navigation.closeDrawer();navigation.navigate('checkList')}}>
                <Icon2 name={'messenger-outline'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
                <Text style={[istyles.drawerItemLabel]}>Check List</Text>
              </TouchableOpacity> */}
                  {/* <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => {navigation.closeDrawer();navigation.navigate('availability')}}>
                <Icon2 name={'timer'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
                <Text style={[istyles.drawerItemLabel]}>Availability</Text>
              </TouchableOpacity> */}
            </>
          }

          <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => {navigation.closeDrawer(); navigation.navigate('settings')}}>
            <Icon2 name={'settings'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
            <Text style={[istyles.drawerItemLabel]}>Settings</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => {navigation.closeDrawer(); navigation.navigate('shiftsExchange')}}>
            <Icon2 name={'settings'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
            <Text style={[istyles.drawerItemLabel]}>Shifts Exchange</Text>
          </TouchableOpacity>
          {/* <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => {navigation.closeDrawer(); navigation.navigate('confirmedShifts');}}>
            <Icon2 name={'work-outline'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
            <Text style={[istyles.drawerItemLabel]}>Confirmed Shifts</Text>
          </TouchableOpacity> */}
          <SpaceBox height={15} />
        </View>
        <SpaceBox height={15} />

        <View style={istyles.drawerSection}>
          <Text style={[istyles.drawerSectionHeader]}>SUPPORT</Text>

          <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => { navigation.closeDrawer(); alert('In-Progress') }}>
            <Icon2 name={'support-agent'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
            <Text style={istyles.drawerItemLabel}>Chat Support</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => { navigation.closeDrawer(); alert('In-Progress') }}>
            <Icon name={'email-outline'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
            <Text style={[istyles.drawerItemLabel]}>Email Support</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => { navigation.closeDrawer(); alert('In-Progress') }}>
            <Icon2 name={'messenger-outline'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
            <Text style={[istyles.drawerItemLabel]}>Feedback</Text>
          </TouchableOpacity>
        </View>
        <SpaceBox height={15} />
      </View>

      <View style={styles.drawerNavigation}>
        <View style={[istyles.drawerSection, { borderBottomWidth: 0 }]}>
          <Text style={[istyles.drawerSectionHeader]}>MORE</Text>

          <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => { navigation.closeDrawer(); navigation.navigate('aboutus')}}>
            <Icon name={'wallet-membership'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
            <Text style={[istyles.drawerItemLabel]}>About Us</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => { navigation.closeDrawer(); navigation.navigate('contactus')}}>
            <Icon name={'newspaper-variant-outline'} size={20} style={istyles.drawerItemIcon} color={appColors.themeBlueText} />
            <Text style={[istyles.drawerItemLabel]}>Contact Us</Text>
          </TouchableOpacity>

          <SpaceBox height={20} />

          <TouchableOpacity style={[styles.navigation, istyles.drawerItems]} onPress={() => { navigation.closeDrawer(); handleLogout(); }}>
            <Icon name={'logout'} size={25} style={istyles.drawerItemIcon} color='#EE4B2B' />
            <Text style={[istyles.drawerItemLabel, { color: '#EE4B2B', fontSize: 16, fontWeight: 'bold' }]}>Logout</Text>
          </TouchableOpacity> 
        </View>
        <SpaceBox height={15} />
      </View>
    </DrawerContentScrollView>
  );
}

export default CustomDrawer;

const istyles = StyleSheet.create({
  drawerSection: {
    borderColor: '#eee',
    borderBottomWidth: 1
  },
  drawerSectionHeader: {
    marginLeft: 5,
    marginBottom: 5,
    fontSize: 14,
    color: appColors.themeBlueText
  },
  drawerItems: {
    flexDirection: 'row',
    marginVertical: 2,
    marginLeft: 5,
    marginRight: 10,
  },
  drawerItemIcon: {
    alignItems: 'flex-start',
    // borderWidth:1,
    marginRight: 10,
    width: 25,
  },
  drawerItemLabel: {
    color: appColors.themeBlueText,
    height: 25,
    marginVertical:1,
  }
});