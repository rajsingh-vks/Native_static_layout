import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Home from '../components/Dashboard';
import Post from '../components/PostSites';
import Activity from '../components/Activity';
import Message from '../components/Message';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/Feather';

const Tab = createBottomTabNavigator();

function TabNavigation() {
  return (
      <Tab.Navigator 
        initialRouteName='home'
        screenOptions={{ 
            headerShown: false,
            tabBarActiveTintColor: '#cf4236',
            tabBarInactiveTintColor: '#454545'
        }}>
        <Tab.Screen name="home" component={Home} 
          options={{ 
            tabBarIcon: ({focused}) => {
              let isize = 22;
              if(focused){isize = 23;}
              return(
                <Icon2 name={'home'} size={isize} color={focused ? '#cf4236' : '#454545'} />
              )
            },
            tabBarLabel: 'HOME',
            tabBarLabelStyle:{fontWeight:'700'}
          }} />
        <Tab.Screen name="postsites" component={Post}
          options={{ 
            tabBarIcon: ({focused}) => {
              let isize = 23;
              if(focused){isize = 25;}
              return(
                <Icon name={'view-day-outline'} size={isize} color={focused ? '#cf4236' : '#454545'} />
              )
            },
            tabBarLabel: 'POST SITES',
            tabBarLabelStyle:{fontWeight:'700'}
          }} />
        <Tab.Screen name="activity" component={Activity}
          options={{ 
            tabBarIcon: ({focused}) => {
              let isize = 23;
              if(focused){isize = 25;}
              return(
                <Icon name={'av-timer'} size={isize} color={focused ? '#cf4236' : '#454545'} />
              )
            },
            tabBarLabel: 'ACTIVITY',
            tabBarLabelStyle:{fontWeight:'700'}
          }} />
        <Tab.Screen name="messages" component={Message}
          options={{ 
            tabBarIcon: ({focused}) => {
              let isize = 23;
              if(focused){isize = 25;}
              return(
                <Icon name={'message-text-outline'} size={isize} color={focused ? '#cf4236' : '#454545'} />
              )
            },
            tabBarLabel: 'MESSAGES',
            tabBarLabelStyle:{fontWeight:'700'}
          }} />
      </Tab.Navigator>
  );
}

export default TabNavigation;