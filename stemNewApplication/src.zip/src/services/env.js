const env = {
    mode: 'prod', // prod | dev
    baseURL: 'http://3.143.11.195:8000',
    currencySymbol: '$',
    debug: true,
    googleApiKey: 'AIzaSyB-O-naOKgp-92xAtTwb-JUTLBQUvVSr0U'
};
  
export default env;
  