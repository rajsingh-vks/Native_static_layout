import axios from 'axios';
import store from '../redux/store';
import { logout } from './logout';
import env from './env';

const http = axios.create({
  baseURL: env.baseURL,
});

http.interceptors.request.use(
  config => {
    let token = store.getState()?.user?.data?.token;
    console.log(token);
    if (token) {
      config.headers["Authorization"] = `Token ${token}`;
    }

    if (config.data instanceof FormData) {
      config.headers["Content-Type"] = "multipart/form-data";
    } else {
      config.headers["Content-Type"] = "application/json";
    }
    
    config.timeout = 30000;
    logRequest(config)
    return config;
  },
  error => {
    // logout();
    return Promise.reject(error);
  },
);

// After response
http.interceptors.response.use(
  response => {
    logResponse(response);
    return response.data;
  },
  error => {
    if (error?.response?.status === 401) {
      console.log('401: Un-Authorized access or Token not found.')
      logout();
      return Promise.reject({'data':{'message':'Session expired!'}});
    }else if (error?.response?.status === 404) {
      console.log('404: API not found.')
      return Promise.reject({'data':{'message':'404: Request not found.'}});
    }else if (error?.response?.status === 500) {
      console.log('500: Internal server error.')
      return Promise.reject({'data':{'message':'500: Internal server error.'}});
    } else {
      logError(error?.response);
      return Promise.reject(error?.response);
    }
  },
);


const logRequest = (config) => {
  if (env.debug) {
    console.log(`---------- Request Param -----------`);
    console.log('# Content Type ---- ', config.headers['Content-Type'] || 'N/A');
    console.log('# Token ---- ', config.headers['Authorization'] || 'N/A');
    console.log('# API ------ ', config.baseURL + config.url);
    console.log('# Params --- ', config.params || config.data || {});
  }
}

const logResponse = (response) => {
  if (env.debug) {
    console.log(`---------- Response -----------`);
    console.log(JSON.stringify(response?.data, null, 5));
  }
}

const logError = (error) => {
  if (env.debug) {
    console.log(`---------- Error -----------`);
    console.log(JSON.stringify(error, null, 5));
  }
}
export default http;
