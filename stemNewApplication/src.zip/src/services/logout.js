import AsyncStorage from '@react-native-async-storage/async-storage';
import store from '../redux/store';

import {removeUser} from '../redux/userSlice';
import {setLogout} from '../redux/logoutSlice';
// import {setSpinner} from '../redux/appSlice';
import constants from '../utils/constants';

// User logout function
export async function logout() {
  const isLogoutSet = await AsyncStorage.getItem(constants.storageKeys.LOGOUT);
  
  if (!isLogoutSet) {
    // Set logout in process
    await AsyncStorage.setItem(constants.storageKeys.LOGOUT, '1');
    store.dispatch(removeUser());
    store.dispatch(setLogout(true));
    // store.dispatch(setSpinner(false));
  }
}
