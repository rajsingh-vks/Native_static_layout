import http from './http';

const api = {
  guardSignup : async (body) => {
    return await http.post(`/api/guard-signup/`, body);
  },
  guardVerifyOTP : async (body, token) => {
    const headers = {};
    if(token != ''){
      headers["Authorization"] = `Token ${token}`;
    }
    return await http.post(`/api/guard-verification-otp/`, body, { headers });
  },
  userLogin : async (body) => {
    return await http.post(`/api/guard-login/`, body);
  },
  userLogout : async (body) => {
    return await http.post(`/api/logout/`, body);
  },
  forgotPassword : async (body) => {
    return await http.post(`/api/forget-password/`, body);
  },
  changePassword : async (body) => {
    return await http.post(`/api/change-password/`, body);
  },
  resetPassword : async (body, token) => {
    const headers = {};
    if(token != ''){
      headers["Authorization"] = `Token ${token}`;
    }

    return await http.post(`/api/reset-password/`, body, { headers });
  },
  validateOTP: async (body, token) => {
    const headers = {};
    if(token != ''){
      headers["Authorization"] = `Token ${token}`;
    }
    return await http.post(`/api/verify-number-email-otp/`, body, { headers });
  },

  updateUserProfile : async (body) => {
    return await http.post(`/company/update-user-account/`, body);
  },

  // Company
  companyList : async (body) => {
    return await http.post(`/company/companies-listing/`, body);
  },
  companySelect : async (body) => {
    return await http.post(`/company/company-select/`, body);
  },
  companyLeave : async (body) => {
    return await http.post(`/company/company-leave/`, body);
  },
  joincompany : async (body) => {
    return await http.post(`/company/company-join/`, body);
  },

  // Dashboard
  getDashboardData : async (body) => {
    return await http.post(`/company/dashboard-data/`, body);
  },
  
  getPostSites : async ( search = "", page = "",) => {
    let url = `/company/post-site-listing/?page=${page}`;

    if(search != ''){
      url = url + '&search=' + search;
    }

    return await http.get(url);
  },

  guardClockin : async (body) => {
    return await http.post(`/company/guards-checked-in-out/`, body);
  },

  getSecurityGuardsList : async (
    page = "",  
  ) => {
    return await http.get(
      `/company/guards-listing/?page=${page}`
    );
  },


  /* Reminders Section */
  reminderList : async (page="", search = "",status = "") => {
    return await http.get(`/company/reminder-listing/?search=${search}&page=${page}&status=${status}`);
  },
  addReminder : async (body) => {
    return await http.post(`/company/add-reminder/`, body);
  },
  updateReminder : async (body) => {
    return await http.patch(`/company/update-reminder/`, body);
  },
  deleteReminder : async (body) => {
    return await http.post(`/company/delete-reminder/`, body);
  },
  markReminder : async (body) => {
    return await http.post(`/company/mark-reminder-complete/`, body);
  },


  /* Time off request Section */
  timeRequestList : async (page="", search = "",status = "") => {
    return await http.get(`/scheduler/timeoff-request-listing/?search=${search}&page=${page}&status=${status}`);
  },
  deleteTimeRequest : async (body) => {
    return await http.post(`/scheduler/delete-timeoff-request/`, body);
  },
  addTimeRequest : async (body) => {
    return await http.post(`/scheduler/add-new-timeoff-request/`, body);
  },
  updateTimeRequest : async (body) => {
    return await http.post(`/scheduler/update-timeoff-request/`, body);
  },
  

  /* Scheduler Section */
  shiftsList : async (type = "",  byDate = "", page="",  search = "", status = "") => {
    let url = `/scheduler/shifts-listing/?page=${page}`;

    if(type == 'Open'){
      url = url + `&shift_type=2`;
    }else if(type == 'Confirmed'){
      url = url + `&confirm_type=1`;
    }else if(type == 'Unconfirmed'){
      url = url + `&confirm_type=0`;
    }

    if(byDate != ''){
      url = url + '&date=' + byDate;
    }

    return await http.get(url);
  },
  confirmShift : async (body) => {
    return await http.post(`/scheduler/confirm-unconfirm-shift/`, body);
  },

  // Post orders
  postOrderList : async (post_id = "", page = "", search = "") => {
    return await http.get(`/company/post-order-listing/`, {
      params: {
        page: page,
        search: search,
        post_id: post_id,
      },
    });
  },
  addPostOrderAcknowledgment : async (body) => {
    return await http.post("/company/add-post-order-acknowledgment/", body);
  },

  // Check list
  CheckListing : async (post_site_id = "", page = "", search = "") => {
    return await http.get(
      `/company/list-post-site-check-list/?page=${page}&search=${search}&post_site_id=${post_site_id}`
    );
  },
  checkListStatusMark : async (body) => {
    return await http.post("/company/mark-post-site-check-list-complete/", body);
  },

  // Guard's Latest Shift Data
  currentShift : async () => {
    let url = `/scheduler/current-shift/`;

    return await http.get(url);
  },
  getCheckinStatus : async (guard_id = "") => {
    return await http.get(
      `/company/guard-latest-activity/?guard_id=${guard_id}`
    );
  },
  clockedRequest : async (body) => {
    return await http.post(`/company/clocked-request/`, body);
  },

  // Availabilities
  getAvailability : async (guard_id = "") => {
    return await http.get(
      `/company/guards-weekly-availability/?guard_id=${guard_id}`
    );
  },
  updateAvailabilities : async (body) => {
    return await http.post(`/company/update-guards-availability/`, body);
  },

  // License
  guardLicenseListing : async (
    guard_id = "",
    page = "",
    search = ""
  ) => {
    return await http.get(
      `/company/user-license-listing/?guard_id=${guard_id}&page=${page}&search=${search}`
    );
  },
  guardLicenseTypeListing : async () => {
    return await http.get(`/company/add-license/`);
  },
  addGuardLicense : async (body) => {
    return await http.post("/company/add-license/", body);
  },
  updateguardLicense : async (body) => {
    return await http.patch(`/company/update-license/`, body);
  },
  deleteGuardLicense : async (body) => {
    return await http.post(`/company/delete-license/`, body);
  },

  //Task
  getPostSiteTask :async (id) => {
    return await http.get(`/company/task-listing/`, {
      params: {
        post_id: id,
      },
    });
  },

// Task Mark as completed
taskMarkAsCompleted : async (body) => {
  return await http.post("/company/mark-task-as-complete/", body);
},

  // Site tours
  getSiteTours : async (id) => {
    return await http.get(`/company/site-tour-listing/`, {
      params: {
        post_site: id,
      },
    });
  },
  
  //  Visitor
  addVisitor : async (body) => {
    return await http.post(`/visitors/add-new-guard-visitor/`, body);
  },
  updateVisitor : async (body) => {
    return await http.post(`/visitors/update-visitor/`, body);
  },
  visitorList : async (search = "", page = "", post_site_id = "", guard_id = "", company_id = "") => {
    return await http.get(
      `/visitors/guard-visitor-listing/?search=${search}&page=${page}&post_site_id=${post_site_id}&guard_id=${guard_id}&company_id=${company_id}`
    );
  },
  visitorDetails : async (id = "") => {
    return await http.get(`/visitors/view-visitor/?visitor_id=${id}`);
  },
  deleteVisitor : async (body) => {
    return await http.post(`/visitors/delete-visitor/`, body);
    
  },

  // Reports
  getSiteTourReports : async (search = "", page = "") => {
    return await http.get(
      `/reports/site-tour-report-listing?search=${search}&page=${page}`
    );
  },
  getChecklist : async (search = "", page = "") => {
    return await http.get(
      `/reports/report-checklist-lisitng/?search=${search}&page=${page}`
    );
  }

}

export default api;
