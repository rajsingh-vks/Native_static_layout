import { View, Text, StyleSheet, ScrollView } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import { TagStatus, WeekDaysNames } from '../../utils/appHelpers';
import styles from '../../utils/styles';

const SiteTourDetails = ({ route, navigation }) => {
  const { tour } = route.params;
  console.log(typeof tour.tag_type, "TOUR");


  return (
    <>
      <Header title="Site Tour Info" />
      <View style={[styles.container]}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}>

          <View style={iStyles.card}>
            <View style={iStyles.leftBorder}></View>
            <View style={iStyles.cardContent}>
              <View style={iStyles.cardHeader}>
                <Text style={iStyles.title}>{tour?.tour_name ?? '--'}</Text>
                <View style={iStyles.statusContainer}>
                  <Text style={iStyles.statusText}>Qr</Text>
                  <Text style={iStyles.statusNumber}>2</Text>
                </View>
              </View>
              <View style={iStyles.scheduleContainer}>
                <Icon name="calendar" size={16} color="#007bff" />
                <Text style={iStyles.scheduleText}>{WeekDaysNames(tour?.selected_days)}</Text>
              </View>
              <View style={iStyles.divider}></View>
              <Text style={iStyles.description}>
                {tour?.description ?? ""}
              </Text>

            </View>
          </View>




          <View style={iStyles.cardSecond}>
            <View style={iStyles.contentContainer}>
              <View style={iStyles.row}>
                <Text style={iStyles.label}>Start Time</Text>
                <Text style={iStyles.value}>{tour?.start_time?.map((ele) => ele.label).join(", ") ?? "--"}</Text>
              </View>
              <View style={iStyles.row}>
                <Text style={iStyles.label}>Duration</Text>
                <Text style={iStyles.value}>{tour?.max_duration ?? '--'}</Text>
              </View>
              <View style={iStyles.missedContainer}>
                <Text style={iStyles.missedText}>{TagStatus(tour?.tag_type)}</Text>
              </View>
              <View style={iStyles.missedContainer}>
                <Text style={iStyles.missedText}>{tour?.tags?.map((ele) => ele.label)}</Text>
              </View>
            </View>

          </View>

        </ScrollView>
      </View>
    </>
  );
};

const iStyles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    flexDirection: 'row',
    marginHorizontal: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
    overflow: 'hidden',
  },
  leftBorder: {
    width: 5,
    backgroundColor: '#007bff',
  },
  cardContent: {
    flex: 1,
    padding: 15,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusText: {
    backgroundColor: '#c8e6c9',
    color: '#388e3c',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 5,
    marginRight: 5,
  },
  statusNumber: {
    backgroundColor: '#ffcdd2',
    color: '#d32f2f',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 5,
  },
  scheduleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  scheduleText: {
    fontSize: 14,
    color: '#333',
    marginLeft: 5,
  },
  divider: {
    height: 1,
    backgroundColor: '#90caf9',
    marginVertical: 5,
  },
  description: {
    fontSize: 13,
    color: '#666',
  },
  cardSecond: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    marginHorizontal: 15,
    marginBottom: 10,
    overflow: 'hidden',

  },
  contentContainer: {
    paddingVertical: 10,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  label: {
    fontSize: 14,
    color: '#333',
  },
  value: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
  },
  divider: {
    height: 1,
    backgroundColor: '#90caf9',
    marginVertical: 10,
  },
  missedContainer: {
    alignSelf: 'flex-end',
    backgroundColor: '#ffcdd2',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 5,
  },
  missedText: {
    color: '#d32f2f',
    fontSize: 12,
    fontWeight: 'bold',
  },
});

export default SiteTourDetails;
