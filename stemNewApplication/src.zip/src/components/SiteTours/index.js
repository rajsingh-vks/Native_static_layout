import { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, RefreshControl, ScrollView, StyleSheet } from 'react-native';
import { convertUTCToLocal, showErrorToast, WeekDaysNames } from '../../utils/appHelpers';
import { useDispatch, useSelector } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Header from '../Header';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { getRefresh } from '../../redux/refreshSlice';
import styles from '../../utils/styles';

const Index = ({ route, navigation }) => {
  const { siteId } = route.params;

  const dispatch = useDispatch();
  const [siteTours, setSiteTours] = useState([]);
  const [isDataFetched, setIsDataFetched] = useState(false);
  const refresh = useSelector((state) => getRefresh(state, 'siteTours'));

  const getSiteTours = async () => {
    dispatch(setSpinner(true));
    try {
      const response = await api.getSiteTours(siteId);
      if (response?.status == 200) {
        setSiteTours(response.data ?? []);
      } else {
        setSiteTours([]);
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message || 'Failed to fetch siteTours');
    } finally {
      setIsDataFetched(true);
      dispatch(setSpinner(false));
    }
  };

  useEffect(() => {
    getSiteTours();
  }, [refresh]);

  return (
    <>
      <Header title="Site Tours" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={() => getSiteTours()}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 50 }}
          showsVerticalScrollIndicator={false}>
          {siteTours?.length > 0 && <Text style={styles.settingTitle}>SITE TOURS</Text>}

          {isDataFetched && siteTours?.length === 0 ? (
            <View style={styles.noRecordsContainer}>
              <Image
                source={require('../../assets/images/not-found.png')}
                style={styles.noRecordsImage}
              />
              <Text style={styles.noRecordsText}>No Data Found</Text>
            </View>
          ) : (
            siteTours?.map((tour, index) => (
              <TouchableOpacity onPress={() => navigation.navigate('siteToursDetails', { tour })} key={index} style={iStyles.card}>
                <View style={iStyles.leftBorder}></View>
                <View style={iStyles.cardContent}>
                  <View style={iStyles.cardHeader}>
                    <Text style={iStyles.title}>{tour?.tour_name ?? '--'}</Text>
                    <View style={iStyles.statusContainer}>
                      <Text style={iStyles.statusText}>Qr</Text>
                      <Text style={iStyles.statusNumber}>2</Text>
                    </View>
                  </View>
                  <View style={iStyles.scheduleContainer}>
                    <Icon name="calendar" size={16} color="#007bff" />
                    <Text style={iStyles.scheduleText}>{WeekDaysNames(tour?.selected_days)}</Text>
                  </View>
                  <View style={iStyles.divider}></View>
                  <Text style={iStyles.description}>
                    {tour?.description ? (tour.description.length > 100 ? `${tour.description.slice(0, 100)}...` : tour.description) : ""}
                  </Text>

                </View>
              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>
    </>
  );
}

const iStyles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    flexDirection: 'row',
    marginHorizontal: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
    overflow: 'hidden',
  },
  leftBorder: {
    width: 5,
    backgroundColor: '#007bff',
  },
  cardContent: {
    flex: 1,
    padding: 15,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusText: {
    backgroundColor: '#c8e6c9',
    color: '#388e3c',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 5,
    marginRight: 5,
  },
  statusNumber: {
    backgroundColor: '#ffcdd2',
    color: '#d32f2f',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 5,
  },
  scheduleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  scheduleText: {
    fontSize: 14,
    color: '#333',
    marginLeft: 5,
  },
  divider: {
    height: 1,
    backgroundColor: '#90caf9',
    marginVertical: 5,
  },
  description: {
    fontSize: 13,
    color: '#666',
  },
});

export default Index;
