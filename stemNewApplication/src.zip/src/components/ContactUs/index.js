import * as React from 'react';
import { View, Text, ScrollView, TouchableOpacity, RefreshControl, TextInput } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import styles from '../../utils/styles';
import Input from '../Common/Input';
import appColors from '../../utils/appColors';

function ContactUs() {
  const navigation = useNavigation();

  return (
    <>
      <Header title="Contact Us" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
            />
          }
          contentContainerStyle={{ flexGrow: 1 }}>
          <View>
            <View style={{ marginBottom: 10 }}>
              <Input
                type='text'
                label='Full Name'
                placeholder="Your name"
                placeholderTextColor="#CDCDCD"
                inputStyle={{ paddingHorizontal: 15 }}
              />
            </View>
            <View style={{ marginBottom: 10 }}>
              <Input
                type='text'
                label='Email id'
                placeholder="Email id"
                placeholderTextColor="#CDCDCD"
                inputStyle={{ paddingHorizontal: 15 }}
              />
            </View>
            <View style={{marginBottom: 35}}>
              <Text style={styles.label}>Message</Text>
              <TextInput
                style={styles.textareaLarge}
                type='text'
                label='Message'
                multiline={true}
                numberOfLines={4}
                placeholder="Your message"
                placeholderTextColor="#CDCDCD"
              />
            </View>
            <View style={[styles.btnContainer, { height: 55, marginHorizontal: 0 }]}>
              <TouchableOpacity
                style={[styles.Authbtn, { backgroundColor: '#2360FB' }]}>
                <Text style={styles.Authbtntext}>Submit</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

export default ContactUs