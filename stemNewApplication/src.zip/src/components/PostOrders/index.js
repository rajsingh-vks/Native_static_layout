import { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, RefreshControl, ScrollView, StyleSheet, Alert } from 'react-native';
import { convertUTCToLocal, showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import { useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import SpaceBox from '../Common/SpaceBox';
import { showConfirmationBox } from '../Common/Confirmation';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { getRefresh } from '../../redux/refreshSlice';
import styles from '../../utils/styles';

const Index = ({ route }) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const { site_id } = route?.params;
  const refresh = useSelector((state) => getRefresh(state, 'postOrders'));

  const [isDataFetched, setIsDataFetched] = useState(false); // Track whether data fetching is complete
  const [postOrders, setPostOrders] = useState([]);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');

  const getPostOrders = async () => {
    dispatch(setSpinner(true));
    try {
      const response = await api.postOrderList(site_id, page, search);
      if (response?.status === 200) {
        setPostOrders(response?.data ?? []);
      } else {
        setPostOrders([]);
        showErrorToast(response?.data?.message);
      }
    } catch (error) {
      showErrorToast(error.data?.message || 'Failed to fetch postOrders');
    } finally {
      setIsDataFetched(true);
      dispatch(setSpinner(false));
    }
  };

  useEffect(() => {
    getPostOrders();
  }, [refresh]);

  return (
    <>
      <Header title="PostOrders" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={() => getPostOrders()}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 20 }}
          showsVerticalScrollIndicator={false}>

          {isDataFetched && postOrders?.length === 0 ? (
            <View style={styles.noRecordsContainer}>
              <Image
                source={require('../../assets/images/not-found.png')}
                style={styles.noRecordsImage}
              />
              <Text style={styles.noRecordsText}>No Data Found</Text>
            </View>
          ) : (
            postOrders?.map((post_order, index) => (
              <TouchableOpacity 
                key={index}
                style={[styles.settingTab, { marginBottom: 10 }]}
                onPress={() => navigation.navigate('postOrderDetails', { post_order })}>
                <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc' }]}></View>

                <View style={[styles.companyDetails]}>
                  <View style={styles.tabHeader}>
                    <Text style={[styles.companyName, { fontSize: 19, fontWeight:'600' }]}>
                      {post_order?.title ?? '--'}
                    </Text>
                  </View>
                  <SpaceBox height={10} />
                  <View style={{ flexDirection: 'row', marginBottom:5 }}>
                    <View style={[styles.tabIconCircle, { backgroundColor: '#e2eaff', marginRight:5, height:30, width:30 }]}>
                      <Icon name={'calendar'} size={18} style={{ color: '#1d61f4' }} />
                    </View>
                    <View style={{ flex:1, justifyContent: 'center' }}>
                      <Text style={[styles.companyEmail, {fontSize:17}]}>
                        {convertUTCToLocal(post_order?.created_on, 'ddd, MMM DD YYYY', false)}
                      </Text>
                    </View>
                    <View style={[styles.ackStatus, post_order?.acknowledgment_status?.status === 'yes' ? styles.greenTag : styles.redTag]}>
                      <Text style={[styles.ackStatusText, {color:post_order?.acknowledgment_status?.status === 'yes' ?'green':'red'}]}>
                        {post_order?.acknowledgment_status?.status === 'yes'? 'Acknowledged':'Unacknowledged'}
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                  <SpaceBox height={10} />

                  <Text style={[styles.companyEmail, {fontSize:16}]}>
                  {post_order?.description ? (post_order.description.length > 200 ? `${post_order.description.slice(0, 300)}...` : post_order.description) : ""}
                  </Text>
                </View>

              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>
    </>
  );
}

export default Index;
