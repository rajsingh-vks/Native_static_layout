import React, { useRef, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import SignatureScreen from "react-native-signature-canvas";

const AddAcknowledge = () => {
  const signatureRef = useRef(null);
  const [signature, setSignature] = useState(null);

  const handleOK = (signature) => {
    console.log("Signature captured:", signature);
    setSignature(signature);
    Alert.alert("Signature Saved", "Your signature has been successfully captured.");
  };

  const handleEmpty = () => {
    console.log("Canvas is empty.");
    Alert.alert("Empty Canvas", "Please sign before saving.");
  };

  const handleClear = () => {
    if (signatureRef.current) {
      signatureRef.current.clearSignature();
    }
    setSignature(null);
    console.log("Signature cleared.");
  };

  const handleEnd = () => {
    console.log("Signature process ended.");
    signatureRef.current.readSignature();
  };

  const handleSave = () => {
    if (signature) {
      console.log("Saved Signature:", signature);
      Alert.alert("Success", "Signature has been saved!");
    } else {
      Alert.alert("No Signature", "Please provide a signature before saving.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Add Your Acknowledgement</Text>
      <View style={styles.signatureContainer}>
        <SignatureScreen
          ref={signatureRef}
          onEnd={handleEnd}
          onOK={handleOK}
          onEmpty={handleEmpty}
          autoClear={false}
          descriptionText="Sign Below"
          webStyle={`
            .m-signature-pad { 
              border: 1px solid #ccc; 
              border-radius: 10px; 
              margin: 0; 
            }
            .m-signature-pad--body { 
              border-radius: 10px; 
              background-color: white; 
              margin: 0; 
              height: 100%; 
            }
            .m-signature-pad--footer { 
              display: none; 
            }
            canvas { 
              background-color: transparent; 
              width: 100%; 
              height: 100%; 
            }
          `}
        />
      </View>
      <View style={styles.buttonRow}>
        <TouchableOpacity style={styles.button} onPress={handleClear}>
          <Text style={styles.buttonText}>Clear</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={handleSave}>
          <Text style={styles.buttonText}>Save</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default AddAcknowledge;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9f9f9',
    padding: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
    color: '#333',
  },
  signatureContainer: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#fff',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  button: {
    flex: 0.48,
    backgroundColor: '#007BFF',
    paddingVertical: 15,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
