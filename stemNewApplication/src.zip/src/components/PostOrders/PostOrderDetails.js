import React, { useState, useRef, useCallback } from 'react';
import { View, Text, TouchableOpacity, ScrollView, Image, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Signature from 'react-native-signature-canvas';
import ImageViewing from "react-native-image-viewing";
import Header from '../Header';
import FileType from '../FileType/index';
import { useDispatch } from 'react-redux';
import { setSpinner } from '../../redux/appSlice';
import { convertUTCToLocal, showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import api from '../../services/api';
import styles from '../../utils/styles';
import SpaceBox from '../Common/SpaceBox';

const PostOrderDetails = ({ route, navigation }) => {
  const { post_order } = route.params;


  console.log(post_order,"TEXT");
  
  const [signature, setSignature] = useState(null);
  const [isViewerVisible, setIsViewerVisible] = useState(false);
  const [images, setImages] = useState([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isChecked, setIsChecked] = useState(false);


  const dispatch = useDispatch();
  const signatureRef = useRef(null);

  const handleSignature = (signature) => {
    if (signature) {
      setSignature(signature);
    }
  };


  const handleClear = useCallback(() => {
    if (signatureRef.current) {
      signatureRef.current.clearSignature();
    }
    setSignature(null);
  }, []);

  const handleEnd = () => {
    signatureRef.current.readSignature();
  };
  const openImage = (imageUri, index) => {
    setImages([{ uri: imageUri }]);
    setCurrentImageIndex(index);
    setIsViewerVisible(true);
  };
  const handleSubmit = useCallback(async () => {
    try {
      dispatch(setSpinner(true));

      const formData = new FormData();
      formData.append('signature', signature);
      formData.append('post_order_id', post_order?.id);

      const response = await api.addPostOrderAcknowledgment(formData);

      if (response?.status) {
        showSuccessToast(response?.message);
        navigation.goBack()
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      console.error('Error submitting signature:', error);
      showErrorToast('An error occurred while saving.');
    } finally {
      dispatch(setSpinner(false));
    }
  }, [signature, post_order, navigation]);

  return (
    <>
      <Header title="PostOrder Info" />
      <View style={[styles.container]}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 10 }}
          showsVerticalScrollIndicator={false}>

          <TouchableOpacity
            style={[styles.settingTab, { marginBottom: 10 }]}
            onPress={() => navigation.navigate('postOrderDetails', { post_order })}>
            <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc' }]}></View>

            <View style={[styles.companyDetails]}>
              <View style={styles.tabHeader}>
                <Text style={[styles.companyName, { fontSize: 19, fontWeight: '600' }]}>
                  {post_order?.title ?? '--'}
                </Text>
              </View>
              <SpaceBox height={10} />
              <View style={{ flexDirection: 'row', marginBottom: 5 }}>
                <View style={[styles.tabIconCircle, { backgroundColor: '#e2eaff', marginRight: 5, height: 30, width: 30 }]}>
                  <Icon name={'calendar'} size={18} style={{ color: '#1d61f4' }} />
                </View>
                <View style={{ flex: 1, justifyContent: 'center' }}>
                  <Text style={[styles.companyEmail, { fontSize: 17 }]}>
                    {convertUTCToLocal(post_order?.created_on, 'ddd, MMM DD YYYY', false)}
                  </Text>
                </View>
                <View style={[styles.ackStatus, post_order?.acknowledgment_status?.status === 'yes' ? styles.greenTag : styles.redTag]}>
                  <Text style={[styles.ackStatusText, { color: post_order?.acknowledgment_status?.status === 'yes' ? 'green' : 'red' }]}>
                    {post_order?.acknowledgment_status?.status === 'yes' ? 'Acknowledged' : 'Unacknowledged'}
                  </Text>
                </View>
              </View>
              <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
              <SpaceBox height={10} />

              <Text style={[styles.companyEmail, { fontSize: 16 }]}>
                {post_order?.description ? (post_order.description.length > 200 ? `${post_order.description.slice(0, 300)}...` : post_order.description) : ""}
              </Text>
            </View>

          </TouchableOpacity>

          <View style={iStyles.attachments}>
            {post_order?.post_order_attachment?.length > 0 ? (
              post_order?.post_order_attachment?.map((item, index) => (
                <TouchableOpacity
                  // style={iiStyles.attachmentContainer}
                  onPress={() => openImage(item?.attachment, index)}
                  key={index}
                >
                  <FileType url={item?.attachment} />

                </TouchableOpacity>

              ))
            ) : (
              <Text>No attachments available</Text>
            )}
          </View>

          <View style={iStyles.signatureContainer}>
            {post_order?.acknowledgment_status?.status === 'no' && (
              <View style={iStyles.signatureSection}>
                <Text style={iStyles.sectionTitle}>ACKNOWLEDGE</Text>
                <View style={iStyles.signatureWrapper}>
                  <Signature
                    ref={signatureRef}
                    onOK={handleSignature}
                    onEnd={handleEnd}
                    descriptionText="Sign below"
                    clearText="Clear"
                    confirmText="Save"
                    webStyle={`.m-signature-pad { border: 1px solid #f4f4f4; border-radius: 10px; }`}
                    style={iStyles.signaturePad}
                  />
                  {post_order?.acknowledgment_status?.status === 'no' && (
                    <TouchableOpacity style={iStyles.clearButton} onPress={handleClear} disabled={!signature}>
                      <Text style={iStyles.clearButtonText}>Clear</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            )}
          </View>


          <ImageViewing
            images={images}
            imageIndex={currentImageIndex}
            visible={isViewerVisible}
            onRequestClose={() => setIsViewerVisible(false)}
          />
        </ScrollView>




      </View>
      {post_order?.acknowledgment_status?.status === 'no' && (
      <View style={{ backgroundColor: "white", padding: 10 }}>
               <View style={iStyles.checkboxContainer}>
          <TouchableOpacity onPress={() => setIsChecked(!isChecked)} style={[iStyles.checkbox, isChecked && iStyles.checkedCheckbox]}>
            {isChecked && <Icon name="check" size={16} color="#fff" />}
          </TouchableOpacity>
          <Text style={iStyles.checkboxText}>
            By clicking on the acknowledge button I agree that I have
            thoroughly read and I acknowledge the post orders
          </Text>
        </View>
       

          <View style={[styles.btnContainer]}>
            <TouchableOpacity
              style={[!signature || !isChecked ? styles.disabledBtn : styles.Authbtn]}
              onPress={handleSubmit}
              disabled={!signature || !isChecked}
            >
              <Text style={styles.Authbtntext}>
                Acknowledge
              </Text>
            </TouchableOpacity>
          </View>

      </View>
        )}

    </>
  );
};


const iStyles = StyleSheet.create({
  signatureContainer: {
    marginTop: 60
  },
  signatureSection: {
    marginVertical: 10,
    width: '100%',
  },
  signatureWrapper: {
    width: '100%',
    position: 'relative',
  },
  signaturePad: {
    width: '100%',
    height: 200,
    backgroundColor: '#fff',
    borderRadius: 10,
    borderColor: '#ddd',
    borderWidth: 1,
  },
  clearButton: {
    position: 'absolute',
    right: 10,
    top: 10,
    padding: 5,
    backgroundColor: '#f44336',
    borderRadius: 5,
  },
  clearButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 30,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
    backgroundColor: '#fff',
  },
  checkboxText: {
    fontSize: 14,
    color: '#333',
  },
  checkedCheckbox: {
    backgroundColor: '#3b5998',
  },
  attachments:{
    padding:10,
  }
  
});

export default PostOrderDetails;

