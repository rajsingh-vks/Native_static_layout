import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import moment from 'moment';

import Header from '../Header';
import { PriorityStatus, reminderStatus } from '../../utils/appHelpers';
// import styles from '../../utils/styles';

const ReminderDetails = ({ route, navigation }) => {
  const { remind } = route.params;

  return (
    <>
      <Header title="Reminder Info" />
      <View style={[styles.container]}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}>
          {/* Title */}
          <View style={styles.infoRow}>
            <View style={styles.iconWrapper}>
              <Icon name="account" style={styles.icon} />
            </View>
            <View style={styles.textWrapper}>
              <Text style={styles.infoTitle}>Title</Text>
              <Text style={styles.infoSubtitle}>{remind?.title ?? '--'}</Text>
            </View>
          </View>

          {/* Description */}
          <View style={styles.infoRow}>
            <View style={styles.iconWrapper}>
              <Icon name="file-document" style={styles.icon} />
            </View>
            <View style={styles.textWrapper}>
              <Text style={styles.infoTitle}>Description</Text>
              <Text style={styles.infoSubtitle}>{remind?.description ?? '--'}</Text>
            </View>
          </View>

          {/* Selected Date */}
          <View style={styles.infoRow}>
            <View style={styles.iconWrapper}>
              <Icon name="calendar" style={styles.icon} />
            </View>
            <View style={styles.textWrapper}>
              <Text style={styles.infoTitle}>Selected Date</Text>
              <Text style={styles.infoSubtitle}>
                {remind?.reminder_date_time
                  ? moment(remind.reminder_date_time).format('MMMM Do, YYYY [at] h:mm A')
                  : '--'}
              </Text>
            </View>
          </View>

          {/* Priority */}
          <View style={styles.infoRow}>
            <View style={styles.iconWrapper}>
              <Icon name="flag" style={styles.icon} />
            </View>
            <View style={styles.textWrapper}>
              <Text style={styles.infoTitle}>Priority</Text>
              <Text style={styles.infoSubtitle}>{PriorityStatus(remind?.priority)}</Text>
            </View>
          </View>

          {/* Status */}
          <View style={styles.infoRow}>
            <View style={styles.iconWrapper}>
              <Icon name="card" style={styles.icon} />
            </View>
            <View style={styles.textWrapper}>
              <Text style={styles.infoTitle}>Status</Text>
              <Text style={styles.infoSubtitle}>{reminderStatus(remind?.status)}</Text>
            </View>
          </View>
        </ScrollView>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },

  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 3,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  iconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#e0e0e0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    fontSize: 20,
    color: '#3b5998',
  },
  textWrapper: {
    marginLeft: 10,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  infoSubtitle: {
    fontSize: 14,
    color: '#666',
  },
  headerRight: {
    flexDirection: 'row',
  },
  drawerTouch: {
    padding: 10,
  },
  drawerIcon: {
    color: '#fff',
  },
});

export default ReminderDetails;
