import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, Platform, KeyboardAvoidingView, ScrollView } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import moment from 'moment';

import Header from '../Header';
import Input from '../Common/Input';
import DateComponent from '../Common/DateComponent';
import SelectComponent from '../Common/SelectComponent';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { getUser } from '../../redux/userSlice';
import { showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import Dropdown from '../../utils/dropdown';
import validateForm from '../../utils/validateForm';
import styles from '../../utils/styles';

const AddEditReminder = ({ route, navigation }) => {
  const dispatch = useDispatch();
  const user = useSelector(getUser);
  const { remind } = route.params || {};
  const [disabled, setDisabled] = useState(true);
  
  const [fields, setFields] = useState({
    title: remind?.title,
    description: remind?.description || "",
    added_date_time: remind?.added_date_time || "",
    reminder_date: remind?.reminder_date || "",
    remind_time: remind?.remind_time || "",
    hour: remind?.hour || "",
    minute: remind?.minute || "",
    priority: Number(remind?.priority) || "",
  });

  const rules_reminders = {
    title: ['required', 'string'],
    description: ['required', 'string'],
    priority: ['required', 'number'],
    reminder_date: ['required', 'date'],
    remind_time: ['required', 'number'],
    hour: ['required', 'number'],
    minute: ['required', 'number'],
  };

  const handleInputChange = (field, value) => {
    setFields((prevState) => ({ ...prevState, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // dispatch(setSpinner(true));
    
    try {
      let formData = new FormData();
      const fromDateTime = `${fields.reminder_date}T${fields?.hour.value+':'+fields?.minute.value}`;
      formData.append('user_id', user?.id);
      formData.append('company_id', user?.company_id);
      formData.append('status', 'P');
      formData.append('title', fields?.title?.trim());
      formData.append('description', fields?.description?.trim());
      formData.append("added_date_time", moment().format("YYYY-MM-DD HH:mm:ss"));
      formData.append("reminder_date_time", moment(fromDateTime).format("YYYY-MM-DD HH:mm:ss"));
      formData.append('remind_time', fields?.remind_time.value);
      formData.append('priority', fields?.priority.value);
      formData.append('time_zone', 'India Standard Time');

      const response = await api.addReminder(formData);

      if (response?.status) {
        showSuccessToast(response?.message);
        navigation.goBack();
        // navigation.navigate('reminders');
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      console.error('Error updating reminder:', error);
      showErrorToast('An error occurred while saving the reminder');
    } finally {
      dispatch(setSpinner(false));
    }
  };

  useEffect(() => {
    let rules = rules_reminders;
    let valStat = validateForm(fields, rules);
    console.log(valStat);
    if (valStat?.status == true) {
      setDisabled(false);
    } else {
      setDisabled(true);
    }
  }, [fields]);

  return (
    <>
      <Header title={remind?.id ? 'Update Reminder' : 'Add Reminder'} />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, backgroundColor:'#FFF'}} 
          keyboardShouldPersistTaps="handled">
          
          <View style={[{ flex: 1, backgroundColor: '#fff'}]}>
            <View style={[styles.container, { boxShadow: 'none', backgroundColor: '#fff', padding: 0 }]}>
              <View style={{ marginVertical: 5 }}>
                <Input
                  type="text"
                  label="Title"
                  value={fields.title}
                  placeholder="Title"
                  required={true}
                  placeholderTextColor="#CDCDCD"
                  onChangeText={(value) => handleInputChange('title', value)}
                />
              </View>

              <View style={{ marginVertical: 5 }}>
                <Input
                  type="textarea"
                  numberOfLines={4}
                  style={{ height: 80 }}
                  label="Description"
                  value={fields.description}
                  required={true}
                  placeholder="Description"
                  placeholderTextColor="#CDCDCD"
                  onChangeText={(value) => handleInputChange('description', value)}
                />
              </View>

              <DateComponent 
                label="From Date"
                value={fields.reminder_date}
                required={true}
                placeholder="DD-MM-YYYY"
                minDate={moment().startOf('day').toISOString()}
                onChange={(reminder_date) => handleInputChange('reminder_date', reminder_date)}
              />              

              <View style={{flexDirection:'row'}}>
                <View style={{flex:1}}>
                  <SelectComponent 
                    label="Hour"
                    placeholder="Select Hour"
                    options={Dropdown?.hour}
                    value={fields.hour}
                    required={true}
                    onSelect={(hour) => handleInputChange('hour', hour)}
                  />
                </View>
                <View style={{flex:1, marginLeft:10}}>
                  <SelectComponent 
                    label="Minute"
                    placeholder="Select Hour"
                    options={Dropdown?.minute}
                    value={fields.minute}
                    required={true}
                    onSelect={(minute) => handleInputChange('minute', minute)}
                  />
                </View>
              </View>

              <SelectComponent 
                label="Priority"
                placeholder="Select Priority"
                options={Dropdown?.priorityItems}
                value={fields.priority}
                required={true}
                onSelect={(priority) => handleInputChange('priority', priority)}
              />

              <SelectComponent 
                label="Remind"
                placeholder="Select Remind"
                options={Dropdown?.remindList}
                value={fields.remind_time}
                required={true}
                onSelect={(remind_time) => handleInputChange('remind_time', remind_time)}
              />
            </View>
          </View>

          <View style={{ height: 50, marginBottom: 20, marginHorizontal:15 }}>
            <TouchableOpacity
              style={disabled ? styles.disabledBtn : styles.Authbtn}
              disabled={disabled}
              onPress={handleSubmit}>
              <Text style={styles.Authbtntext}>Save Reminder</Text>
            </TouchableOpacity>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>
    </>
  );
}



export default AddEditReminder;
