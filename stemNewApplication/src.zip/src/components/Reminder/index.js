import { useCallback, useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, RefreshControl, ScrollView, StyleSheet, Alert } from 'react-native';
import { convertUTCToLocal, PriorityStatus, showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
// import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
// import Icon2 from 'react-native-vector-icons/Feather';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import SpaceBox from '../Common/SpaceBox';
import { showConfirmationBox } from '../Common/Confirmation';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { getRefresh } from '../../redux/refreshSlice';
import styles from '../../utils/styles';
import appColors from '../../utils/appColors';

const Index = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [reminders, setReminders] = useState([]);
  const [isDataFetched, setIsDataFetched] = useState(false);
  const refresh = useSelector((state) => getRefresh(state, 'reminders'));

  const getReminders = async () => {
    dispatch(setSpinner(true));
    try {
      const response = await api.reminderList(1);
      if (response?.results) {
        setReminders(response.results ?? []);
      } else {
        setReminders([]);
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message || 'Failed to fetch reminders');
    } finally {
      setIsDataFetched(true);
      dispatch(setSpinner(false));
    }
  };

  const handleReminderDelete = async (reminder_id) => {
    showConfirmationBox(
      'Delete Reminder',
      'Are you sure you want to delete this reminder?',
      async () => {
        dispatch(setSpinner(true));
        try {
          const formData = new FormData();
          formData.append('reminder_id', reminder_id);

          const response = await api.deleteReminder(formData);

          if (response.status === 200) {
            const updatedReminders = reminders.filter((item) => item.id !== reminder_id);
            setReminders(updatedReminders);
            showSuccessToast(response?.message || 'Reminder deleted successfully');
          } else {
            showErrorToast(response?.message || 'Failed to delete the reminder');
          }
        } catch (error) {
          showErrorToast(error?.message || 'An error occurred while deleting the reminder');
        } finally {
          dispatch(setSpinner(false));
        }
      }
    );
  };

  const handleConfirmation = async (reminder_id, currentStatus) => {
    const newStatus = currentStatus === '1' ? '0' : '1';
    try {
      const formData = new FormData();
      formData.append('reminder_id', reminder_id);
      formData.append('status', newStatus);

      const response = await api.markReminder(formData);

      if (response?.status === 200) {
        setReminders((prev) =>
          prev.map((reminder) =>
            reminder.id === reminder_id ? { ...reminder, status: newStatus } : reminder
          )
        );
        showSuccessToast(response?.message);
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message);
    }
  };

  useEffect(() => {
    getReminders();
  }, [refresh]);

  useFocusEffect(
    useCallback(() => {
      getReminders();     
      return () => {}; 
    }, [])
  );

  return (
    <>
      <Header title="Reminders" />
      <View style={[styles.container]}>
        <ScrollView 
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={() => getReminders()}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 50}}
          showsVerticalScrollIndicator={false}>

          {isDataFetched && reminders?.length === 0 ? (
            <View style={styles.noRecordsContainer}>
              <Image
                source={require('../../assets/images/not-found.png')}
                style={styles.noRecordsImage}
              />
              <Text style={styles.noRecordsText}>No Data Found</Text>
            </View>
          ) : (
            reminders?.map((remind, index) => (
              <TouchableOpacity 
                key={index}
                style={[styles.cardTab, { marginBottom: 10 }]}
                onPress={() => navigation.navigate('reminderDetails', { remind })}>
                <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc' }]}></View>

                <View style={styles.tabDetails}>
                  <View style={styles.tabHeader}>
                    <Text style={styles.tabHeaderTitle}>
                      {remind?.title ?? '--'}
                    </Text>
                    <Text style={[styles.tabStatus, {backgroundColor:remind?.status === '1' ? appColors.lightgreen : appColors.lightYellow}]}>
                      {remind?.status === '1' ? 'Completed' : 'Pending'}
                    </Text>
                  </View>
                  <SpaceBox height={2} />
                  <View style={styles.horizontalLine}></View>

                  <View style={[{ flexDirection: 'row' }]}> 
                    <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                      <View style={[styles.tabIconCircle, { backgroundColor: '#e2eaff', marginTop:1 }]}>
                        <Icon2 name={'alpha-p-circle-outline'} size={25} style={{ color: '#1d61f4' }} />
                      </View>
                      <View style={{ justifyContent: 'center' }}>
                        <Text style={styles.tabIconLabel}>
                          Priority
                        </Text>
                        <SpaceBox height={3} />
                        <Text style={[styles.tabIconTitle]}>
                          {PriorityStatus(remind?.priority)}
                        </Text>
                      </View>
                    </View>
                    <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                      <View style={[styles.tabIconCircle, { backgroundColor: '#e2eaff', marginTop:1 }]}>
                        <Icon2 name={'calendar-month'} size={22} style={{ color: '#1d61f4' }} />
                      </View>
                      <View style={{ justifyContent: 'center' }}>
                        <Text style={styles.tabIconLabel}>
                          Date
                        </Text>
                        <SpaceBox height={3} />
                        <Text style={[styles.tabIconTitle, { color: '#000e42'}]}>
                          {convertUTCToLocal(remind?.created_on, 'MMM DD, YY', false)}
                        </Text>
                      </View>
                    </View>
                  </View>

                  <View style={{flexDirection:'row', paddingVertical:5, justifyContent:'flex-end'}}>
                    <Text style={styles.tabViewDetails}>
                      View Details
                    </Text>
                    <Icon2 name={'arrow-right-thin-circle-outline'} size={16} style={{ color:appColors.dark500 }} />
                  </View>
                </View>
              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>
      {/* <View style={[styles.btnContainer]}>
        <TouchableOpacity
          style={styles.Authbtn}
          onPress={() => navigation.navigate('addReminder')}>
          <Text style={styles.Authbtntext}>
            Add Reminder
          </Text>
        </TouchableOpacity>
      </View> */}
      <TouchableOpacity
        onPress={() => navigation.navigate('addReminder')}
        style={styles.iconPlus}>
        <Icon name="add" size={30} color="white" />
      </TouchableOpacity>
    </>
  );
}

export default Index;
