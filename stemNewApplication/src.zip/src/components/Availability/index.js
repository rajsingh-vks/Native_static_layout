import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Switch,
  StyleSheet,
  TouchableOpacity,
  RefreshControl,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';

import Header from '../Header';
import styles from '../../utils/styles';
import Input from '../Common/Input';
import { formatTime, showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import api from '../../services/api';
import { getUser } from '../../redux/userSlice';
import { getRefresh } from '../../redux/refreshSlice';
import { setSpinner } from '../../redux/appSlice';

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const Index = () => {
  const user = useSelector(getUser);
  const dispatch = useDispatch();
  const refresh = useSelector((state) => getRefresh(state, 'availabilities'));
  const [availability, setAvailability] = useState(
    days.map(() => ({
      is_available: false,
      start_time: '00:00',
      end_time: '23:59',
    }))
    
  );


  const getAvailability = async () => {
    dispatch(setSpinner(true));

    try {
      
      const response = await api.getAvailability(user?.id);

      if (response?.status === 200) {
        const list = response?.data || [];

        setAvailability(
          days.map((day, index) => ({
            is_available: list[index]?.is_available || false,
            start_time: formatTime(list[index]?.start_time) || '00:00',
            end_time: formatTime(list[index]?.end_time) || '23:59',
          }))
        );
      } else {
        showErrorToast(response?.data?.message);
      }
    } catch (error) {
      showErrorToast('Failed to fetch availabilities');
    } finally {
      dispatch(setSpinner(false));

    }
  };

  useEffect(() => {
    getAvailability();
  }, [refresh]);

  const toggleAvailability = (index) => {
    setAvailability((prev) =>
      prev.map((item, i) =>
        i === index
          ? {
            ...item,
            is_available: !item.is_available,
            ...(item.is_available
              ? { start_time: '00:00', end_time: '00:00' }
              : {}),
          }
          : item
      )
    );
  };

  const updateAvailability = (index, field, value) => {
    setAvailability((prev) =>
      prev.map((item, i) => (i === index ? { ...item, [field]: value } : item))
    );
  };

  const handleSaveAvailability = async () => {
    try {
      dispatch(setSpinner(true));
      const formattedData = availability.map((item, index) => ({
        day: index + 1,
        is_available: item.is_available,
        start_time: item.is_available ? item.start_time : '00:00',
        end_time: item.is_available ? item.end_time : '00:00',
      }));

      const formData = new FormData();
      formData.append('guard_id', user?.id)
      formData.append('availability_info', JSON.stringify(formattedData));


      const response = await api.updateAvailabilities(formData);
      if (response?.status) {
        showSuccessToast(response?.message);
        getAvailability();
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      console.error(error);
      showErrorToast('An error occurred while saving availability settings');
    }
    finally {
      dispatch(setSpinner(false));
    }
  };

  return (
    <>
      <Header title="Availability" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl refreshing={false} onRefresh={getAvailability} />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 50 }}
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.settingTitle}>AVAILABILITY</Text>
          {days.map((day, index) => (
            <View key={day} style={istyles.dayContainer}>
              <View style={istyles.switchRow}>
                <Text style={istyles.dayText}>{day}</Text>
                <Switch
                  value={availability[index]?.is_available}
                  onValueChange={() => toggleAvailability(index)}
                  thumbColor={availability[index]?.is_available ? '#4caf50' : '#ffc107'}
                  trackColor={{ false: '#d6d6d6', true: '#81c784' }}
                />
              </View>
              {availability[index]?.is_available && (
                <View style={istyles.timeRow}>
                  <View style={istyles.inputGroup}>
                    <Text style={istyles.inputLabel}>START TIME</Text>
                    <Input
                      type="time"
                      placeholder="00:00"
                      iconName="time-outline"
                      value={availability[index]?.start_time}
                      onChange={(start) =>
                        updateAvailability(index, 'start_time', start)
                      }
                    />
                  </View>
                  <View style={istyles.inputGroup}>
                    <Text style={istyles.inputLabel}>END TIME</Text>
                    <Input
                      type="time"
                      placeholder="23:59"
                      iconName="time-outline"
                      value={availability[index]?.end_time}
                      onChange={(end) => {
                        if (end > availability[index]?.start_time) {
                          updateAvailability(index, 'end_time', end);
                        } else {
                          showErrorToast('End time must be greater than start time');
                        }
                      }}
                    />
                  </View>
                </View>
              )}
            </View>
          ))}

        </ScrollView>
      </View>
      <View style={[styles.btnContainer]}>
        <TouchableOpacity style={styles.Authbtn} onPress={handleSaveAvailability}>
          <Text style={styles.Authbtntext}>Save</Text>
        </TouchableOpacity>
      </View>
    </>
  );
};

const istyles = StyleSheet.create({
  dayContainer: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 15,
    marginVertical: 5,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 2,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
  },
  inputGroup: {
    flex: 1,
    marginHorizontal: 5,
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#666',
    marginBottom: 5,
  },
});

export default Index;
