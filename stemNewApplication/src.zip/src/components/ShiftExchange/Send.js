import React from "react";
import { View, Text, RefreshControl, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import styles from "../../utils/styles";
import SpaceBox from '../Common/SpaceBox';
import { useNavigation } from "@react-navigation/native";

function SendRoute() {
  const navigation = useNavigation();
  return (
    <>
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>
          <View>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
              onPress={() => navigation.navigate('shiftsExchangeRequest')}
            >
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc', left: '0', height: '60%', top: '40%' }]}></View>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={[{ flexDirection: 'row' }]}>
                    <Text style={[styles.companyName, { fontSize: 18, flex: 1 }]}>
                      # 1607
                    </Text>
                    <TouchableOpacity style={[styles.companyName, {backgroundColor: '#B8C7FF', borderRadius: 4, paddingVertical: 4, paddingHorizontal: 8}]}>
                      <Text style={{ color: '#2360FB' }}>Pending</Text>
                    </TouchableOpacity>
                  </View>
                  <SpaceBox height={5} />
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 30, height: 30, marginRight: 12 }]}>
                      <Icon2
                        name={'calendar'}
                        size={20}
                        style={{ color: '#1d61f4' }}
                      />
                    </View>
                    <Text style={[styles.companyEmail, { marginTop: 2, fontSize: 16 }]}>
                      Mon, Apr 01, 2024 14:51:45
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Sender Name</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>John Walk</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Receiver Name</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>William Smith</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Sender Shift Duration</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>1hr 30min</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Receiver Shift Duration</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>1hr 30min</Text>
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
              onPress={() => navigation.navigate('shiftsExchangeRequest')}
            >
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc', left: '0', height: '60%', top: '40%' }]}></View>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={[{ flexDirection: 'row' }]}>
                    <Text style={[styles.companyName, { fontSize: 18, flex: 1 }]}>
                      # 1607
                    </Text>
                    <TouchableOpacity style={[styles.companyName, {backgroundColor: '#FFE2E0', borderRadius: 4, paddingVertical: 4, paddingHorizontal: 8}]}>
                      <Text style={{ color: '#FF3B30' }}>Rejected</Text>
                    </TouchableOpacity>
                  </View>
                  <SpaceBox height={5} />
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 30, height: 30, marginRight: 12 }]}>
                      <Icon2
                        name={'calendar'}
                        size={20}
                        style={{ color: '#1d61f4' }}
                      />
                    </View>
                    <Text style={[styles.companyEmail, { marginTop: 2, fontSize: 16 }]}>
                      Mon, Apr 01, 2024 14:51:45
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Sender Name</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>John Walk</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Receiver Name</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>William Smith</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Sender Shift Duration</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>1hr 30min</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Receiver Shift Duration</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>1hr 30min</Text>
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
              onPress={() => navigation.navigate('shiftsExchangeRequest')}
            >
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc', left: '0', height: '60%', top: '40%' }]}></View>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={[{ flexDirection: 'row' }]}>
                    <Text style={[styles.companyName, { fontSize: 18, flex: 1 }]}>
                      # 1607
                    </Text>
                    <TouchableOpacity style={[styles.companyName, {backgroundColor: '#DFFFE4', borderRadius: 4, paddingVertical: 4, paddingHorizontal: 8}]}>
                      <Text style={{ color: '#0DA927' }}>Approved</Text>
                    </TouchableOpacity>
                  </View>
                  <SpaceBox height={5} />
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 30, height: 30, marginRight: 12 }]}>
                      <Icon2
                        name={'calendar'}
                        size={20}
                        style={{ color: '#1d61f4' }}
                      />
                    </View>
                    <Text style={[styles.companyEmail, { marginTop: 2, fontSize: 16 }]}>
                      Mon, Apr 01, 2024 14:51:45
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Sender Name</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>John Walk</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Receiver Name</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>William Smith</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Sender Shift Duration</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>1hr 30min</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Receiver Shift Duration</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>1hr 30min</Text>
                </View>
              </View>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

export default SendRoute