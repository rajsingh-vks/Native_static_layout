import React from "react";
import { View, Text, RefreshControl, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import Header from '../Header';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import styles from "../../utils/styles";
import SpaceBox from '../Common/SpaceBox';
import { useNavigation } from "@react-navigation/native";
import SlidingTabs from "./SlidingTabs";

function ShiftsExchange() {
  const navigation = useNavigation();

  return (
    <>
      <Header title='Shifts Exchange' />
      <SlidingTabs />
    </>
  );
}

export default ShiftsExchange;