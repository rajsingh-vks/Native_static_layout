import React, { useState } from "react";
import { Dimensions } from "react-native";
import { TabView, SceneMap, TabBar } from "react-native-tab-view";
import SendRoute from "./Send";
import ReceivedRoute from "./Received";

const initialLayout = { width: Dimensions.get("window").width };

const SlidingTabs = () => {
  const [index, setIndex] = useState(0);
  const [routes] = useState([
    { key: "send", title: "SENT" },
    { key: "received", title: "RECEIVED" },
  ]);

  const renderScene = SceneMap({
    send: SendRoute,
    received: ReceivedRoute,
  });

  return (
    <TabView
      navigationState={{ index, routes }}
      renderScene={renderScene}
      onIndexChange={setIndex}
      initialLayout={initialLayout}
      renderTabBar={(props) => (
        <TabBar {...props} 
          indicatorStyle={{ backgroundColor: "#2360FB" }} 
          style={{ backgroundColor: "#F5F5F1", fontWeight: 'bold' }}
          labelStyle={{ color: '#000E42' }}
          activeColor="#000" 
          inactiveColor="#000E42" />
      )}
    />
  );
};

export default SlidingTabs;