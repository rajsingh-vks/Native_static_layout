import {useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import { useNavigation } from '@react-navigation/native';
import { getLogout, setLogout } from '../redux/logoutSlice';

const LogoutListner = () => {
  const logout = useSelector(getLogout);
  const navigation = useNavigation();
  const dispatch = useDispatch();

  useEffect(() => {
    if (navigation && logout === true) {
      try {
        navigation.reset({index: 0, routes: [{name: 'Login'}]});
        dispatch(setLogout(false));
      } catch (error) {
        console.log('Logout Listner Error: ', error.message);
      }
    }
  }, [logout]);

  return null;
};

export default LogoutListner;