import React, { useState, useEffect, useRef } from 'react';
import { Keyboard, KeyboardAvoidingView, Text, TextInput, TouchableOpacity, TouchableWithoutFeedback, StyleSheet, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Label } from '@react-navigation/elements';
import axios from 'axios';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import env from '../services/env';
import api from '../services/api';
import OtpTimer from './Common/OtpTimer';
import { setSpinner } from '../redux/appSlice';
import { showErrorToast, showSuccessToast, showPopup } from '../utils/appHelpers';
import appColors from '../utils/appColors';
import styles from '../utils/styles';

const UserOTP = ({route}) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const { type, token: initialToken, email, phone, country_code } = route.params || {};
  const [token, setToken] = useState(initialToken);
  const [timer, setTimer] = useState(30);
  const [userotp, setUserotp] = useState('');
  const [resend, setResend] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [disabled, setDisabled] = useState(true);
  const [loader, setLoader] = useState(false);
  const [keyboardHeight, setKeyboardHeight] = useState(0);

  const [otp1, setOTP1] = useState('');
  const [otp2, setOTP2] = useState('');
  const [otp3, setOTP3] = useState('');
  const [otp4, setOTP4] = useState('');

  const ref1 = useRef(null);
  const ref2 = useRef(null);
  const ref3 = useRef(null);
  const ref4 = useRef(null);

  const validateOTP = async () => {
    dispatch(setSpinner(true));

    let formData = new FormData();
    formData.append('otp', userotp);
    if (type === 'email') {
      formData.append('verify_type', '1');
    } else {
      formData.append('verify_type', '2');
    }

    try {
      let response = await api.validateOTP(formData, token);
      if (response?.status == 200) {
        navigation.replace('ResetPassword',{
          token: response?.data?.token,
        });
      } else {
        showErrorToast(response?.message || 'OTP validation failed, Contact support.');
      }

      dispatch(setSpinner(false));
      setDisabled(false);
    } catch (error) {
      dispatch(setSpinner(false));
      setDisabled(false);
      showErrorToast("OTP validation error, Contact support.");
      console.log(JSON.stringify(error, null, 5));
    }
  }

  const resendOTP = async () => {
    Keyboard.dismiss();
    dispatch(setSpinner(true));

    let formData = new FormData();
    if (type === 'email') {
      formData.append('email', email ?? "");
    } else {
      formData.append("mobile_no", phone ?? "");
      formData.append("country_code", country_code ?? "");
    }
    formData.append('role_id', 4);

    api
    .forgotPassword(formData)
    .then(async res => {
      dispatch(setSpinner(false));
      if (res?.status == '200') {
        showSuccessToast(res?.message);
      } else {
        setError(res?.data?.message);
      }
    })
    .catch(function (error) {
      dispatch(setSpinner(false));
      showErrorToast(error?.data?.message);
    })
  };

  useEffect(() => {
    if(userotp !=''){
      setDisabled(false);
    }else{
      setDisabled(true);
    }
  }, [userotp]);

  useEffect(() => {
    let otp = '';
    if (otp1 != '' && otp2 != '' && otp3 != '' && otp4 != '') {
      otp = otp1 + otp2 + otp3 + otp4;
      setUserotp(otp);
    }
    if(otp1 == '' || otp2 == '' || otp3 == '' || otp4 == ''){
      setUserotp('');
    }
  }, [otp1, otp2, otp3, otp4]);

  useEffect(() => {
    setUserotp('');
  }, []);

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      Platform.OS === 'android' ? 'keyboardDidShow' : 'keyboardWillShow',
      (event) => {
        setKeyboardHeight(40);
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      Platform.OS === 'android' ? 'keyboardDidHide' : 'keyboardWillHide',
      () => {
        setKeyboardHeight(0);
      }
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor:'#FFF' }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.authContainer}>
          <TouchableOpacity
            style={[styles.drawerTouch, {backgroundColor:'transparent', borderColor:'#ccc', borderWidth:1}]}
            onPress={() => navigation.navigate('Forgot')}>
              <Icon name='arrow-left' style={[styles.drawerIcon, {color: '#2c3f83'}]}/>
          </TouchableOpacity>

          <View style={[{alignItems:'center', paddingHorizontal:10}]}>
            <Text style={[styles.authTitle]}>OTP Verification</Text>
            {type == 'email'?(
              <Text style={[styles.authsubtitle, {fontSize:16}]}>To verify your email, Please Enter OTP that has been sent to your email {email}.</Text>
            ):(
              <Text style={[styles.authsubtitle, {fontSize:16}]}>To verify your phone, Please Enter OTP that has been sent to your phone number +{country_code}{phone}.</Text>
            )}
          </View>

          {/* <>OTP Start</> */}
          <View style={[styles.container, {paddingHorizontal:10}]}>
            <View
              style={[
                iStyles.inputwrapper,
                {flexDirection: 'row', marginBottom: 5, marginTop:20, alignItems: 'center'},
              ]}>
              <TextInput
                style={[
                  iStyles.input,
                  {
                    borderColor: ref1.current ? '#2296d2' : '#cccccc',
                    fontSize: 17,
                    marginRight: 10,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    textAlign: 'center',
                    height: 40,
                    width: 40,
                  },
                ]}
                placeholder="#"
                placeholderTextColor="#AAAAAA"
                autoFocus={true}
                maxLength={1}
                returnKeyType="done"
                numeric
                keyboardType={'number-pad'}
                value={otp1}
                ref={ref => (ref1.current = ref)}
                onChangeText={value => {
                  if (value.length > 0) {
                    setOTP1(value);
                    ref2.current?.focus();
                  } else if (value.length == 0) {
                    setOTP1(value);
                  }
                }}
              />
              <TextInput
                style={[
                  iStyles.input,
                  {
                    borderColor: '#2296d2',
                    fontSize: 17,
                    marginRight: 10,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    textAlign: 'center',
                    height: 40,
                    width: 40,
                  },
                ]}
                placeholder="#"
                placeholderTextColor="#AAAAAA"
                maxLength={1}
                returnKeyType="done"
                numeric
                keyboardType={'number-pad'}
                value={otp2}
                ref={ref => (ref2.current = ref)}
                onChangeText={value => {
                  if (value.length > 0) {
                    setOTP2(value);
                    ref3.current?.focus();
                  } else if (value.length == 0) {
                    setOTP2(value);
                  }
                }}
                onKeyPress={({nativeEvent}) => {
                  if (nativeEvent.key === 'Backspace') {
                    if (otp2.length == 0) {
                      ref1.current?.focus();
                    }
                  }
                }}
              />
              <TextInput
                style={[
                  iStyles.input,
                  {
                    borderColor: '#2296d2',
                    fontSize: 17,
                    marginRight: 10,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    textAlign: 'center',
                    height: 40,
                    width: 40,
                  },
                ]}
                placeholder="#"
                placeholderTextColor="#AAAAAA"
                maxLength={1}
                returnKeyType="done"
                numeric
                keyboardType={'number-pad'}
                value={otp3}
                ref={ref => (ref3.current = ref)}
                onChangeText={value => {
                  if (value.length > 0) {
                    setOTP3(value);
                    ref4.current?.focus();
                  } else if (value.length == 0) {
                    setOTP3(value);
                  }
                }}
                onKeyPress={({nativeEvent}) => {
                  if (nativeEvent.key === 'Backspace') {
                    if (otp3.length == 0) {
                      ref2.current?.focus();
                    }
                  }
                }}
              />
              <TextInput
                style={[
                  iStyles.input,
                  {
                    borderColor: '#2296d2',
                    fontSize: 17,
                    marginRight: 10,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    textAlign: 'center',
                    height: 40,
                    width: 40,
                  },
                ]}
                placeholder="#"
                placeholderTextColor="#AAAAAA"
                maxLength={1}
                returnKeyType="done"
                numeric
                keyboardType={'number-pad'}
                value={otp4}
                ref={ref => (ref4.current = ref)}
                onChangeText={value => {
                  setOTP4(value);
                }}
                onKeyPress={({nativeEvent}) => {
                  if (nativeEvent.key === 'Backspace') {
                    if (otp4.length == 0) {
                      ref3.current?.focus();
                    }
                  }
                }}
              />
            </View>
            {typeof error == 'string' && (
              <Text style={[styles.errMsg, {textAlign: 'left'}]}>{error}</Text>
            )}

            {/* <>Resend Start</> */}
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                height: 80,
                marginVertical: 5,
              }}>
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: '400',
                  textAlign: 'left',
                  marginRight: 5,
                }}>
                Didn't receive the OTP?
              </Text>
              {resend == false && (
                <OtpTimer
                  active={true}
                  timer={timer}
                  onComplete={complete => {
                    setResend(complete);
                  }}
                />
              )}

              {resend == true && (
                <TouchableOpacity
                  disabled={submitted}
                  onPress={() => {
                    resendOTP();
                  }}
                  style={styles.btnTrans}>
                  <Text style={{fontSize:16, fontWeight:'600'}}>Resend</Text>
                  {loader && (
                    <ActivityIndicator
                      size={10}
                      color="black"
                      style={styles.ms10}
                    />
                  )}
                </TouchableOpacity>
              )}
            </View>
            {/* <>Resend End</> */}
          </View>
          {/* <>OTP End</> */}          

          <View style={[styles.btnContainer, {marginHorizontal:10, bottom: keyboardHeight}]}>
            <TouchableOpacity
              style={disabled ? styles.disabledBtn : styles.Authbtn}
              onPress={validateOTP} disabled={disabled}>
              <Text style={styles.Authbtntext}>
                VERIFY OTP
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

export default UserOTP;

const iStyles = StyleSheet.create({
  inputwrapper: {
    height: 50,
    overflow: 'hidden',
    position: 'relative',
  },
  input: {
    borderColor: appColors.gray,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: 'white',
  },

})