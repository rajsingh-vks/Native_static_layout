import * as React from 'react';
import { View, Text, ScrollView, TouchableOpacity, RefreshControl, ImageBackground } from 'react-native';
import { useNavigation } from '@react-navigation/native';

import Header from '../Header';
import styles from '../../utils/styles';

function AboutUs() {
  const navigation = useNavigation();

  return (
    <>
      <Header title="About Us" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
            />
          }
          contentContainerStyle={{ flexGrow: 1 }}>
          <View>
            <Text style={[styles.companyEmail, { marginBottom: 15, textAlign: "justify", lineHeight: 20  }]}>
              This app is a greate addition for any roomin your home. not only just the living room,Featuring a mid-century design with. this ca greate addition for any room this chair is addition for any room in your home. not onl the living room, Featuring a mid-century dwith. this chair is a greate addition for any.
            </Text>
            <Text style={[styles.companyEmail, { marginBottom: 15, textAlign: "justify", lineHeight: 20  }]}>
              This app is a greate addition for any roomin your home. not only just the living room,Featuring a mid-century design with. this ca greate addition for any room this chair is addition for any room in your home. not onl the living room, Featuring a mid-century dwith. this chair is a greate addition for any.
            </Text>
            <Text style={[styles.companyEmail, { marginBottom: 15, textAlign: "justify", lineHeight: 20  }]}>
              This app is a greate addition for any roomin your home. not only just the living room,Featuring a mid-century design with. this ca greate addition for any room this chair is addition for any room in your home. not onl the living room, Featuring a mid-century dwith. this chair is a greate addition for any.
            </Text>
            <Text style={[styles.companyEmail, { marginBottom: 15, textAlign: "justify", lineHeight: 20  }]}>
              This app is a greate addition for any roomin your home. not only just the living room,Featuring a mid-century design with. this ca greate addition for any room this chair is addition for any room in your home. not onl the living room, Featuring a mid-century dwith. this chair is a greate addition for any.
            </Text>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

export default AboutUs