import React, { useState, useEffect } from 'react';
import {Alert, View, Text, Image, TextInput, TouchableOpacity, Keyboard, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { useDispatch } from 'react-redux';
import DeviceInfo from 'react-native-device-info';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Label } from '@react-navigation/elements';
import PhoneInput from 'react-native-international-phone-number';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Input from './Common/Input';
import SpaceBox from './Common/SpaceBox';
import api from '../services/api';
import constants from '../utils/constants';
import validateForm from '../utils/validateForm';
import { setUser } from '../redux/userSlice';
import { hidePopup, showErrorToast, showPopup } from '../utils/appHelpers';
import { setSpinner } from '../redux/appSlice';
import appColors from '../utils/appColors';
import styles from '../utils/styles';

const Login = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [selectedRadio, setSelectedRadio] = useState(2);
  const [activeTab, setActiveTab] = useState('email');
  const [eyeIcon, setEyeIcon] = useState('eye-off');
  const [passVisible, setPassVisible] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState({ callingCode: '', cca2: '', flag: '' });
  const [flag, setCountryFlag] = useState('');
  const [remember, setRemember] = useState(false);
  const [keyboardHeight, setKeyboardHeight] = useState(0);
  const [disabled, setDisabled] = useState(true);
  const [error, setError] = useState(null);
    
  const [fields, setFields] = useState({
    email: '',
    mobile_no: '',
    password: '',
    country_code: '',
    country_iso_code: '',
  });
  const rules_email = {
    email: ['required', 'email'],
    password: ['required', 'string'],
  };
  const rules_mobile = {
    mobile_no: ['required', 'string', 'digits:10'],
    country_code: ['required', 'string'],
    country_iso_code: ['required', 'string'],
    password: ['required', 'string'],
  };

  // Handle form Tab
  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  // Show Hide Password
  const showPassword = () => {
    if(passVisible){
      setPassVisible(false);
      setEyeIcon('eye-off');
    }else{
      setPassVisible(true);
      setEyeIcon('eye');
    }
  }

  const handleRemember = () => {
    if(remember){
      setRemember(false);
    }else{
      setRemember(true);
    }
  }

  // Handle form inputs
  const handleInputChange = (field, value) => {
    setFields((prevState) => ({ ...prevState, [field]: value }));
  };

  const handlePhoneInputChange = (phoneNumber) => {
    setFields((prevState) => ({ ...prevState, mobile_no: phoneNumber.replace(/\s+/g, '') }));
  };

  const handleSelectedCountryChange = (country) => {
    console.log(country, 'country');
    setSelectedCountry(country);
    setFields((prevState) => ({
      ...prevState,
      country_code: country?.callingCode.replace('+', '') || '',
      country_iso_code: country?.cca2 || '',
      flag: country?.flag || '',
    }));
    setCountryFlag(country?.flag || '');
  };

  const handleLogin = async () => {
    Keyboard.dismiss();
    setError(null);
    dispatch(setSpinner(true));

    let rules;
    if(activeTab == 'email'){
      rules = rules_email;
    }else{
      rules = rules_mobile;
    }

    let valStat = validateForm(fields, rules);
    if(valStat?.status == true){
      let formData = new FormData();
      if (activeTab === 'email') {
        formData.append('email', fields.email);
      } else {
        formData.append("mobile_no", fields.mobile_no ?? "");
        formData.append("country_code", fields.country_code ?? "");
        formData.append("country_iso_code", fields.country_iso_code ?? "");
      }
      formData.append('password', fields.password);
      formData.append('role_id', 4);

      api
      .userLogin(formData)
      .then(async res => {
        dispatch(setSpinner(false));
        
        if(res?.verify == true){
          Alert.alert('Account Verification', 'Your account verification pending. Proceed to verify your account.', [
            {text: 'Cancel',},
            {text: 'Verify', onPress: () => sendVerificationOTP(res)},
          ]);
        }else{
          setUserReduxStore(res)
        }
      })
      .catch(function (error) {
        let errorMsg;
        if(error?.data){
          errorMsg = error?.data?.message;
        }else{
          errorMsg = 'Something went wrong. Contact Support.'
        }
        dispatch(setSpinner(false));
        showErrorToast(errorMsg);
      })
      .finally(() => {
        dispatch(setSpinner(false));
        setDisabled(false);
      })
    }else{
      dispatch(setSpinner(false));
      showPopup('error', 'Please check login credentials.');
    }
  };

  const sendVerificationOTP = async (res) => {
    dispatch(setSpinner(true));

    let formData = new FormData();
    formData.append('role_id', 4);
    api
      .guardVerifyOTP(formData, res?.data?.token)
      .then(async res => {
        dispatch(setSpinner(false));
        
        if (res?.status == '200') {
          let vType = '';
          if(res?.data?.is_mobile_verified != 1){
            vType = 'phone';
          }else if(res?.data?.is_email_verified != 1){
            vType = 'email';
          }

          navigation.navigate('VerifyOTP', {
            type: vType,
            token: res?.data?.token,
            email: res?.data?.email,
            phone: res?.data?.mobile_no,
            country_code: res?.data?.country_code,
            message: res?.message,
          });
          setFields({});
        }else{
          console.log(res?.message);
        }
      })
      .catch(function (error) {
        let errorMsg;
        if(error?.data){
          errorMsg = error?.data?.message;
        }else{
          errorMsg = 'Something went wrong. Contact Support.'
        }
        dispatch(setSpinner(false));
        showErrorToast(errorMsg);
      })
      .finally(() => {
        dispatch(setSpinner(false));
        setDisabled(false);
      })
  }

  const setUserReduxStore = async (res) => {
    if (res?.data) {
      if (res.data?.token) {
        // Load user data in redux
        dispatch(setUser(res.data));
        
        // Save credential if remember me is checked
        if (remember) {
          AsyncStorage.setItem(
            constants.storageKeys.LOGIN,
            JSON.stringify({
              email: fields.email || '',
              mobile_no: fields.mobile_no || '',
              password: fields.password || '',
            }),
          );
        } else {
          AsyncStorage.removeItem('login');
        }

        // Save App current version
        const currentVersion = DeviceInfo.getVersion();
        await AsyncStorage.setItem(constants.storageKeys.VERSION, currentVersion);

        // Remove logout status
        await AsyncStorage.removeItem('logout');

        // Navigate to dashboard
        navigation.reset({ index: 0, routes: [{ name: 'DrawerNavigation' }] });
      } else {
        showErrorToast('Invalid login details.');
      }
    } else {
      showErrorToast('Invalid login details.');
    }
  }

  // Check if login detail saved.
  const getSavedLogin = async () => {
    try {
      let login = await AsyncStorage.getItem(constants.storageKeys.LOGIN);
      
      if (login) {
        login = await JSON.parse(login);
        if( login?.password != '' && (login?.email != '' || login?.mobile_no != '')){
          setFields({ ...fields, ...login});
          setRemember(true);
        }
      }
    } catch (error) {
      console.log(JSON.stringify(error, null, 5))
    }
  };

  // Check field value changes
  useEffect(() => {
    let rules;
    if(activeTab == 'email'){
      rules = rules_email;
    }else{
      rules = rules_mobile;
    }
    
    let valStat = validateForm(fields, rules);
    if(valStat?.status == true){
      setDisabled(false);
    }else{
      setDisabled(true);
    }
  }, [fields]);

  // Initial Load actions
  useEffect(() => {
    hidePopup();
    getSavedLogin();
  }, []);

  // Keyboard Height Manage
  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      Platform.OS === 'android' ? 'keyboardDidShow' : 'keyboardWillShow',
      (event) => {
        setKeyboardHeight(20);
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      Platform.OS === 'android' ? 'keyboardDidHide' : 'keyboardWillHide',
      () => {
        setKeyboardHeight(0);
      }
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);
  
  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, backgroundColor:'#FFF'}} 
        keyboardShouldPersistTaps="handled">

        <View style={[styles.container, {paddingTop:0}]}>
          <View style={[styles.authImageWrapper, {flex:1}]}>
            <Image
              source={require('../assets/images/ic_login.png')}
              style={styles.authImage}
            />
          </View>

          <View style={styles.auth}>
            <Text style={styles.authTitle}>Welcome</Text>
            <Text style={styles.authsubtitle}>Sign in to continue</Text>

            <View style={{ flexDirection: 'row' }}>
              <TouchableOpacity onPress={() => [handleTabChange('email'), setSelectedRadio(2)]} style={styles.radioWrapper}>
                  <View style={[styles.radio, {marginLeft:0}]}>
                      {
                        selectedRadio === 2 ? <View style={styles.radioBg}></View> : null
                      }
                  </View>
                  <Text>With Email</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => [handleTabChange('phone'), setSelectedRadio(1)]} style={styles.radioWrapper}>
                  <View style={[styles.radio, {marginLeft:0}]}>
                      {
                        selectedRadio === 1 ? <View style={styles.radioBg}></View> : null
                      }
                  </View>
                  <Text>With Phone</Text>
              </TouchableOpacity>
            </View>
          </View>

          {activeTab === 'phone' ? (
            <View style={{ marginVertical: 5 }}>
              <Label style={styles.label}>Phone Number</Label>
              <PhoneInput
                defaultCountry="US"
                selectedCountry={selectedCountry}
                onChangePhoneNumber={(value) => handlePhoneInputChange(value)}
                onChangeSelectedCountry={handleSelectedCountryChange}
                placeholder="Enter phone number"
                containerStyle={{
                  backgroundColor: '#fff',
                  padding: 10,
                }}
                textInputStyle={{
                  fontSize: 16,
                }}
                flagStyle={{
                  width: 100,
                  height: 20,
                }}
                phoneInputStyles={{
                  container: {
                    borderColor: '#ccc',
                  },
                }}
              />
            </View>
          ) : (
            <View style={{ marginVertical: 5 }}>
              <Input 
                type='text'
                label='Email'
                value={fields.email}
                leftIcon={<Icon name="email" size={20} color={appColors.iconColor}/>}
                placeholder="Enter your email"
                placeholderTextColor="#CDCDCD"
                inputStyle={{paddingHorizontal:5}}
                onChangeText={(value) => handleInputChange('email', value)}
              />
            </View>
          )}
          <View style={{ marginVertical: 5 }}>
            <Input 
              type='text'
              label='Password'
              value={fields.password}
              leftIcon={<Icon name="lock" size={20} color={appColors.iconColor}/>}
              rightIcon={
                <Icon name={eyeIcon} size={20} color={appColors.iconColor} onPress={()=>showPassword()}/>
              }
              placeholder="Enter your password"
              placeholderTextColor="#CDCDCD"
              secureTextEntry={!passVisible}
              inputStyle={{paddingHorizontal:5}}
              onChangeText={(value) => handleInputChange('password', value)}
            />
          </View>

          <View style={{ flexDirection: 'row', marginVertical: 10, marginHorizontal:2}}>
            <Input type='checkbox' value='Remember me' isChecked={remember} onPress={() => handleRemember()}/>
            <TouchableOpacity style={{ justifyContent: 'center' }} onPress={() => navigation.navigate('Forgot')}>
              <Text style={[styles.label]}>Forgot Password</Text>
            </TouchableOpacity>
          </View>
          <SpaceBox height={20}/>

          <View style={[styles.btnContainer, {bottom: keyboardHeight, height:'auto', marginHorizontal:0}]}>
            <TouchableOpacity
              style={[disabled ? styles.disabledBtn : styles.Authbtn, {height:50}]}
              onPress={handleLogin} disabled={disabled}>
              <Text style={styles.Authbtntext}>Confirm</Text>
            </TouchableOpacity>
            <View style={[styles.authBottom, {marginVertical:10}]}>
              <Text>Don't have an account?</Text> 
              <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
                <Text style={{ fontWeight: 'bold', color: 'red' }}> Sign up</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

export default Login;