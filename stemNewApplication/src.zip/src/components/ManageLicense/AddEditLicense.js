import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import DocumentPicker from "react-native-document-picker";
import Header from "../Header";
import Input from "../Common/Input";
import api from "../../services/api";
import { setSpinner } from "../../redux/appSlice";
import { showErrorToast, showSuccessToast } from "../../utils/appHelpers";
import moment from "moment";
import { getUser } from "../../redux/userSlice";
import validateForm from "../../utils/validateForm";
import styles from "../../utils/styles";
import SelectComponent from "../Common/SelectComponent";
import DateComponent from "../Common/DateComponent";

function AddEditLicense({ route, navigation }) {
  const { license } = route.params || {};

  console.log(license, "DATA");


  const [disabled, setDisabled] = useState(true);
  const [licenseType, setLicenseType] = useState([]);
  const [fields, setFields] = useState({
    license_no: license?.license_number,
    expire_date: license?.expired_on ? moment(license.expired_on, "YYYY-MM-DD").toDate() : null,
    license_type_id: license?.license_type?.id || null,
    image: license?.image || null,
  });

  const user = useSelector(getUser);
  const dispatch = useDispatch();
  const rules_licenses = {
    license_no: ["required", "string"],
    license_type_id: ["required", "number"],
    expire_date: ["required", "date"],
  };

  useEffect(() => {
    const getLicenseType = async () => {
      try {
        const response = await api.guardLicenseTypeListing();
        const formattedData = response?.data?.map((item) => ({
          label: item.license_name,
          value: item.id,
        })) ?? [];

        setLicenseType(formattedData);


      } catch (error) {
        console.error(error?.data?.message);
      }
    };
    getLicenseType();
  }, []);


  const handleInputChange = (field, value) => {
    setFields((prevState) => ({ ...prevState, [field]: value }));
  };

  const handleImageUpload = async () => {
    try {
      const result = await DocumentPicker.pickSingle({
        type: [DocumentPicker.types.images],
      });

      setFields((prevState) => ({
        ...prevState,
        image: {
          uri: result.uri,
          type: result.type,
          name: result.name,
        },
      }));
    } catch (error) {
      if (DocumentPicker.isCancel(error)) {
        console.log("User canceled the document picker");
      } else {
        console.error("Error selecting document:", error);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    dispatch(setSpinner(true));

    try {
      let formData = new FormData();
      formData.append("guard_id", user?.id);
      license?.id && formData.append("license_id", license?.id);
      formData.append("license_type_id", fields?.license_type_id);
      formData.append("license_no", fields?.license_no);
      formData.append("expire_date", fields?.expire_date);

      if (fields?.image?.uri && fields?.image?.type && fields?.image?.name) {
        formData.append("image", {
          uri: fields.image.uri,
          type: fields.image.type,
          name: fields.image.name,
        });
      }

      const response = license?.id
        ? await api.updateguardLicense(formData)
        : await api.addGuardLicense(formData);

      if (response?.status) {
        showSuccessToast(response?.message);
        // navigation.navigate('manageLicense');
        navigation.goBack();
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      console.error(error, "HELOO");
      showErrorToast(error?.data?.message);
    } finally {
      dispatch(setSpinner(false));
    }
  };

  useEffect(() => {
    let rules = rules_licenses;
    let valStat = validateForm(fields, rules);
    setDisabled(!valStat?.status);
  }, [fields]);

  return (
    <>
      <Header title={license?.id ? "Update License" : "Add License"} />

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, backgroundColor: "#FFF" }}
          keyboardShouldPersistTaps="handled"
        >
          <View style={[{ flex: 1, backgroundColor: "#fff" }]}>
            <View
              style={[
                styles.container,
                { boxShadow: "none", backgroundColor: "#fff", padding: 0 },
              ]}
            >
              <SelectComponent
                label="Select License Type"
                placeholder="License Type"
                options={licenseType}
                value={fields.license_type_id}
                required={true}
                // selectedOption={fields.license_type_id}
                onSelect={(selectedOption) => handleInputChange("license_type_id", selectedOption?.value)}
                />


              <View style={{ marginVertical: 5 }}>
                <Input
                  type="text"
                  label="License Number"
                  value={fields.license_no}
                  placeholder="Enter License Number"
                  required={true}
                  placeholderTextColor="#CDCDCD"
                  inputStyle={{ paddingHorizontal: 5 }}
                  onChangeText={(value) =>
                    handleInputChange("license_no", value)
                  }
                />
              </View>

              <DateComponent
                label="Expiry Date"
                value={fields.expire_date}
                required={true}
                placeholder="DD-MM-YYYY"
                minDate={moment().startOf("day").toISOString()}
                onChange={(expire_date) =>
                  handleInputChange("expire_date", expire_date)
                }
              />

              <View style={{ marginVertical: 5 }}>
                <Text style={styles.label}>License Image</Text>
                <View style={isStyles.attachmentBox}>
                  <TouchableOpacity
                    style={isStyles.uploadButton}
                    onPress={handleImageUpload}
                  >
                    <Image
                      source={{
                        uri: "https://img.icons8.com/ios-filled/50/upload-to-cloud.png",
                      }}
                      style={isStyles.uploadIcon}
                    />
                    <Text style={isStyles.uploadText}>Upload Document</Text>
                  </TouchableOpacity>
                  <Text style={isStyles.fileGuidelines}>
                    Allowed file types: jpeg, jpg, png (Max file size: 10MB)
                  </Text>
                </View>
                {fields.image && (
                  <View style={isStyles.imagePreview}>
                    <Image
                      source={{ uri: fields.image.uri }}
                      style={isStyles.image}
                    />
                    <Text style={isStyles.imageName}>{fields.image.name}</Text>
                  </View>
                )}
              </View>
            </View>
          </View>

          <View style={{ height: 50, marginBottom: 20, marginHorizontal: 15 }}>
            <TouchableOpacity
              style={disabled ? styles.disabledBtn : styles.Authbtn}
              disabled={disabled}
              onPress={handleSubmit}
            >
              <Text style={styles.Authbtntext}>Save License</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </>
  );
}

const isStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingHorizontal: 15,
    paddingTop: 20,
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 15,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 3,
  },
  label: {
    fontSize: 14,
    fontWeight: "600",
    color: "#333",
    marginBottom: 5,
  },
  pickerWrapper: {
    borderWidth: 1,
    borderColor: "#CDCDCD",
    borderRadius: 5,
  },
  inputGroup: {
    marginVertical: 5,
  },
  attachmentBox: {
    borderWidth: 1,
    borderColor: "#CDCDCD",
    borderStyle: "dashed",
    borderRadius: 5,
    padding: 15,
    alignItems: "center",
  },
  uploadButton: {
    flexDirection: "row",
    alignItems: "center",
  },
  uploadIcon: {
    width: 24,
    height: 24,
    marginRight: 10,
  },
  uploadText: {
    color: "#007BFF",
    fontSize: 16,
  },
  fileGuidelines: {
    color: "#888",
    fontSize: 12,
    marginTop: 10,
    textAlign: "center",
  },
  imagePreview: {
    marginTop: 15,
    alignItems: "center",
    backgroundColor: "#f8f9fa",
    padding: 10,
    borderRadius: 5,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 5,
    marginBottom: 10,
  },
  imageName: {
    fontSize: 12,
    color: "#666",
  },
  buttonContainer: {
    height: 50,
    marginBottom: 20,
  },
  authBtn: {
    backgroundColor: "#007BFF",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
  },
  authBtnText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
  disabledBtn: {
    backgroundColor: "#ccc",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
  },
});

export default AddEditLicense;
