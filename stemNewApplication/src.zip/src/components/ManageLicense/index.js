import { useCallback, useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, RefreshControl, ScrollView } from 'react-native';
import { convertUTCToLocal, PriorityStatus, showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import { showConfirmationBox } from '../Common/Confirmation';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { getRefresh } from '../../redux/refreshSlice';
import styles from '../../utils/styles';
import { getUser } from '../../redux/userSlice';
import appColors from '../../utils/appColors';
import SpaceBox from '../Common/SpaceBox';

const Index = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [licenses, setLicenses] = useState([]);
  const [isDataFetched, setIsDataFetched] = useState(false);
  const refresh = useSelector((state) => getRefresh(state, 'licenses'));
  const user = useSelector(getUser);

  const getLicenses = async () => {
    dispatch(setSpinner(true));
    try {
      const response = await api.guardLicenseListing(user?.id);

      if (response?.status == 200) {
        setLicenses(response.data ?? []);
      } else {
        setLicenses([]);
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message);
    } finally {
      setIsDataFetched(true);
      dispatch(setSpinner(false));
    }
  };

  const handleLicenseDelete = async (id) => {
    showConfirmationBox(
      'Delete License',
      'Are you sure you want to delete this License?',
      async () => {
        dispatch(setSpinner(true));
        try {
          const formData = new FormData();
          formData.append("license_id", [id]);

          const response = await api.deleteGuardLicense(formData);

          if (response.status == 200) {
            const updatedLicense = licenses.filter((item) => item.id !== id);
            setLicenses(updatedLicense);
            showSuccessToast(response?.message);
          } else {
            showErrorToast(response?.message);
          }
        } catch (error) {
          showErrorToast(error?.message);
        } finally {
          dispatch(setSpinner(false));
        }
      }
    );
  };



  useEffect(() => {
    getLicenses();
  }, [refresh]);


  useFocusEffect(
    useCallback(() => {
      getLicenses();

      return () => { };
    }, [])
  );

  return (
    <>
      <Header title="Licenses" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={() => getLicenses()}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 50 }}
          showsVerticalScrollIndicator={false}>
          {licenses?.length > 0 && <Text style={styles.settingTitle}>Licenses</Text>}

          {isDataFetched && licenses?.length === 0 ? (
            <View style={styles.noRecordsContainer}>
              <Image
                source={require('../../assets/images/not-found.png')}
                style={styles.noRecordsImage}
              />
              <Text style={styles.noRecordsText}>No Data Found</Text>
            </View>
          ) : (
            licenses?.map((license, index) => (
              <TouchableOpacity
                key={index}
                style={[styles.cardTab, { marginBottom: 10 }]}
                onPress={() => navigation.navigate('licenseDetails', { license })}>
                <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc' }]}></View>

                <View style={styles.tabDetails}>
                  <View style={styles.tabHeader}>
                    <Text style={styles.tabHeaderTitle}>
                      {license?.license_type?.license_name ?? '--'}
                    </Text>
                    <Text style={[styles.tabStatus, { backgroundColor: license?.status === '1' ? appColors.lightgreen : appColors.lightYellow }]}>
                      {license?.license_number ?? "--"}
                    </Text>
                  </View>
                  <SpaceBox height={2} />
                  <View style={styles.horizontalLine}></View>

                  <View style={[{ flexDirection: 'row' }]}>

                    <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                      <View style={[styles.tabIconCircle, { backgroundColor: '#e2eaff', marginTop: 1 }]}>
                        <Icon2 name={'calendar-month'} size={22} style={{ color: '#1d61f4' }} />
                      </View>
                      <View style={{ justifyContent: 'center' }}>
                        <Text style={styles.tabIconLabel}>
                          Date
                        </Text>
                        <SpaceBox height={3} />
                        <Text style={[styles.tabIconTitle, { color: '#000e42' }]}>
                          {convertUTCToLocal(license?.expired_on, 'MMM DD, YY', false)}
                        </Text>
                      </View>
                    </View>
                  </View>

                  <View style={{ flexDirection: 'row', paddingVertical: 5, justifyContent: 'flex-end' }}>
                    <TouchableOpacity onPress={(e) => {
                      e.stopPropagation();
                      handleLicenseDelete(license?.id);
                    }}>
                      <Icon name="delete" size={20} color="#dc3545" />
                    </TouchableOpacity>
                  </View>
                </View>
              </TouchableOpacity>

            ))
          )}
        </ScrollView>
      </View>
      <View style={[styles.btnContainer]}>

        <TouchableOpacity
          onPress={() => navigation.navigate('addEditLicense')}
          style={styles.iconPlus}>
          <Icon name="add" size={30} color="white" />
        </TouchableOpacity>
      </View>

    </>
  );
}



export default Index;
