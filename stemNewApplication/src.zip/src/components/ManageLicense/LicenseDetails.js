import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import ImageViewing from "react-native-image-viewing";

import Header from '../Header';
import { convertUTCToLocal } from '../../utils/appHelpers';
import appColors from '../../utils/appColors';
import SpaceBox from '../Common/SpaceBox';
import styles from '../../utils/styles';

const LicenseDetails = ({ route, navigation }) => {

  const { license } = route.params;

  const [isViewerVisible, setIsViewerVisible] = useState(false);
  const [images, setImages] = useState([{ uri: license?.image }]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [imageError, setImageError] = useState(false);

  
  const openImage = (imageUri) => {
    setImages([{ uri: imageUri }]);
    setIsViewerVisible(true);
  };



  return (
    <>
      <Header title="License Info" />
      <View style={styles.container}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}>

          <TouchableOpacity
            style={[styles.cardTab, { marginBottom: 10 }]}
            onPress={() => navigation.navigate('licenseDetails', { license })}>
            <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc' }]}></View>

            <View style={styles.tabDetails}>
              <View style={styles.tabHeader}>
                <Text style={styles.tabHeaderTitle}>
                  {license?.license_type?.license_name ?? '--'}
                </Text>
                <Text style={[styles.tabStatus, { backgroundColor: license?.status === '1' ? appColors.lightgreen : appColors.lightYellow }]}>
                  {license?.license_number ?? "--"}
                </Text>
              </View>
              <SpaceBox height={2} />
              <View style={styles.horizontalLine}></View>

              <View style={[{ flexDirection: 'row' }]}>

                <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                  <View style={[styles.tabIconCircle, { backgroundColor: '#e2eaff', marginTop: 1 }]}>
                    <Icon2 name={'calendar-month'} size={22} style={{ color: '#1d61f4' }} />
                  </View>
                  <View style={{ justifyContent: 'center' }}>
                    <Text style={styles.tabIconLabel}>
                      Date
                    </Text>
                    <SpaceBox height={3} />
                    <Text style={[styles.tabIconTitle, { color: '#000e42' }]}>
                      {convertUTCToLocal(license?.expired_on, 'MMM DD, YY', false)}
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          </TouchableOpacity>

          {/* License Image Section */}
          <TouchableOpacity
            style={[styles.cardTab, { marginBottom: 10 }]}
            onPress={() => navigation.navigate('licenseDetails', { license })}>
            <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc' }]}></View>

            <View style={styles.tabDetails}>
              <View style={styles.tabHeader}>
                <Text style={styles.tabHeaderTitle}>
                  License Image
                </Text>
              </View>
              <SpaceBox height={2} />
              <View style={styles.horizontalLine}></View>

              <View style={{ flexDirection: 'row', justifyContent: "center", alignItems: "center" }}>
                <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                  <View style={styles.textWrapper}>
                    {!imageError && license?.image ? (
                      <TouchableOpacity onPress={() => openImage(license?.image)}>
                        <Image
                          source={{ uri: license.image }}
                          style={styles.imageThumbnail}
                          resizeMode="cover"
                          onError={() => setImageError(true)} 
                        />
                      </TouchableOpacity>
                    ) : (
                      <Text style={{ color: "#888", fontSize: 10, textAlign: "center" }}>
                        No License Image Available
                      </Text>
                    )}
                  </View>
                </View>
              </View>
            </View>
          </TouchableOpacity>

        </ScrollView>

        {/* Image Viewer Modal */}
        <ImageViewing
          images={images}
          imageIndex={currentImageIndex}
          visible={isViewerVisible}
          onRequestClose={() => setIsViewerVisible(false)}
        />
      </View>

      <View style={styles.btnContainer}>
        <TouchableOpacity
          style={styles.Authbtn}
          onPress={() => navigation.navigate('addEditLicense', { license })}>
          <Text style={styles.Authbtntext}>Update License</Text>
        </TouchableOpacity>
      </View>
    </>
  );
};

export default LicenseDetails;
