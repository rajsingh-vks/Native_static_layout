import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Keyboard, KeyboardAvoidingView, TouchableWithoutFeedback } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Label } from '@react-navigation/elements';
import axios from 'axios';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import env from '../services/env';
import api from '../services/api';
import Input from './Common/Input';
import LinearProgress from './Common/LinearProgress';
import SpaceBox from './Common/SpaceBox';
import { setSpinner, getPopupModal, setPopupModal } from '../redux/appSlice';
import { showErrorToast, showSuccessToast, showPopup, passwordStrength } from '../utils/appHelpers';
import styles from '../utils/styles';

const ResetPassword = ({route}) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const popup = useSelector(getPopupModal);
  const { token } = route.params || {};
  const [newpwd, setNewPwd] = useState('');
  const [cnfpwd, setCnfPwd] = useState('');
  const [eyeIcon, setEyeIcon] = useState('eye-off');
  const [passVisible, setPassVisible] = useState(false);
  const [strength, setStrength] = useState(0);
  const [disabled, setDisabled] = useState(true);
  const [keyboardHeight, setKeyboardHeight] = useState(0);

  // Show Hide Password
  const showPassword = () => {
    if (passVisible) {
      setPassVisible(false);
      setEyeIcon('eye-off');
    } else {
      setPassVisible(true);
      setEyeIcon('eye');
    }
  }

  const changePassword = async () => {
    dispatch(setSpinner(true));

    let formData = new FormData();
    formData.append('password', newpwd);
    formData.append('confirm_password', cnfpwd);
    formData.append('role_id', 4);
    
    try {
      let response = await api.resetPassword(formData, token);
      if (response?.status == 200) {
        showSuccessToast(response?.message || 'Password changed successfully.', true);
      } else {
        showErrorToast(response?.message || 'Reset password failed, Contact support.');
      }

      dispatch(setSpinner(false));
      setDisabled(false);
    } catch (error) {
      dispatch(setSpinner(false));
      setDisabled(false);
      showErrorToast("Password reset failed.");
      console.log(JSON.stringify(error, null, 5));
    }
  }

  useEffect(() => {
    let strength = passwordStrength(newpwd);
    setStrength(strength);

    if(newpwd !='' && cnfpwd != '' && newpwd == cnfpwd && strength == 1){
      setDisabled(false);
    }else{
      setDisabled(true);
    }
  }, [newpwd, cnfpwd]);

  // For redirecting to login page after change password.
  useEffect(() => {
    if(popup?.visible == false && popup?.navigate == true){
      dispatch(setPopupModal({ navigate: false}),);
      navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
    }
  }, [popup]);

  useEffect(() => {
    setNewPwd('');
    setCnfPwd('');
  }, []);

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      Platform.OS === 'android' ? 'keyboardDidShow' : 'keyboardWillShow',
      (event) => {
        setKeyboardHeight(40);
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      Platform.OS === 'android' ? 'keyboardDidHide' : 'keyboardWillHide',
      () => {
        setKeyboardHeight(0);
      }
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={{flex:1, backgroundColor:'#fff'}}>
          <View style={styles.authContainer}>
            <TouchableOpacity
              style={[styles.drawerTouch, {backgroundColor:'transparent', borderColor:'#2c3f83', borderWidth:1}]}
              onPress={() => navigation.navigate('Forgot')}>
                <Icon name='chevron-left' style={[styles.drawerIcon, {color: '#2c3f83'}]}/>
            </TouchableOpacity>

            <View style={[{alignItems:'center'}]}>
              <Text style={[styles.authTitle]}>Reset Password</Text>
              <Text style={styles.authsubtitle}>
                A strong password is at least 8 characters long. Use a combination of uppercase and lowercase letters, numbers, and symbols.
              </Text>
            </View>

            <View style={{marginTop:20}}>
              <Input
                type='text'
                label='New password'
                leftIcon={<Icon name="lock" size={20} color='#465c9e' />}
                rightIcon={
                  <Icon name={eyeIcon} size={20} color='#465c9e' onPress={() => showPassword()} />
                }
                placeholder="Enter your password"
                placeholderTextColor="#CDCDCD"
                secureTextEntry={!passVisible}
                onChangeText={newpwd => setNewPwd(newpwd)}
              />
              <LinearProgress strength={strength}></LinearProgress>
              <SpaceBox height={10} />
              
              <Input
                type='text'
                label='Confirm Password'
                leftIcon={<Icon name="lock" size={20} color='#465c9e' />}
                rightIcon={
                  <Icon name={eyeIcon} size={20} color='#465c9e' onPress={() => showPassword()} />
                }
                placeholder="Enter confirm password"
                placeholderTextColor="#CDCDCD"
                secureTextEntry={!passVisible}
                onChangeText={cnfpwd => setCnfPwd(cnfpwd)}
              />
            </View>
          </View>

          <View style={[styles.btnContainer, {bottom: keyboardHeight}]}>
            <TouchableOpacity
              style={disabled ? styles.disabledBtn : styles.Authbtn}
              onPress={changePassword} disabled={disabled}>
              <Text style={styles.Authbtntext}>
                SUBMIT
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

export default ResetPassword;