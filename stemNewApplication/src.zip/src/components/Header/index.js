import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, Image, ScrollView, ImageBackground } from 'react-native';
import { useNavigation, useNavigationState, useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useDispatch, useSelector } from 'react-redux';

import { getUser } from '../../redux/userSlice';
import styles from '../../utils/styles';

const Header = ({ profile = '', title = '', subTitle = '', rightIcon = '', enableDrawer = false }) => {
  const navigation = useNavigation();
  const user = useSelector(getUser);
  const [leftIcon, setLeftIcon] = useState('currency-eth');
  const [drawer, setDrawer] = useState(true);
  const [uicon, setUicon] = useState(true);

  const screen = useNavigationState((state) => {
    const route = state.routes[state.index]; // Get the active route
    return route.name;
  });

  const initHeader = () => {
    console.log(screen);
    if ('dashboard' == screen || 'home' == screen || 'postsites' == screen || 'activity' == screen || 'messages' == screen || enableDrawer) {
      setLeftIcon('view-grid-outline');
      setDrawer(true);
      setUicon(true);
    } else {
      setLeftIcon('arrow-left');
      setDrawer(false);
      setUicon(false);
    }
  }

  useEffect(() => {
    initHeader();
  }, []);

  return (
    <View style={styles.header}>
      <TouchableOpacity
        style={[styles.drawerTouch]}
        onPress={() => { drawer ? navigation.openDrawer() : navigation.goBack(); }}>
        <Icon name={leftIcon} style={[styles.drawerIcon, { fontSize: 24 }]} />
      </TouchableOpacity>

      <View style={[styles.headerContent, { justifyContent: 'center' }]}>
        {title != '' ? (
          <>
            {subTitle && <Text style={styles.headerSubTitle}>{subTitle}</Text>}
            <Text style={styles.headerTitle}>{title}</Text>
          </>
        ) : (
          <>
            <Text style={styles.headerSubTitle}>Good Morning</Text>
            <Text style={styles.headerTitle}>{user?.full_name}</Text>
          </>
        )}
      </View>

      <View style={styles.headerRight}>
        {uicon &&
          <>
            <TouchableOpacity onPress={() => navigation.navigate('notification')}>
              <Icon name='bell-badge-outline' style={[styles.drawerIcon, { marginRight: 10 }]} />
            </TouchableOpacity>
            {/* <TouchableOpacity
              onPress={() => navigation.goBack()}
              style={styles.drawerTouch}>
              <Icon name='account' style={styles.drawerIcon} />
            </TouchableOpacity> */}
          </>
        }
        {rightIcon}
      </View>
    </View>
  );
}

export default Header