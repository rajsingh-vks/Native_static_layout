import { useCallback, useEffect, useState } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  RefreshControl,
  ScrollView,
} from "react-native";
import { useFocusEffect, useNavigation } from "@react-navigation/native";
import { useDispatch, useSelector } from "react-redux";
import Icon from "react-native-vector-icons/MaterialIcons";
import Icon2 from "react-native-vector-icons/MaterialCommunityIcons";

import Header from "../Header";
import api from "../../services/api";
import { setSpinner } from "../../redux/appSlice";
import { getRefresh } from "../../redux/refreshSlice";
import {
  showErrorToast,
} from "../../utils/appHelpers";
import appColors from "../../utils/appColors";
import SpaceBox from "../Common/SpaceBox";
import styles from "../../utils/styles";
import moment from "moment";

function Index() {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [timeRequests, setTimeRequests] = useState([]);
  const [isDataFetched, setIsDataFetched] = useState(false);
  const refreshTimeRequest = useSelector((state) =>
    getRefresh(state, "timeRequests")
  );

  const getTimeRequests = async () => {
    dispatch(setSpinner(true));
    try {
      const response = await api.timeRequestList(1); // Fetch page 1
      if (response?.status === 200) {
        setTimeRequests(response?.data ?? []);
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message || "Failed to fetch time requests");
    } finally {
      setIsDataFetched(true);
      dispatch(setSpinner(false));
    }
  };

  useEffect(() => {
    getTimeRequests();
  }, [refreshTimeRequest]);

  useFocusEffect(
    useCallback(() => {
      getTimeRequests();

      return () => {};
    }, [])
  );

  return (
    <>
      <Header title="Time Off Request" />
      <View style={styles.container}>
        <ScrollView
          refreshControl={
            <RefreshControl refreshing={false} onRefresh={getTimeRequests} />
          }
          contentContainerStyle={styles.scrollView}
        >
          {timeRequests.length > 0 && (
            <Text style={styles.sectionHeader}>Time Off Request</Text>
          )}
          {isDataFetched && timeRequests.length === 0 ? (
            <View style={styles.noDataContainer}>
              <Image
                source={require("../../assets/images/not-found.png")}
                style={styles.noDataImage}
              />
              <Text style={styles.noDataText}>No Records Found</Text>
            </View>
          ) : (
            timeRequests.map((ele, index) => (
              <TouchableOpacity
                key={index}
                style={[styles.cardTab, { marginBottom: 10 }]}
                onPress={() =>
                  navigation.navigate("TimeRequestDetails", { ele })
                }
              >
                <View
                  style={[
                    styles.absoluteLeftLine,
                    { backgroundColor: "#275ffc" },
                  ]}
                ></View>

                <View style={styles.tabDetails}>
                  <View style={styles.tabHeader}>
                    <Text style={styles.tabHeaderTitle}>
                      {ele?.guard[0]?.label ?? '--'}
                    </Text>
                    <Text
                      style={[
                        styles.tabStatus,
                        {
                          backgroundColor:
                            ele?.status === "1"
                              ? appColors.lightgreen
                              : appColors.lightYellow,
                        },
                      ]}
                    >
                      {ele?.status === "1" ? "Completed" : "Pending"}
                    </Text>
                  </View>
                  <SpaceBox height={2} />
                  <View style={styles.horizontalLine}></View>

                  <View style={[{ flexDirection: "row" }]}>
                    <View
                      style={[
                        styles.notification,
                        { paddingHorizontal: 0, flex: 1 },
                      ]}
                    >
                      <View
                        style={[
                          styles.tabIconCircle,
                          { backgroundColor: "#e2eaff", marginTop: 1 },
                        ]}
                      >
                        <Icon2
                          name={"alpha-p-circle-outline"}
                          size={25}
                          style={{ color: "#1d61f4" }}
                        />
                      </View>
                      <View style={{ justifyContent: "center" }}>
                        <Text style={styles.tabIconLabel}>Is Paid</Text>
                        <SpaceBox height={3} />
                        <Text style={[styles.tabIconTitle]}>
                          {ele?.is_paid ? "Paid" : "Unpaid"}
                        </Text>
                      </View>
                    </View>
                    <View
                      style={[styles.notification, { paddingHorizontal: 0 }]}
                    >
                      <View
                        style={[
                          styles.tabIconCircle,
                          { backgroundColor: "#e2eaff", marginTop: 1 },
                        ]}
                      >
                        <Icon2
                          name={"calendar-month"}
                          size={22}
                          style={{ color: "#1d61f4" }}
                        />
                      </View>
                      <View style={{ justifyContent: "center" }}>
                        <Text style={styles.tabIconLabel}>Date</Text>
                        <SpaceBox height={3} />
                        <Text
                          style={[styles.tabIconTitle, { color: "#000e42" }]}
                        >
                          {moment(ele?.start_date).format("MM/DD/YYYY")}
                        </Text>
                      </View>
                    </View>
                  </View>

                  <View
                    style={{
                      flexDirection: "row",
                      paddingVertical: 5,
                      justifyContent: "flex-end",
                    }}
                  >
                    <Text style={styles.tabViewDetails}>View Details</Text>
                    <Icon2
                      name={"arrow-right-thin-circle-outline"}
                      size={16}
                      style={{ color: appColors.dark500 }}
                    />
                  </View>
                </View>
              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>
      <TouchableOpacity
        onPress={() => navigation.navigate("addTimeRequest")}
        style={styles.iconPlus}
      >
        <Icon name="add" size={30} color="white" />
      </TouchableOpacity>
    </>
  );
}

export default Index;
