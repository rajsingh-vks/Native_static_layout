import { useEffect, useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
} from "react-native";
import { useDispatch, useSelector } from "react-redux";
import moment from "moment";

import Header from "../Header";
import Input from "../Common/Input";
import api from "../../services/api";
import { setSpinner } from "../../redux/appSlice";
import { getUser } from "../../redux/userSlice";
import { showErrorToast, showSuccessToast } from "../../utils/appHelpers";
import Dropdown from "../../utils/dropdown";
import validateForm from "../../utils/validateForm";
import SelectComponent from "../Common/SelectComponent";
import styles from "../../utils/styles";
import DateComponent from "../Common/DateComponent";

function AddEditTimeRequest({ route, navigation }) {
  const { ele } = route.params || {};
  const [fields, setFields] = useState({});
  const [disabled, setDisabled] = useState(true);
  const user = useSelector(getUser);
  const dispatch = useDispatch();

  // Edit data
  // from: ele?.start_date ? moment(ele.start_date).format("YYYY-MM-DD") : "",
  // from_time: ele?.start_date ? moment(ele.start_date).format("HH:mm") : "",
  // to: ele?.end_date ? moment(ele.end_date).format("YYYY-MM-DD") : "",
  // to_time: ele?.end_date ? moment(ele.end_date).format("HH:mm") : "",
  // type: ele?.is_paid ? 1 : 2,
  // paid_hours: ele?.paid_hours || "",
  // timezone: ele?.timezone || "Asia/Calcutta",
  // time_off_reason: ele?.time_off_reason || "",
  // comments: ele?.comments || "",

  const handleInputChange = (field, value) => {
    setFields((prevState) => ({ ...prevState, [field]: value }));
  };

  const rules_timeRequest = {
    type: ["required", "number"],
    time_off_reason: ["required", "number"],
    from: ["required", "date"],
    from_time: ["required", "date"],
    to: ["required", "date"],
    to_time: ["required", "date"],
    comments: ["required", "string"],
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    dispatch(setSpinner(true));

    try {
      let formData = new FormData();
      let phours = "";

      const fromDateTime = `${fields.from}T${fields.from_time}`;
      const toDateTime = `${fields.to}T${fields.to_time}`;

      formData.append("guard_id", user?.id);
      formData.append("time_at", moment().format("YYYY-MM-DD HH:mm:ss"));
      formData.append(
        "from",
        moment(fromDateTime).format("YYYY-MM-DD HH:mm:ss")
      );
      formData.append("to", moment(toDateTime).format("YYYY-MM-DD HH:mm:ss"));
      formData.append("type", fields?.type);
      if (fields?.type === 1) {
        phours = moment(fields?.paid_hours, "HH:mm:ss").format("HH:mm");
        formData.append("paid_hours", phours);
      }
      formData.append("timezone", fields?.timezone || "Asia/Calcutta");
      formData.append("time_off_reason", fields?.time_off_reason);
      formData.append("comments", fields?.comments);

      const response = await api.addTimeRequest(formData);

      if (response?.status == 200) {
        showSuccessToast(response?.message);
        navigation.goBack();
      } else {
        showErrorToast(response?.message || "An error occurred.");
      }
    } catch (error) {
      showErrorToast(
        error?.data?.message || "Something went wrong. Contact Support."
      );
    } finally {
      dispatch(setSpinner(false));
    }
  };

  useEffect(() => {
    let rules = rules_timeRequest;
    let valStat = validateForm(fields, rules);
    if (valStat?.status == true) {
      setDisabled(false);
    } else {
      setDisabled(true);
    }
  }, [fields]);

  return (
    <>
      <Header title={ele?.id ? "Update Time Request" : "Add Time Request"} />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, backgroundColor: "#FFF" }}
          keyboardShouldPersistTaps="handled"
        >
          <View style={[{ flex: 1, backgroundColor: "#fff" }]}>
            <View
              style={[
                styles.container,
                { boxShadow: "none", backgroundColor: "#fff", padding: 0 },
              ]}
            >
              <SelectComponent
                label="Type"
                placeholder="Select Type"
                options={Dropdown?.leaveItems}
                value={fields.type}
                required={true}
                onSelect={(selectedOption) => handleInputChange("type", selectedOption?.value)}
              />

              <DateComponent
                label="From Date"
                value={fields.from}
                required={true}
                placeholder="DD-MM-YYYY"
                minDate={moment().startOf("day").toISOString()}
                onChange={(from) => handleInputChange("from", from)}
              />

              <View style={{ marginVertical: 5 }}>
                <Input
                  type="time"
                  label="At"
                  placeholder="00:00"
                  value={fields.from_time}
                  required={true}
                  iconName="time-outline"
                  onChange={(from_time) =>
                    handleInputChange("from_time", from_time)
                  }
                />
              </View>

              <DateComponent
                label="To Date"
                value={fields.to}
                required={true}
                placeholder="DD-MM-YYYY"
                minDate={moment().startOf("day").toISOString()}
                onChange={(to) => handleInputChange("to", to)}
              />
              <View style={{ marginVertical: 5 }}>
                <Input
                  type="time"
                  label="At"
                  placeholder="00:00"
                  value={fields.to_time}
                  required={true}
                  iconName="time-outline"
                  onChange={(to_time) => handleInputChange("to_time", to_time)}
                />
              </View>
              {fields?.type == 1 && (
                <View style={{ marginVertical: 5 }}>
                  <Input
                    label="Paid Hours"
                    placeholder="00:00:00"
                    type="text"
                    value={fields.paid_hours}
                    required={true}
                    iconName="time-outline"
                    onChangeText={(paid_hours) =>
                      handleInputChange("paid_hours", paid_hours)
                    }
                  />
                </View>
              )}

              <SelectComponent
                label="Select Reason"
                placeholder="Select Reason"
                options={Dropdown?.reasonItems}
                value={fields.time_off_reason}
                required={true}
                onSelect={(selectedOption) => handleInputChange("time_off_reason", selectedOption?.value)}

              />

              <View style={{ marginVertical: 5 }}>
                <Input
                  type="textarea"
                  numberOfLines={4}
                  required={true}
                  label="Comment"
                  value={fields.comments}
                  placeholder="Comment"
                  placeholderTextColor="#CDCDCD"
                  inputStyle={styles.textAreaInput}
                  onChangeText={(value) => handleInputChange("comments", value)}
                />
              </View>
            </View>
          </View>

          <View style={{ height: 50, marginBottom: 20, marginHorizontal: 15 }}>
            <TouchableOpacity
              style={disabled ? styles.disabledBtn : styles.Authbtn}
              disabled={disabled}
              onPress={handleSubmit}
            >
              <Text style={styles.Authbtntext}>Save</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </>
  );
}

export default AddEditTimeRequest;
