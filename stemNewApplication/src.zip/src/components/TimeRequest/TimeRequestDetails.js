import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import Icon from "react-native-vector-icons/MaterialIcons";
import Icon2 from "react-native-vector-icons/MaterialCommunityIcons";
import moment from "moment";

import Header from "../Header";
import styles from "../../utils/styles";
import appColors from "../../utils/appColors";
import SpaceBox from "../Common/SpaceBox";

const TimeRequestDetails = ({ route, navigation }) => {
  const { ele } = route.params;

  return (
    <>
      <Header title="Time Off Request Info" />
      <View style={[styles.container]}>
        <TouchableOpacity
          style={[styles.cardTab, { marginBottom: 10 }]}
          onPress={() => navigation.navigate("TimeRequestDetails", { ele })}
        >
          <View
            style={[styles.absoluteLeftLine, { backgroundColor: "#275ffc" }]}
          ></View>

          <View style={styles.tabDetails}>
            <View style={styles.tabHeader}>
              <Text style={styles.tabHeaderTitle}>
                {ele?.guard[0]?.label ?? "--"}
              </Text>
              <Text
                style={[
                  styles.tabStatus,
                  {
                    backgroundColor:
                      ele?.status === "1"
                        ? appColors.lightgreen
                        : appColors.lightYellow,
                  },
                ]}
              >
                {ele?.status === "1" ? "Completed" : "Pending"}
              </Text>
            </View>
            <SpaceBox height={2} />
            <View style={styles.horizontalLine}></View>

            <View style={[{ flexDirection: "row" }]}>
              <View
                style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}
              >
                <View
                  style={[
                    styles.tabIconCircle,
                    { backgroundColor: "#e2eaff", marginTop: 1 },
                  ]}
                >
                  <Icon2
                    name={"alpha-p-circle-outline"}
                    size={25}
                    style={{ color: "#1d61f4" }}
                  />
                </View>
                <View style={{ justifyContent: "center" }}>
                  <Text style={styles.tabIconLabel}>Is Paid</Text>
                  <SpaceBox height={3} />
                  <Text style={[styles.tabIconTitle]}>
                    {ele?.is_paid ? "Paid" : "Unpaid"}
                  </Text>
                </View>
              </View>
              <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                <View
                  style={[
                    styles.tabIconCircle,
                    { backgroundColor: "#e2eaff", marginTop: 1 },
                  ]}
                >
                  <Icon2
                    name={"clock"}
                    size={22}
                    style={{ color: "#1d61f4" }}
                  />
                </View>
                <View style={{ justifyContent: "center" }}>
                  <Text style={styles.tabIconLabel}>Paid Hours</Text>
                  <SpaceBox height={3} />
                  <Text style={[styles.tabIconTitle, { color: "#000e42" }]}>
                    {ele?.paid_hours ?? "--"}
                  </Text>
                </View>
              </View>
            </View>

            <View style={[{ flexDirection: "row" }]}>
              <View
                style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}
              >
                <View
                  style={[
                    styles.tabIconCircle,
                    { backgroundColor: "#e2eaff", marginTop: 1 },
                  ]}
                >
                  <Icon2
                    name={"calendar-month"}
                    size={25}
                    style={{ color: "#1d61f4" }}
                  />
                </View>
                <View style={{ justifyContent: "center" }}>
                  <Text style={styles.tabIconLabel}>Start</Text>
                  <SpaceBox height={3} />
                  <Text style={[styles.tabIconTitle]}>
                    {ele?.start_date
                      ? moment(ele.start_date).format(
                          "MMM Do, YYYY [at] h:mm A"
                        )
                      : "--"}
                  </Text>
                </View>
              </View>
            </View>
            <View style={[styles.notification, { paddingHorizontal: 0 }]}>
              <View
                style={[
                  styles.tabIconCircle,
                  { backgroundColor: "#e2eaff", marginTop: 1 },
                ]}
              >
                <Icon2
                  name={"calendar-month"}
                  size={22}
                  style={{ color: "#1d61f4" }}
                />
              </View>
              <View style={{ justifyContent: "center" }}>
                <Text style={styles.tabIconLabel}>End</Text>
                <SpaceBox height={3} />
                <Text style={[styles.tabIconTitle, { color: "#000e42" }]}>
                  {ele?.end_date
                    ? moment(ele.end_date).format("MMM Do, YYYY [at] h:mm A")
                    : "--"}
                </Text>
              </View>
            </View>
            <View style={[styles.notification, { paddingHorizontal: 0 }]}>
              <View
                style={[
                  styles.tabIconCircle,
                  { backgroundColor: "#e2eaff", marginTop: 1 },
                ]}
              >
                <Icon2
                  name={"calendar-month"}
                  size={22}
                  style={{ color: "#1d61f4" }}
                />
              </View>
              <View style={{ justifyContent: "center" }}>
                <Text style={styles.tabIconLabel}>Added On</Text>
                <SpaceBox height={3} />
                <Text style={[styles.tabIconTitle, { color: "#000e42" }]}>
                  {ele?.created_on
                    ? moment(ele.created_on).format("MMMM Do, YYYY [at] h:mm A")
                    : "--"}
                </Text>
              </View>
            </View>
            <View style={[styles.notification, { paddingHorizontal: 0 }]}>
              <View
                style={[
                  styles.tabIconCircle,
                  { backgroundColor: "#e2eaff", marginTop: 1 },
                ]}
              >
                <Icon2
                  name={"comment"}
                  size={22}
                  style={{ color: "#1d61f4" }}
                />
              </View>
              <View style={{ justifyContent: "center" }}>
                <Text style={styles.tabIconLabel}>Comment</Text>
                <SpaceBox height={3} />
                <Text style={[styles.tabIconTitle, { color: "#000e42" }]}>
                  {ele?.comments ?? "--"}
                </Text>
              </View>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    </>
  );
};

export default TimeRequestDetails;
