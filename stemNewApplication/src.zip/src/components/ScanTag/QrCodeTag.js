import * as React from 'react';
import { View, Text } from 'react-native';

import Header from '../Header';
import styles from '../../utils/styles';

function QrCode() {

  return (
    <>
      <Header title='QR Scan' />
      <View style={[styles.container]}>
        <Text style={styles.title}>QR Code</Text>
      </View>
    </>
  );
}

export default QrCode