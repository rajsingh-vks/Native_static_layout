import * as React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/Feather';

import Header from '../Header';
import SpaceBox from '../Common/SpaceBox';
import styles from '../../utils/styles';

function Index() {
  const navigation = useNavigation();

  return (
    <>
      <Header title='Scan Tag' />
      <View style={[styles.container]}>
        <ScrollView>
          <TouchableOpacity style={styles.settingTab} onPress={() => navigation.navigate('')}>
            <Icon name={'nfc'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Scan NFC Tag</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingTab} onPress={() => navigation.navigate('')}>
            <Icon name={'qrcode-scan'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Scan QR Tag</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingTab} onPress={() => navigation.navigate('')}>
            <Icon name={'file-table-box-multiple-outline'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Scan Virtual Tag</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity>
          <SpaceBox height={20} />

    

          
        </ScrollView>
      </View>
    </>
  );
}

export default Index