import * as React from 'react';
import { View, Text } from 'react-native';

import Header from '../Header';
import styles from '../../utils/styles';

function NfcTag() {

  return (
    <>
      <Header title='NFC Scan' />
      <View style={[styles.container]}>
        <Text style={styles.title}>NFC TAG</Text>
      </View>
    </>
  );
}

export default NfcTag