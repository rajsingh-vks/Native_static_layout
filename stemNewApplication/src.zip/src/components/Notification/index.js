import * as React from 'react';
import { View, Text, ScrollView, TouchableOpacity, RefreshControl, ImageBackground } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import styles from '../../utils/styles';
import appColors from '../../utils/appColors';

function Notification() {
  const navigation = useNavigation();

  return (
    <>
      <Header title="Notification" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>
          <View>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 12, marginBottom: 10 }]}
              onPress={() => navigation.navigate('chat')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: 'rgba(109, 192, 115, 0.3)', width: 45, height: 45 }]}>
                        <Icon name='bell' style={[styles.drawerIcon, {color: appColors.green}]} />
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 16, flex: 1, color: '#4D4D4D', fontWeight: 400, marginLeft: 10 }]}>
                        Your Incident Report has been Approved.
                      </Text>
                      <Text style={[styles.companyEmail, { fontSize: 13, flex: 1, verticalAlign: 'middle', marginLeft: 10 }]}>
                        5:10 am
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 12, marginBottom: 10 }]}
              onPress={() => navigation.navigate('chat')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: 'rgba(109, 192, 115, 0.3)', width: 45, height: 45 }]}>
                        <Icon name='bell' style={[styles.drawerIcon, {color: appColors.green}]} />
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 16, flex: 1, color: '#4D4D4D', fontWeight: 400, marginLeft: 10 }]}>
                        Your Incident Report has been Approved.
                      </Text>
                      <Text style={[styles.companyEmail, { fontSize: 13, flex: 1, verticalAlign: 'middle', marginLeft: 10 }]}>
                        5:10 am
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 12, marginBottom: 10 }]}
              onPress={() => navigation.navigate('chat')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: 'rgba(193, 93, 82, 0.3)', width: 45, height: 45 }]}>
                        <Icon name='bell' style={[styles.drawerIcon, {color: appColors.red}]} />
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 16, flex: 1, color: '#4D4D4D', fontWeight: 400, marginLeft: 10 }]}>
                         Your Incident Report has been Rejected.
                      </Text>
                      <Text style={[styles.companyEmail, { fontSize: 13, flex: 1, verticalAlign: 'middle', marginLeft: 10 }]}>
                        5:10 am
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 12, marginBottom: 10 }]}
              onPress={() => navigation.navigate('chat')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: 'rgba(109, 192, 115, 0.3)', width: 45, height: 45 }]}>
                        <Icon name='bell' style={[styles.drawerIcon, {color: appColors.green}]} />
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 16, flex: 1, color: '#4D4D4D', fontWeight: 400, marginLeft: 10 }]}>
                        Your Incident Report has been Approved.
                      </Text>
                      <Text style={[styles.companyEmail, { fontSize: 13, flex: 1, verticalAlign: 'middle', marginLeft: 10 }]}>
                        5:10 am
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 12, marginBottom: 10 }]}
              onPress={() => navigation.navigate('chat')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: 'rgba(109, 192, 115, 0.3)', width: 45, height: 45 }]}>
                        <Icon name='bell' style={[styles.drawerIcon, {color: appColors.green}]} />
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 16, flex: 1, color: '#4D4D4D', fontWeight: 400, marginLeft: 10 }]}>
                        Your Incident Report has been Approved.
                      </Text>
                      <Text style={[styles.companyEmail, { fontSize: 13, flex: 1, verticalAlign: 'middle', marginLeft: 10 }]}>
                        5:10 am
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

export default Notification