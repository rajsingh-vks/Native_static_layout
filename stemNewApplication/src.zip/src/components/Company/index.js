import { useCallback, useEffect, useState } from 'react';
import { Image, RefreshControl, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/Feather';

import Header from '../Header';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { getUser, updateCompanyId } from '../../redux/userSlice';
import { getRefresh, setRefresh } from '../../redux/refreshSlice';
import { showErrorToast, showSuccessToast, refresh } from '../../utils/appHelpers';
import { showConfirmationBox } from '../Common/Confirmation';
import styles from '../../utils/styles';

function Company() {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const user = useSelector(getUser);
  const [companies, setCompanies] = useState([]);
  const [isDataFetched, setIsDataFetched] = useState(false);
  const refreshCompany = useSelector(state => getRefresh(state, 'companies'),);

  const getCompanies = async () => {
    try {
      dispatch(setSpinner(true));

      const params = { user_id: user?.id };
      const response = await api.companyList(params);

      if (response.status === 200) {
        setCompanies(response?.companies ?? []);
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message || 'Failed to fetch companies');
    } finally {
      setIsDataFetched(true); 
      dispatch(setSpinner(false)); 
    }
  };

  const handleConfirmation = (company_id) => {
    showConfirmationBox(
      'Select Company',
      'select',
      async () => {
        try {
          let formData = new FormData();
          formData.append('company_id', [company_id]);
          formData.append('user_id', [user?.id]);
          const response = await api.companySelect(formData);

          if (response.status === 200) {
            dispatch(updateCompanyId(response?.company_id));
            refresh('dashboard');
            navigation.goBack();
          } else {
            showErrorToast(response.message);
          }
        } catch (error) {
          showErrorToast(error.message);
        }
      },
    );
  };

  useEffect(() => {
    getCompanies();
  }, [refreshCompany]);

  // Load on focus
  useFocusEffect(
    useCallback(() => {
      getCompanies(); 
  
      return () => {}; 
    }, [])
  );

  return (
    <>
      <Header title='Select Company' enableDrawer={true}/>
      <View style={[styles.container]}>
        <ScrollView 
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={getCompanies}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>

          {/* Show "not-found" image only after data not found */}
          {isDataFetched && companies?.length === 0 ? (
            <View style={customStyles.noRecordsContainer}>
              <Image
                source={require('../../assets/images/not-found.png')}
                style={customStyles.noRecordsImage}
              />
              <Text style={customStyles.noRecordsText}>No Companies found.</Text>
            </View>
          ) : (
            <View>
              {companies?.map((company, index) => (
                <TouchableOpacity
                  key={index}
                  style={[styles.settingTab, {borderRadius:15, marginVertical:5, paddingHorizontal:10}]}
                  onPress={() => handleConfirmation(company?.id)}>
                  <View style={[styles.companyDetails, {flexDirection:'row'}]}>
                    <View style={{paddingVertical:5, width:35, justifyContent:'center'}}>
                      {company?.selected == true ?(
                      <Icon name={'check-circle-outline'} size={25} color='#28A745' style={{marginRight:5}}/>
                      ) : (
                      <Icon2 name={'disc'} size={24} color='#A6A8A9' style={{marginRight:5}}/>
                      )}
                    </View>

                    <View style={[styles.companyRow, {flexDirection:'column', flex:1}]}>
                      <Text style={styles.companyName}>
                        {company?.access_name ?? '--'}
                      </Text>

                      {company?.invite_status === 2 && (
                      <View style={styles.badgeYellow}>
                        <Text style={styles.badgeText}>Invited</Text>
                      </View>
                      )}
                      <View>
                        <Text style={styles.companyEmail}>{company?.email ?? '--'}</Text>
                      </View>
                    </View>

                    <TouchableOpacity onPress={() => navigation.navigate('companyDetails',{company})}>
                      <Icon name={'chevron-right'} size={20} style={[styles.roundedGrey, styles.secondaryIcon]} />
                    </TouchableOpacity>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </ScrollView>
      </View>
      <View style={[styles.btnContainer]}>
        <TouchableOpacity
          style={styles.Authbtn}
          onPress={() => navigation.navigate('joinCompany')}>
          <Text style={styles.Authbtntext}>Join Company</Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

export default Company;

const customStyles = StyleSheet.create({
  noRecordsContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 50,
  },
  noRecordsImage: {
    width: 100,
    height: 100,
    resizeMode: 'contain',
  },
  noRecordsText: {
    marginTop: 10,
    fontSize: 16,
    color: '#A6A8A9',
  },
});
