import { useEffect, useState, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';

import Header from '../Header';
import Input from '../Common/Input';
import api from '../../services/api';
import { getUser } from '../../redux/userSlice';
import { setSpinner } from '../../redux/appSlice';
import { setRefresh } from '../../redux/refreshSlice';
import { showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import appColors from '../../utils/appColors';
import styles from '../../utils/styles';

function JoinCompany() {
  const navigation = useNavigation();
  const user = useSelector(getUser);
  const dispatch = useDispatch();
  const [fields, setFields] = useState(Array(6).fill(''));
  const [joinCode, setJoinCode] = useState('');
  const [isLoader, setIsLoader] = useState(false);
  const [disabled, setDisabled] = useState(true);

  const [otp1, setOTP1] = useState('');
  const [otp2, setOTP2] = useState('');
  const [otp3, setOTP3] = useState('');
  const [otp4, setOTP4] = useState('');
  const [otp5, setOTP5] = useState('');
  const [otp6, setOTP6] = useState('');

  const ref1 = useRef(null);
  const ref2 = useRef(null);
  const ref3 = useRef(null);
  const ref4 = useRef(null);
  const ref5 = useRef(null);
  const ref6 = useRef(null);

  // const handleInputChange = (index, value) => {
  //   if (/^[a-zA-Z0-9]?$/.test(value)) {
  //     setFields((prevFields) => {
  //       const updatedFields = [...prevFields];
  //       updatedFields[index] = value.toUpperCase();
  //       return updatedFields;
  //     });
  //   }
  // };

  const handleSubmit = async () => {
    try {
      dispatch(setSpinner(true));
      // setIsLoader(true);
      // const joinCode = fields.join('');
      const formData = new FormData();
      formData.append('join_code', joinCode);
      formData.append('user_id', user?.id);

      const response = await api.joincompany(formData);

      if (response?.status) {
        dispatch(setSpinner(false));
        showSuccessToast(response?.message || 'Join company successfully');
        dispatch(setRefresh('companies'));
        navigation.replace('company');
      } else {
        showErrorToast(response?.message || 'Failed to join company');
      }
    } catch (error) {
      dispatch(setSpinner(false));
      showErrorToast(error?.data?.message || 'An error occurred');
    } finally {
      dispatch(setSpinner(false));
      setIsLoader(false);
    }
  };

  useEffect(() => {
    const isValid = fields.every((field) => field !== '');
    setDisabled(!isValid);
  }, [fields]);

  useEffect(() => {
    if(joinCode !=''){
      setDisabled(false);
    }else{
      setDisabled(true);
    }
  }, [joinCode]);

  useEffect(() => {
    let otp = '';
    if (otp1 != '' && otp2 != '' && otp3 != '' && otp4 != '' && otp5 != '' && otp6 != '') {
      otp = otp1 + otp2 + otp3 + otp4 + otp5 + otp6;
      setJoinCode(otp);
    }
    if(otp1 == '' || otp2 == '' || otp3 == '' || otp4 == '' || otp5 == '' || otp6 == ''){
      setJoinCode('');
    }
  }, [otp1, otp2, otp3, otp4, otp5, otp6]);

  return (
    <>
      <Header title='Join Company'/>
      <View style={[styles.container]}>
        <ScrollView contentContainerStyle={styles.content}>
          <Text style={styles.title}>Enter Join Code</Text>
          <Text style={styles.subtitle}>
            Please enter the invitation code below to join a new company.
          </Text>
          {/* <View style={styles.inputContainer}>
            {fields.map((value, index) => (
              <Input
                key={index}
                type="text"
                style={styles.inputBox}
                maxLength={1}
                keyboardType="number-pad"
                onChangeText={(value) => handleInputChange(index, value)}
                value={value}
              />
            ))}
          </View> */}

          {/* <>OTP Start</> */}
          <View style={[styles.container, {paddingHorizontal:0}]}>
            <View
              style={[
                iStyles.inputwrapper,
                {flexDirection: 'row', marginBottom: 5, marginTop:20, alignItems: 'center'},
              ]}>
              <TextInput
                style={[
                  iStyles.input,
                  {
                    borderColor: ref1.current ? '#cccccc' : '#cccccc',
                    fontSize: 17,
                    marginRight: 10,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    textAlign: 'center',
                    height: 40,
                    width: 40,
                  },
                ]}
                placeholder="#"
                placeholderTextColor="#AAAAAA"
                autoFocus={true}
                maxLength={1}
                returnKeyType="done"
                value={otp1}
                ref={ref => (ref1.current = ref)}
                onChangeText={value => {
                  if (value.length > 0) {
                    setOTP1(value);
                    ref2.current?.focus();
                  } else if (value.length == 0) {
                    setOTP1(value);
                  }
                }}
              />
              <TextInput
                style={[
                  iStyles.input,
                  {
                    borderColor: '#cccccc',
                    fontSize: 17,
                    marginRight: 10,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    textAlign: 'center',
                    height: 40,
                    width: 40,
                  },
                ]}
                placeholder="#"
                placeholderTextColor="#AAAAAA"
                maxLength={1}
                returnKeyType="done"
                value={otp2}
                ref={ref => (ref2.current = ref)}
                onChangeText={value => {
                  if (value.length > 0) {
                    setOTP2(value);
                    ref3.current?.focus();
                  } else if (value.length == 0) {
                    setOTP2(value);
                  }
                }}
                onKeyPress={({nativeEvent}) => {
                  if (nativeEvent.key === 'Backspace') {
                    if (otp2.length == 0) {
                      ref1.current?.focus();
                    }
                  }
                }}
              />
              <TextInput
                style={[
                  iStyles.input,
                  {
                    borderColor: '#cccccc',
                    fontSize: 17,
                    marginRight: 10,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    textAlign: 'center',
                    height: 40,
                    width: 40,
                  },
                ]}
                placeholder="#"
                placeholderTextColor="#AAAAAA"
                maxLength={1}
                returnKeyType="done"
                value={otp3}
                ref={ref => (ref3.current = ref)}
                onChangeText={value => {
                  if (value.length > 0) {
                    setOTP3(value);
                    ref4.current?.focus();
                  } else if (value.length == 0) {
                    setOTP3(value);
                  }
                }}
                onKeyPress={({nativeEvent}) => {
                  if (nativeEvent.key === 'Backspace') {
                    if (otp3.length == 0) {
                      ref2.current?.focus();
                    }
                  }
                }}
              />
              <TextInput
                style={[
                  iStyles.input,
                  {
                    borderColor: '#cccccc',
                    fontSize: 17,
                    marginRight: 10,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    textAlign: 'center',
                    height: 40,
                    width: 40,
                  },
                ]}
                placeholder="#"
                placeholderTextColor="#AAAAAA"
                maxLength={1}
                returnKeyType="done"
                value={otp4}
                ref={ref => (ref4.current = ref)}
                onChangeText={value => {
                  if (value.length > 0) {
                    setOTP4(value);
                    ref5.current?.focus();
                  } else if (value.length == 0) {
                    setOTP4(value);
                  }
                }}
                onKeyPress={({nativeEvent}) => {
                  if (nativeEvent.key === 'Backspace') {
                    if (otp4.length == 0) {
                      ref3.current?.focus();
                    }
                  }
                }}
              />
              <TextInput
                style={[
                  iStyles.input,
                  {
                    borderColor: '#cccccc',
                    fontSize: 17,
                    marginRight: 10,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    textAlign: 'center',
                    height: 40,
                    width: 40,
                  },
                ]}
                placeholder="#"
                placeholderTextColor="#AAAAAA"
                maxLength={1}
                returnKeyType="done"
                value={otp5}
                ref={ref => (ref5.current = ref)}
                onChangeText={value => {
                  if (value.length > 0) {
                    setOTP5(value);
                    ref6.current?.focus();
                  } else if (value.length == 0) {
                    setOTP5(value);
                  }
                }}
                onKeyPress={({nativeEvent}) => {
                  if (nativeEvent.key === 'Backspace') {
                    if (otp5.length == 0) {
                      ref4.current?.focus();
                    }
                  }
                }}
              />
              <TextInput
                style={[
                  iStyles.input,
                  {
                    borderColor: '#cccccc',
                    fontSize: 17,
                    marginRight: 10,
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    textAlign: 'center',
                    height: 40,
                    width: 40,
                  },
                ]}
                placeholder="#"
                placeholderTextColor="#AAAAAA"
                maxLength={1}
                returnKeyType="done"
                value={otp6}
                ref={ref => (ref6.current = ref)}
                onChangeText={value => {
                  setOTP6(value);
                }}
                onKeyPress={({nativeEvent}) => {
                  if (nativeEvent.key === 'Backspace') {
                    if (otp6.length == 0) {
                      ref5.current?.focus();
                    }
                  }
                }}
              />
            </View>
          </View>
          {/* <>OTP End</> */}
        </ScrollView>
      </View>
      <View style={[styles.btnContainer, {marginHorizontal:15}]}>
        <TouchableOpacity
          style={disabled ? styles.disabledBtn : styles.Authbtn}
          onPress={handleSubmit} disabled={disabled}>
          <Text style={styles.Authbtntext}>{isLoader ? 'Saving...' : 'Submit'}</Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

export default JoinCompany;

const iStyles = StyleSheet.create({
  inputwrapper: {
    height: 60,
    overflow: 'hidden',
    position: 'relative',
  },
  input: {
    borderColor: appColors.gray,
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: 'white',
  },

})