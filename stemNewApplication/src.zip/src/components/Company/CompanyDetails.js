import { View, Text, TouchableOpacity,ScrollView } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import api from '../../services/api';
import { showConfirmationBox } from '../Common/Confirmation';
import { useDispatch, useSelector } from 'react-redux';
import { getUser, updateCompanyId } from '../../redux/userSlice';
import { showErrorToast, showSuccessToast, refresh } from '../../utils/appHelpers';
import styles from '../../utils/styles';

function CompanyDetails({ route, navigation }) {

  const user = useSelector(getUser);
  const dispatch = useDispatch();
  const { company } = route.params;

  const handleConfirmation = (company_id, action) => {
    const isLeaveAction = action === 'leave';
    const apiMethod = isLeaveAction ? api.companyLeave : api.companySelect;
    const title = isLeaveAction ? 'Leave Company' : 'Select Company';

    showConfirmationBox(
      title,
      action,
      async () => {
        try {
          let formData = new FormData();
          formData.append('company_id', [company_id]);
          formData.append('user_id', [user?.id]);
          const response = await apiMethod(formData);

          if (response.status === 200) {
            dispatch(updateCompanyId(response?.company_id));
            refresh('companies');
            navigation.goBack();
          } else {
            showErrorToast(response.message);
          }
        } catch (error) {
          showErrorToast(error.message);
        }
      },
    );
  };

  return (
    <>
      <Header title='Company Information'/>

      <View style={[styles.container]}>
        <ScrollView>
          <View style={[styles.companyTab]}>
            <View style={[styles.companyHeader]}>
              <Icon name='office-building' size={60} style={[styles.companyLogo]}/>
              <Text style={[styles.companyDetailName]}>{company?.access_name ?? "--"}</Text>
            </View>
            
            <View style={[styles.companyDetails]}>
              <Text style={styles.companyTitle}>CONTACT DETAILS</Text>
              <View style={[styles.companyWrapper]}>
                <Icon name='email-outline' style={styles.companyInfoIcon}/>
                <View style={[styles.companyInfoDetails, {flex:1}]}>
                  <Text style={styles.companyTabTitle}>{company?.email ?? "--"}</Text>
                </View>
              </View>

              <View style={styles.companyWrapper}>
                <Icon name='phone' style={styles.personalInfoIcon}/>
                <View style={styles.companyInfoDetails}>
                  <Text style={styles.companyTabTitle}>{company?.company_phone ?? "--"}</Text>
                </View>
              </View>

              <View style={styles.companyWrapper}>
                <Icon name='google-maps' style={styles.personalInfoIcon}/>
                <View style={styles.companyInfoDetails}>
                  <Text style={styles.companyTabTitle}>{company?.address ?? "--"}</Text>
                </View>
              </View>
            </View>
          </View>
        </ScrollView>
      </View>

      <View style={[styles.btnContainer]}>
        <TouchableOpacity
          style={[styles.redbtn, {marginHorizontal:5}]}
          onPress={(e) => {
            e.stopPropagation();
            handleConfirmation(company?.id, 'leave');
          }}>
          <Text style={[styles.Authbtntext, {fontSize:17}]}>
            Leave Company
          </Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

export default CompanyDetails