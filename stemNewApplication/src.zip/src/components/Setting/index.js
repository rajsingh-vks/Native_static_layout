import * as React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/Feather';

import Header from '../Header';
import SpaceBox from '../Common/SpaceBox';
import styles from '../../utils/styles';

function Setting() {
  const navigation = useNavigation();

  return (
    <>
      <Header title='Settings' />
      <View style={[styles.container]}>
        <ScrollView>
          <Text style={styles.settingTitle}>ACCOUNT</Text>
          <TouchableOpacity style={styles.settingTab} onPress={() => navigation.navigate('profile')}>
            <Icon name={'account-outline'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Profile</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingTab} onPress={() => navigation.navigate('availability')}>
            <Icon2 name={'clock'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Availability</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingTab} onPress={() => navigation.navigate('manageLicense')}>
            <Icon name={'file-table-box-multiple-outline'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Manage License</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity>
          <SpaceBox height={20} />

          <Text style={styles.settingTitle}>SECURITY</Text>
          <TouchableOpacity style={styles.settingTab} onPress={() => navigation.navigate('changePassword')}>
            <Icon name={'line-scan'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Change Password</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity>

          <SpaceBox height={20} />
          <Text style={styles.settingTitle}>NOTIFICATIONS</Text>
          {/* <TouchableOpacity style={styles.settingTab} onPress={() => navigation.navigate('company')}>
            <Icon name={'trending-up'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Push</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity> */}
          <TouchableOpacity style={styles.settingTab}>
            <Icon name={'email-variant'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Email</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingTab}>
            <Icon name={'chat-processing-outline'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>SMS</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity>

          <SpaceBox height={20} />
          <Text style={styles.settingTitle}>OTHER SETTINGS</Text>
          <TouchableOpacity style={styles.settingTab}>
            <Icon2 name={'moon'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Appearance</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingTab}>
            <Icon name={'clock-outline'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Time Format</Text>
            <Icon name={'chevron-right'} size={18} style={styles.secondaryIcon} />
          </TouchableOpacity>
        </ScrollView>
      </View>
    </>
  );
}

export default Setting