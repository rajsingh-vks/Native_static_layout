import React from "react";
import { View, Text, TouchableOpacity, Linking } from "react-native";
import Icon from "react-native-vector-icons/MaterialCommunityIcons";

const FileType = ({ url }) => {
  if (!url) return null;

  const extension = url.split(".").pop()?.toLowerCase();

  const fileTypeIcons = {
    image: ["image", ["jpg", "jpeg", "png", "gif"]],
    video: ["video", ["mp4", "webm", "ogg"]],
    word: ["file-word-box", ["doc", "docx", "txt"]],
    excel: ["file-excel-box", ["xls", "xlsx"]],
    powerpoint: ["file-powerpoint-box", ["ppt", "pptx"]],
    pdf: ["file-pdf-box", ["pdf"]], // Updated PDF icon
  };

  const fileType = Object.entries(fileTypeIcons).find(([_, [, extensions]]) =>
    extensions.includes(extension)
  )?.[0];

  const iconName = fileTypeIcons[fileType]?.[0] || "file-outline"; 


  const handleFilePress = () => {
    Linking.openURL(url).catch((err) => console.error("Failed to open file:", err));
  };

  return (
    <TouchableOpacity onPress={handleFilePress}>
      <View style={{ alignItems: "center", margin: 5 }}>
        <Icon name={iconName} size={40} color="#007BFF" />
        <Text style={{ fontSize: 12, color: "#555", marginTop: 5 }}>
          {extension.toUpperCase()}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

export default FileType;
