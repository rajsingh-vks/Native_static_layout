import React from 'react';
import { Modal, View, Text, ActivityIndicator } from 'react-native';
import Lottie from 'lottie-react-native';
import { useSelector } from 'react-redux';

import { getSpinner } from '../../redux/appSlice';
import styles from '../../utils/styles';

const OverlayLoader = () => {
  const visible = useSelector(getSpinner);
  return (
    <Modal visible={visible} transparent>
      <View style={styles.overlayLayout}>
        <View style={styles.activityWrapper}>
          {/* <ActivityIndicator size={50} color={"#1384bd"} /> */}
          <Lottie
            style={styles.loaderIcon}
            source={require('../../assets/lottie/loader.json')}
            autoPlay
            loop
            speed={1.5}
            colorFilters={[
              {
                keypath: 'circle1',
                color: '#1e2f97',
              },
              {
                keypath: 'circle2',
                color: '#5840bb',
              },
              {
                keypath: 'circle3',
                color: '#1aa7ec',
              },
              {
                keypath: 'circle4',
                color: '#45a8d9',
              },
            ]}
          />
        </View>
      </View>
    </Modal>
  );
};

export default OverlayLoader;