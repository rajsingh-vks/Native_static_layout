import React, { useState } from 'react';
import { FlatList, Modal, Platform, StyleSheet, Text, TextInput, TouchableOpacity, View, } from 'react-native';
import moment from 'moment';
import { Label } from '@react-navigation/elements';
import Icon from 'react-native-vector-icons/AntDesign';

import appStyles from '../../utils/appStyles';
import appColors from '../../utils/appColors';

const SelectComponent = ({
    label = null,
    options = [],
    value = null,
    // selectedValue = null,
    required = false,
    placeholder = 'Select an option',
    disabled = false,
    onSelect = () => null,
  }) => {
  const [date, setDate] = useState(new Date());
  const [showModal, setShowModal] = useState(false);
  const [selectedValue, setSelectedValue] = useState(false);

  const showSelect = () => setShowModal(true);
  const closeSelect = () => setShowModal(false);

  const selectOption = (value) => {
    onSelect(value);
    setSelectedValue(value);
    closeSelect();
  };

  return (
    <View style={{ paddingVertical: 10 }}>
      {label && (
        <Label style={[styles.label]}>
          {label}
          {required && <Text style={appStyles.textDanger}> *</Text>}
        </Label>
      )}
      <TouchableOpacity onPress={showSelect} style={styles.dropdownButton}>
        <Text style={styles.selectedText}>
          {selectedValue ? selectedValue.label : placeholder}
        </Text>
        <Icon name="down" size={20} color="black" />
      </TouchableOpacity>

      {/* Show Date Picker */}
      {showModal && (
        <Modal
          visible={showModal}
          transparent
          animationType="fade"
          onRequestClose={() => setShowModal(false)}>
          <TouchableOpacity
            style={styles.modalBackdrop}
            activeOpacity={1}
            onPress={() => setShowModal(false)}>
            <View style={[styles.modalContainer, { height: Math.min(options.length * 50, 450) }]}>
              <FlatList
                data={options}
                keyExtractor={(item) => item.value}
                style={{height:200}}
                renderItem={({ item }) => (
                  <TouchableOpacity
                    style={styles.optionItem}
                    onPress={() => selectOption(item)}>
                    <Text style={styles.optionText}>{item.label}</Text>
                  </TouchableOpacity>
                )}
              />
            </View>
          </TouchableOpacity>
        </Modal>
      )}
    </View>
  );
};

export default SelectComponent;

const styles = StyleSheet.create({
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: appColors.themeBlueText,
    textAlign: 'left',
    marginVertical: 5
  },
  container: {
    width: '90%',
  },
  dropdownButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 12,
    borderRadius: 5,
    backgroundColor: 'white',
  },
  selectedText: {
    fontSize: 16,
    color: '#333',
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)', // Dark backdrop
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '80%',
    backgroundColor: 'white',
    borderRadius: 10,
    paddingVertical: 10,
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 3 },
    height:'auto',
    maxHeight:500,
  },
  optionItem: {
    // alignContent:'flex-start',
    // alignSelf:'flex-start',
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    textAlign:'left',
    padding: 15,
  },
  optionText: {
    fontSize: 16,
    textAlign: 'center',
  },
  appContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});