import { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, View, Text, TouchableOpacity, Image } from 'react-native';
import moment from 'moment';

import styles from '../../utils/styles';
import appColors from '../../utils/appColors';

const ClockTimer = ({
  maxDuration = 0,
  hours = 0,
  minutes = 0,
  seconds = 0,
  enabled = false,
}) => {
  const [chours, setHours] =  useState(hours);
  const [cminutes, setMinutes] =  useState(minutes);
  const [cseconds, setSeconds] =  useState(seconds);
  const [totalSeconds, setTotalSeconds] = useState(0);

  const extractTime = (duration = '') => {
    // Split by colon to get hours, minutes, and seconds
    // const [hours, minutes, seconds] = maxDuration.split(":");
  
    // Convert to numbers
    // const hrs = parseInt(hours, 10);
    // const mins = parseInt(minutes, 10);
    // const secs = Math.floor(parseFloat(seconds)); // Remove milliseconds
  
    // return { hrs, mins, secs };

    const [hours, minutes, seconds] = duration.split(":").map(Number);
    return { hrs: hours || 0, mins: minutes || 0, secs: Math.floor(seconds) || 0 };
  };

  useEffect(() => {
    if (!enabled) return; 

    const interval = setInterval(() => {
      setSeconds((prevSeconds) => {
        if (prevSeconds + 1 === 60) {
          setMinutes((prevMinutes) => {
            if (prevMinutes + 1 === 60) {
              setHours((prevHours) => prevHours + 1);
              return 0;
            }
            return prevMinutes + 1;
          });
          return 0;
        }
        return prevSeconds + 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [enabled]);

  useEffect(() => {
    console.log(maxDuration);
    if(maxDuration != ''){
      const {hrs, mins, secs} =  extractTime(maxDuration);

      setHours(hrs);
      setMinutes(mins);
      setSeconds(secs);
    }
  }, [maxDuration]);

  return(
    <>
      <View style={[styles.checkinoutcard, {padding: 0}]}>
        <View style={{flex: 1}}>
          <Text style={[styles.textSecondary, {fontSize:13}]}>
            Today's Shift
          </Text>
          <Text style={[styles.userDetailsTitle, { color: '#000', fontSize:15 }]}>
            {moment().format('DD MMM, YYYY')}
          </Text>
        </View>
        <View style={{ flexDirection: 'row' }}>
          <Text style={[styles.timerBackground, {backgroundColor: enabled?appColors.curDate:appColors.placeholderColor}]}>
          {Math.abs(chours || 0).toString().padStart(2, '0')}
          </Text>
          <Text style={[styles.timerBackground, {backgroundColor: enabled?appColors.curDate:appColors.placeholderColor}]}>
          {Math.abs(cminutes || 0).toString().padStart(2, '0')}
          </Text>
          <Text style={[styles.timerBackground, {backgroundColor: enabled?appColors.curDate:appColors.placeholderColor}]}>
          {Math.abs(cseconds || 0).toString().padStart(2, '0')}
          </Text>
        </View>
      </View>
    </>
  )
}

export default ClockTimer;