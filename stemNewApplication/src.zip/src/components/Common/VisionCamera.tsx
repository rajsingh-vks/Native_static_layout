import React, { useEffect, useState, useRef, useCallback } from "react";
import {
  View,
  StyleSheet,
  TouchableOpacity,
  Image,
  ActivityIndicator,
} from "react-native";
import { Camera, useCameraDevice, PhotoFile, CameraDevice } from "react-native-vision-camera";
import Modal from "react-native-modal";
import {
  createFileObjectFromPath,
  showErrorToast,
} from "../../utils/appHelpers";
import Icon from "react-native-vector-icons/Ionicons";
import ImageResizer from "@bam.tech/react-native-image-resizer";

interface VisionCameraProps {
  show: boolean;
  setShow: (visible: boolean) => void;
  onCapture: (file: any) => void;
  coordinates?: { latitude: number; longitude: number };
  processImage?: boolean;
  cameraPrefrence?: "front" | "back";
}

const VisionCamera: React.FC<VisionCameraProps> = ({
  show,
  setShow,
  onCapture,
  coordinates,
  processImage = true,
  cameraPrefrence = "front",
}) => {
  const cameraRef = useRef<Camera>(null);
  const [imageSource, setImageSource] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [permissionGranted, setPermissionGranted] = useState(false);
  const [showCamera, setShowCamera] = useState(true);

  const frontDevice = useCameraDevice("front");
  const backDevice = useCameraDevice("back");
  const [cameraType, setCameraType] = useState<"front" | "back">(cameraPrefrence);

  const getPermission = useCallback(async () => {
    const permission = await Camera.requestCameraPermission();
    if (permission === "authorized" || permission === "granted") {
      setPermissionGranted(true);
    } else {
      showErrorToast("Please allow camera access to take a selfie.");
      closeCamera();
    }
  }, []);

  useEffect(() => {
    if (show) {
      setShowCamera(true);
      setImageSource(null); // Reset previous image on re-opening
      getPermission();
    }
  }, [show, getPermission]);

  const capturePhoto = async () => {
    if (!cameraRef.current) {
      showErrorToast("Camera error. Please restart your device.");
      return;
    }

    try {
      const photo: PhotoFile = await cameraRef.current.takePhoto({
        enableShutterSound: false,
      });

      setProcessing(true);
      setImageSource(photo.path);

      if (processImage) {
        const resizedPhoto = await resizeImage(`file://${photo.path}`, coordinates!);
        if (resizedPhoto) {
          setImageSource(resizedPhoto.uri); // Show processed image preview
        } else {
          showErrorToast("Error processing image.");
        }
      }

      setProcessing(false);
    } catch (error) {
      showErrorToast("Failed to capture photo.");
      setProcessing(false);
    }
  };

  const savePhoto = () => {
    if (!imageSource) {
      closeCamera();
      showErrorToast("Unable to process image.");
      return;
    }
    onCapture(createFileObjectFromPath(imageSource));
    closeCamera();
  };

  const resizeImage = async (imagePath: string, coordinates?: { latitude: number; longitude: number }) => {
    try {
      const resizedImage = await ImageResizer.createResizedImage(imagePath, 800, 800, "JPEG", 100);
      return resizedImage; // Contains { uri, path, size, width, height }
    } catch (error) {
      console.error("Error resizing image:", error);
      return null;
    }
  };

  const closeCamera = () => {
    setShow(false);
    setShowCamera(false);
  };

  const retakePhoto = () => {
    setImageSource(null);
    setShowCamera(true);
  };

  return (
    <Modal isVisible={show} style={styles.container} onBackButtonPress={closeCamera}>
      {imageSource ? (
        // **Show Image Preview**
        <View style={styles.previewContainer}>
          <Image source={{ uri: imageSource }} style={styles.previewImage} />
          {processing && <ActivityIndicator size="large" color="white" style={styles.loader} />}
          <View style={styles.buttonContainer}>
            <TouchableOpacity onPress={retakePhoto}>
              <Icon name="refresh" size={35} color="white" />
            </TouchableOpacity>
            <TouchableOpacity onPress={savePhoto} style={styles.saveButton}>
              <Icon name="checkmark-circle" size={35} color="white" />
            </TouchableOpacity>
          </View>
        </View>
      ) : (
        // **Show Camera View**
        <>
          {showCamera && (
            <Camera
              ref={cameraRef}
              style={[StyleSheet.absoluteFill, { height: "80%" }]}
              device={(cameraType === "front" ? frontDevice : backDevice) as CameraDevice}
              isActive={showCamera}
              photo
              enableZoomGesture
            />
          )}
          <View style={styles.buttonContainer}>
            <TouchableOpacity onPress={closeCamera}>
              <Icon name="close-circle-outline" size={35} color="white" />
            </TouchableOpacity>
            <TouchableOpacity onPress={capturePhoto} style={styles.camButton} />
            <TouchableOpacity onPress={() => setCameraType(cameraType === "front" ? "back" : "front")}>
              <Icon name="camera-reverse-outline" size={35} color="white" />
            </TouchableOpacity>
          </View>
        </>
      )}
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000", margin: 0, padding: 0 },
  buttonContainer: { 
    position: "absolute", 
    bottom: 0, 
    width: "100%", 
    height: "20%", 
    flexDirection: "row", 
    justifyContent: "space-between", 
    alignItems: "center", 
    paddingHorizontal: 28 
  },
  camButton: { 
    width: 70, 
    height: 70, 
    borderRadius: 35, 
    borderWidth: 4, 
    borderColor: "white", 
    opacity: 0.7 
  },
  previewContainer: {
    flex: 1,
    backgroundColor: "black",
    justifyContent: "center",
    alignItems: "center",
  },
  previewImage: {
    width: "90%",
    height: "80%",
    borderRadius: 10,
  },
  saveButton: {
    backgroundColor: "green",
    padding: 10,
    borderRadius: 20,
  },
  loader: {
    position: "absolute",
    top: "50%",
    left: "50%",
  },
});

export default VisionCamera;
