import React, { useState } from 'react';
import { Modal, Platform, StyleSheet, Text, TextInput, TouchableOpacity, View, } from 'react-native';
import { Label } from '@react-navigation/elements';
import DateTimePicker from '@react-native-community/datetimepicker';
import moment from 'moment';
import Icon from 'react-native-vector-icons/AntDesign';

import appStyles from '../../utils/appStyles';
import appColors from '../../utils/appColors';

const DateComponent = ({
    label = null,
    value = null,
    required = false,
    disabled = false,
    maxDate = null,
    minDate = null,
    dateFormat = 'YYYY-MM-DD',
    visibleDateFormat = 'DD-MM-YYYY',
    onChange = val => null,
  }) => {
  const [date, setDate] = useState(new Date());
  const [showModal, setShowModal] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');

  const showDatePicker = () => setShowModal(true);
  const closeDatePicker = () => setShowModal(false);

  return (
    <View style={{ paddingVertical: 10 }}>
      {label && (
        <Label style={styles.label}>
          {label}
          {required && <Text style={appStyles.textDanger}> *</Text>}
        </Label>
      )}
      <TouchableOpacity onPress={showDatePicker} style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="YYYY-MM-DD"
          value={selectedDate? moment(selectedDate, dateFormat).format(visibleDateFormat) : ''}
          editable={false}
        />
        <Icon name="calendar" size={24} color="black" />
      </TouchableOpacity>

      {/* Show Date Picker */}
      {showModal && (
        <Modal visible={showModal} transparent animationType="fade">
          <View style={styles.modalBackground}>
            <View style={styles.modalContainer}>
              {/* {Platform.OS === 'ios' && (
                <TouchableOpacity onPress={closeDatePicker} style={styles.closeButton}>
                  <Text style={{ color: 'white', fontSize: 16 }}>Done</Text>
                </TouchableOpacity>
              )} */}

              <DateTimePicker
                value={date}
                mode="date"
                minimumDate={minDate ? new Date(minDate) : null}
                maximumDate={maxDate ? new Date(maxDate) : null}
                display={Platform.OS === 'ios' ? 'inline' : 'calendar'}
                onChange={(event, selectedDate) => {
                  closeDatePicker();
                  
                  if (selectedDate) {
                    // setDate(selectedDate);
                    setSelectedDate(selectedDate.toISOString().split('T')[0]);
                    onChange(selectedDate.toISOString().split('T')[0]); // Format as YYYY-MM-DD
                  }
                  // if (Platform.OS === 'android') setShowModal(false); // Close modal on Android after selection
                }}
              />
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
};

export default DateComponent;

const styles = StyleSheet.create({
  label: {
    color: appColors.labelColor,
    fontSize: 16,
    fontWeight: 'bold',
    color: appColors.themeBlueText,
    textAlign: 'left',
    marginVertical: 5
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 5,
  },
  input: {
    flex: 1,
    fontSize: 16,
  },
  modalBackground: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)', // Dark backdrop
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    elevation: 5, // Android shadow
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 3 },
  },
  closeButton: {
    backgroundColor: appColors.blueHeader,
    padding: 10,
    alignSelf: 'flex-end',
    borderRadius: 5,
  },
});
