import { useEffect, useState } from 'react';
import { View, Text, Platform, Linking, TouchableOpacity, StyleSheet } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import Modal from 'react-native-modal';
import Icon2 from 'react-native-vector-icons/AntDesign';

import SpaceBox from '../SpaceBox';
import { getLocationServiceModal, setLocationServiceModal } from '../../../redux/modalSlice';
import { modalProps } from '../../../utils/appHelpers';
import appColors from '../../../utils/appColors';
import appStyles from '../../../utils/appStyles';
import location from '../../../utils/locationHelper';

// import Button from '../Buttons/Button';
// import LocationOFFIcon from '../../../assets/svg/location-off.svg'

const LocationServicesModal = () => {
  const isVisible = useSelector(getLocationServiceModal);
  const dispatch = useDispatch();

  const closeModal = () => {
    dispatch(setLocationServiceModal(false))
  }

  const openSettings = () => {
      closeModal();
      if (Platform.OS === 'android') {
        // Linking.openURL('android.settings.LOCATION_SOURCE_SETTINGS');
        location.openServiceSettings();
        // Linking.openSettings().catch(() => {
        //   Alert.alert('Unable to open settings');
        // });
      } else {
        Linking.openURL('app-settings:');
      }
  };

  return (
    isVisible && (
      <View style={styles.modalOverlay}>
        <Modal
          {...modalProps.zoom}
          isVisible={isVisible}
          style={[/*appStyles.modalContainer,*/ {margin:'auto'}]}>
          <View
            style={[
              appStyles.modalBox,
              appStyles.overflowHidden,
              {
                minWidth: 250,
                maxWidth: 265,
                padding: 0,
                borderRadius: 6,
              },
            ]}>
            <View style={[styles.modalContent]}>
                <SpaceBox height={10} />
                {/* <LocationOFFIcon height={90} /> */}
                <Icon2
                  name="warning"
                  size={40}
                  style={{ color: appColors.orange, fontWeight: 'bold', justifyContent: 'center' }}
                />
                <SpaceBox height={10} />
                <Text style={[{ color: appColors.dark600, fontSize: 14, fontWeight:'bold',},]}>
                  Location is OFF
                </Text>
                <SpaceBox height={10} />
                <Text
                  style={[
                    {
                      // marginTop: -15,
                      color: appColors.dark300,
                      fontSize: 13,
                    },
                  ]}>
                    Enable location services for better experience.
                </Text>
                <SpaceBox height={20} />

                <TouchableOpacity 
                  style={{backgroundColor:appColors.green, paddingHorizontal:15, paddingVertical:10, borderRadius:9}} 
                  onPress={openSettings}>
                  <Text style={{color:'#FFF', fontWeight:'bold'}}>ENABLE LOCATION</Text>
                </TouchableOpacity>
                {/* <Button
                    size={17}
                    rounded
                    color={appColors.blue}
                    value="ENABLE LOCATION"
                    onPress={openSettings}
                    textStyle={[appStyles.ff_Roboto_Medium]}
                    style={[appStyles.px4, appStyles.py2]}
                /> */}
                <SpaceBox height={10} />
            </View>
          </View>
        </Modal>
      </View>
    )
  );
};

export default LocationServicesModal;

const styles = StyleSheet.create({
  modalOverlay: {
    // flex: 1,
    // justifyContent: "center",
    // alignItems: "center",
  },
  modalContent: {
    paddingHorizontal: 20,
    paddingVertical:15,
    backgroundColor: "white",
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    elevation: 5, // Shadow for Android
    shadowColor: "#000", // Shadow for iOS
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  modalText: {
    fontSize: 18,
    marginBottom: 20,
  },
  closeButton: {
    backgroundColor: '#eee',
    paddingHorizontal: 10,
    paddingVertical:6,
    borderRadius: 5,
    marginTop:10,
  },
  closeButtonText: {
    color: appColors.dark500,
    fontSize:13,
    fontWeight: "bold",
    letterSpacing:0.6,
  },
});
