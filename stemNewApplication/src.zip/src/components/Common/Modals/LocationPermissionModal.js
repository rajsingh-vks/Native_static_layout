import { Alert, View, Text, Platform, Linking, TouchableOpacity } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import Modal from 'react-native-modal';
import SpaceBox from '../SpaceBox';
import { getLocationPermissionModal, setLocationPermissionModal } from '../../../redux/modalSlice';
import appColors from '../../../utils/appColors';
import appStyles from '../../../utils/appStyles';
import Icon from 'react-native-vector-icons/Entypo';

const LocationPermissionModal = () => {
  const isVisible = useSelector(getLocationPermissionModal);
  const dispatch = useDispatch();

  const closeModal = () => {
    dispatch(setLocationPermissionModal(false))
  }

  const openSettings = () => {
    try {
      closeModal();
      setTimeout(() => {
        if (Platform.OS === 'android') {
          Linking.openSettings().catch(() => {
            Alert.alert('Unable to open settings');
          });
        } else if (Platform.OS === 'ios') {
          Linking.openURL('app-settings:').catch(() => {
            Alert.alert('Unable to open settings');
          });
        }
      }, 500);
    } catch (error) {
      Alert.alert(error.message);
    }
  };

  return (
    <View>
      <Modal
        useNativeDriver
        useNativeDriverForBackdrop        
        isVisible={isVisible}
        style={[appStyles.flexCenter]}
        onBackdropPress={closeModal}>
        <View
          style={[
            appStyles.modalBox,
            appStyles.overflowHidden,
            {
              minWidth: 250,
              maxWidth: 280,
              padding: 0,
              borderRadius: 6,
            },
          ]}>
          <View style={[appStyles.alignItemsCenter]}>
            <SpaceBox height={25} />
            <Icon name="location" size={50} color={appColors.dark300} style={appStyles.alignSelfCenter} />
            <SpaceBox height={15} />
            <Text
              style={[
                appStyles.textCenter,
                appStyles.py1,
                appStyles.lineHeight,
                appStyles.ff_Poppins_Regular,
                {
                  color: appColors.dark300,
                  fontSize: 13,
                  marginHorizontal: 30
                },
              ]}>
              Your location permission is disabled. Please enable it to continue.
            </Text>
            <SpaceBox height={5} />
            <Text
              style={[
                appStyles.textCenter,
                appStyles.px5,
                appStyles.ff_Poppins_Regular,
                {
                  color: appColors.dark600,
                  fontSize: 13,
                },
              ]}>
              Instructions to Enable Location Permissions
            </Text>
            <SpaceBox height={5} />
            {Platform.OS === 'android' && (
              <Text
                style={[
                  appStyles.textCenter,
                  appStyles.lineHeight,
                  appStyles.ff_Poppins_Medium,
                  {
                    color: appColors.dark300,
                    fontSize: 12,
                    paddingHorizontal: 30
                  },
                ]}>
                Open Settings {'>'} Permissions {'>'} Location {'>'} select "Allow all the time"
              </Text>
            )}
            {Platform.OS === 'ios' && (
              <Text
                style={[
                  appStyles.textCenter,
                  appStyles.px5,
                  appStyles.lineHeight,
                  appStyles.ff_Poppins_Medium,
                  {
                    color: appColors.dark300,
                    fontSize: 12,
                  },
                ]}>
                Go to Settings {'>'} Guardix {'>'} Location {'>'} Always
              </Text>
            )}
            <SpaceBox height={15} />

            <TouchableOpacity onPress={openSettings}>
              <Text style={{color: appColors.blue, fontWeight: 600}}>OPEN SETTINGS</Text>
            </TouchableOpacity>           
            <SpaceBox height={30} />
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default LocationPermissionModal;
