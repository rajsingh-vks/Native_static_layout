import { useEffect, useState, useRef } from 'react';
import {Text} from 'react-native';
import Stylesheet from '../../utils/styles';
import moment from 'moment';

const OtpTimer = ({active, timer, onComplete = () => null}) => {
  const [seconds, setSeconds] = useState(timer);
  const [isTimerActive, setIsTimerActive] = useState(active ? active : false);
  const countDownRef = useRef(null); 
  
  // useEffect(() => {
  //   if (isTimerActive) {
  //     countDownRef.current = setInterval(() => {
  //       setSeconds((prevSeconds) => {
  //         if (prevSeconds <= 1) {
  //           clearInterval(countDownRef.current);
  //           setIsTimerActive(false);
  //           onComplete(true);
  //           return 0;
  //         }
  //         return prevSeconds - 1;
  //       });
  //     }, 1000);
  //   }

  //   return () => clearInterval(countDownRef.current);
  // }, [isTimerActive]);

  useEffect(() => {
    if (isTimerActive) {
      countDownRef.current = setInterval(() => {
        setSeconds((prevSeconds) => prevSeconds - 1);
      }, 1000);
    }

    return () => clearInterval(countDownRef.current);
  }, [isTimerActive]);

  useEffect(() => {
    if (seconds <= 0 && isTimerActive) {
      clearInterval(countDownRef.current);
      setIsTimerActive(false);
      onComplete(true);
    }
  }, [seconds, isTimerActive, onComplete]);
  
  if (seconds > 0) {
    return (
      <Text style={{fontSize:14, fontWeight:'600'}}> 
        Resend in <Text style={[Stylesheet.otpCounter, {fontSize:14}]}>00 : {(seconds || '00').toString().padStart(2, '0')}</Text>
      </Text>
    );
  }
};

export default OtpTimer;
