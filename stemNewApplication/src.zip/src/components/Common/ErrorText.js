import React from 'react';
import {StyleSheet, Text, View} from 'react-native';
import appColors from '../../utils/appColors';

const ErrorText = ({
  error = null,
  align = 'left',
  style = {},
  textStyle = {},
  fill = false,
}) => {
  return (
    <>
      {typeof error == 'string' && (
        <View
          style={[
            styles.errorBox,
            style,
            fill
              ? {backgroundColor: '#ff00001c', borderRadius: 5, padding: 5}
              : null,
          ]}>
          <Text style={[styles.errorTxt, {textAlign: align}, textStyle]}>
            {error}
          </Text>
        </View>
      )}

      {Array.isArray(error) && error[0] && (
        <View
          style={[
            styles.errorBox,
            style,
            fill
              ? {backgroundColor: '#ff00001c', borderRadius: 5, padding: 5}
              : null,
          ]}>
          <Text style={[styles.errorTxt, {textAlign: align}, textStyle]}>
            {error[0]}
          </Text>
        </View>
      )}
    </>
  );
};

export default ErrorText;

const styles = StyleSheet.create({
  errorBox: {
    width: '100%',
    marginTop: 2,
  },
  errorTxt: {
    color: appColors.red,
    fontSize: 12,
    marginStart: 5,
  },
});
