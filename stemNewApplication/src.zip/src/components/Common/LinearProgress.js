import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, TouchableWithoutFeedback, Image, Keyboard, KeyboardAvoidingView, Platform, ScrollView, } from 'react-native';

import appColors from '../../utils/appColors';

const LinearProgress = ({strength}) => {
  const [color, setColor] = useState('#000000');

  useEffect(() => {
    if(strength > 0 && strength <= 0.5){
      setColor(appColors.red);
    }
    if(strength > 0.5){
      setColor(appColors.orange);
    }
    if(strength >= 1){
      setColor(appColors.green);
    }
  }, [strength]);

  return (
    <>
      <View style={{alignItems:'flex-end'}}>
        <View style={{flexDirection:'row', height:5, marginVertical:10, opacity:0.5,}}>
          {[...Array(8)].map((_, index) => (
            <View
              key={index}
              style={{
                flex: 1,
                marginRight: 2,
                backgroundColor: index < strength * 8 ? color : "#d3d3d3", // Color for filled segments
                borderRadius: 5,
              }}
            />
          ))}
        </View>
      </View>
    </>
  );
}

export default LinearProgress;