import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity,} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import Lottie from 'lottie-react-native';
import Modal from 'react-native-modal';

import { getPopupModal, setPopupModal } from '../../redux/appSlice';
import appStyles from '../../utils/appStyles';
import appColors from '../../utils/appColors';
import { hidePopup, modalProps } from '../../utils/appHelpers';
import SpaceBox from './SpaceBox';
// import ScreenLoader from './Loaders/ScreenLoader';

const ShowPopup = () => {
  const popup = useSelector(getPopupModal);
  const dispatch = useDispatch();
  const isCloseEnable = () => {
    if (popup.type == 'success' || popup.type == 'error') {
      return true;
    } else {
      return false;
    }
  };

  let message_text = popup?.message;
  let message_search = popup?.message?.toLowerCase();

  if (
    message_search?.search('network error') >= 0 ||
    message_search?.search('timeout') >= 0
  ) {
    message_text = 'Check your network and try again.';
  }

  if (message_search?.search('status code 500') >= 0) {
    message_text = `Sorry, we couldn't process your request. Please try again.`;
  }

  const handleClose = () => {
    dispatch(
      setPopupModal({
        visible: false,
        message: '',
        type: '',
      }),
    );
  }

  return (
    popup.visible && (
      <View style={styles.container}>
        <Modal
          {...modalProps.zoom}
          isVisible={popup.visible}
          style={[{margin:0}]}
          onBackdropPress={() => (isCloseEnable() ? hidePopup() : null)}>
          <View style={[styles.modalOverlay]}>
            <View style={[styles.modalContent, {marginHorizontal:20}]}>
              <View style={[appStyles.alignItemsCenter]}>
                {popup.type == 'loading' && (
                  <View style={{ height: 130 }}>
                    {/* <ScreenLoader /> */}
                    <Text>Loading...</Text>
                  </View>
                )}
                {popup.type == 'success' && (
                  <Lottie
                    source={require('../../assets/lottie/check.json')}
                    autoPlay={true}
                    loop={false}
                    style={[{height: 100, width: 100, marginTop:-15}]}
                  />
                )}
                {popup.type == 'error' && (
                  <Lottie
                    source={require('../../assets/lottie/error.json')}
                    autoPlay={true}
                    loop
                    style={[{height: 50, width: 50}, appStyles.mb3]}
                  />
                )}
                <Text
                  style={[
                    appStyles.textCenter,
                    appStyles.px5,
                    appStyles.py1,
                    appStyles.lineHeight,
                    {
                      marginTop: -15,
                      color: appColors.dark300,
                      fontSize: 15,
                    },
                  ]}>
                  {message_text}
                </Text>
              </View>
              {isCloseEnable() ? (
                <TouchableOpacity
                  onPress={() => {handleClose();}}
                  style={[styles.closeButton]}
                  activeOpacity={0.4}>
                  <Text
                    style={[
                      appStyles.textCenter,
                      styles.closeButtonText,
                    ]}>
                    CLOSE
                  </Text>
                </TouchableOpacity>
              ) : (
                <SpaceBox height={20} />
              )}
            </View>
          </View>
        </Modal>
      </View>
    )
  );
};

export default ShowPopup;

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    paddingHorizontal: 10,
    paddingTop:5,
    paddingBottom:15,
    backgroundColor: "white",
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    elevation: 5, // Shadow for Android
    shadowColor: "#000", // Shadow for iOS
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  modalText: {
    fontSize: 18,
    marginBottom: 20,
  },
  closeButton: {
    backgroundColor: '#eee',
    paddingHorizontal: 10,
    paddingVertical:6,
    borderRadius: 5,
    marginTop:10,
  },
  closeButtonText: {
    color: appColors.dark500,
    fontSize:13,
    fontWeight: "bold",
    letterSpacing:0.6,
  },
});
