import { View } from 'react-native';
import React from 'react';

const SpaceBox = ({ height = 42, width = '100%', backgroundColor = "transparent" }) => {
  return <View style={{ height, width, backgroundColor }}></View>;
};

export default SpaceBox;
