import { Alert } from "react-native";

export const showConfirmationBox = (title, actionMessage, onConfirm, onCancel) => {
  console.log(title);
  

  
  const baseMessage = `Are you sure you want to `;
  
  Alert.alert(
    title || 'Confirmation',
    `${baseMessage}${title}`,
    [
      {
        text: 'Cancel',
        onPress: onCancel || (() => console.log('Cancelled')), 
        style: 'cancel',
      },
      {
        text: 'OK',
        onPress: onConfirm || (() => console.log('Confirmed')), 
      },
    ],
    { cancelable: false }
  );
};
