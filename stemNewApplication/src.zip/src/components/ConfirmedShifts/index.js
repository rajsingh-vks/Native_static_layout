import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, RefreshControl, ScrollView } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import styles from '../../utils/styles';
import SpaceBox from '../Common/SpaceBox';
import { useNavigation } from '@react-navigation/native';

function ConfirmedShifts() {
  const navigation = useNavigation();
  return (
    <>
      <Header title='Confirmed Shifts' />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
            // onRefresh={getCompanies}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>
          <View>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
              onPress={() => navigation.navigate('shiftsDetails')}
            >
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc', left: '0', height: '60%', top: '40%' }]}></View>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <Text style={[styles.companyName, { fontSize: 18 }]}>
                    National Utilities
                  </Text>
                  <SpaceBox height={5} />
                  <View style={{ flexDirection: 'row' }}>
                    <Icon
                      name={'location-pin'}
                      size={16}
                      style={{ color: '#1d61f4', marginTop: 2 }}
                    />
                    <Text style={styles.companyEmail}>
                      1700 Hickory Dr, Fort Worth, TX 76117, USA
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row' }]}>
                  <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                    <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                      <Icon2
                        name={'calendar-today'}
                        size={22}
                        style={{ color: '#1d61f4' }}
                      />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16 }}>Date</Text>
                      <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>2024-01-25</Text>
                    </View>
                  </View>
                  <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                    <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                      <Icon2
                        name={'clock'}
                        size={22}
                        style={{ color: '#1d61f4' }}
                      />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16 }}>Date</Text>
                      <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>09:00A.M - 07:00 P.M</Text>
                    </View>
                  </View>
                </View>

              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
            // onPress={() => navigation.navigate('postDetails', { site })}
            >
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc', left: '0', height: '60%', top: '40%' }]}></View>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <Text style={[styles.companyName, { fontSize: 18 }]}>
                    National Utilities
                  </Text>
                  <SpaceBox height={5} />
                  <View style={{ flexDirection: 'row' }}>
                    <Icon
                      name={'location-pin'}
                      size={16}
                      style={{ color: '#1d61f4', marginTop: 2 }}
                    />
                    <Text style={styles.companyEmail}>
                      1700 Hickory Dr, Fort Worth, TX 76117, USA
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row' }]}>
                  <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                    <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                      <Icon2
                        name={'calendar-today'}
                        size={22}
                        style={{ color: '#1d61f4' }}
                      />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16 }}>Date</Text>
                      <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>2024-01-25</Text>
                    </View>
                  </View>
                  <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                    <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                      <Icon2
                        name={'clock'}
                        size={22}
                        style={{ color: '#1d61f4' }}
                      />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16 }}>Date</Text>
                      <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>09:00A.M - 07:00 P.M</Text>
                    </View>
                  </View>
                </View>

              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
            // onPress={() => navigation.navigate('postDetails', { site })}
            >
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc', left: '0', height: '60%', top: '40%' }]}></View>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <Text style={[styles.companyName, { fontSize: 18 }]}>
                    National Utilities
                  </Text>
                  <SpaceBox height={5} />
                  <View style={{ flexDirection: 'row' }}>
                    <Icon
                      name={'location-pin'}
                      size={16}
                      style={{ color: '#1d61f4', marginTop: 2 }}
                    />
                    <Text style={styles.companyEmail}>
                      1700 Hickory Dr, Fort Worth, TX 76117, USA
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row' }]}>
                  <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                    <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                      <Icon2
                        name={'calendar-today'}
                        size={22}
                        style={{ color: '#1d61f4' }}
                      />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16 }}>Date</Text>
                      <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>2024-01-25</Text>
                    </View>
                  </View>
                  <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                    <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                      <Icon2
                        name={'clock'}
                        size={22}
                        style={{ color: '#1d61f4' }}
                      />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16 }}>Date</Text>
                      <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>09:00A.M - 07:00 P.M</Text>
                    </View>
                  </View>
                </View>

              </View>
            </TouchableOpacity>

          </View>
        </ScrollView>
      </View>
    </>
  );
}

export default ConfirmedShifts;
