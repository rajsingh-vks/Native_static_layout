import { useState, useRef } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView, RefreshControl, TextInput, KeyboardAvoidingView,
  Platform, FlatList
} from 'react-native';
import { Button } from '@react-navigation/elements';
import Icon from 'react-native-vector-icons/Ionicons';

import Header from '../Header';
import styles from '../../utils/styles';
import SpaceBox from '../Common/SpaceBox';
import appColors from '../../utils/appColors';

function Chat() {
  const [inputText, setInputText] = useState("");
  const flatListRef = useRef(null);

  const [messages, setMessages] = useState([
    { id: "1", text: "Hey! How are you?", sender: "other", time: "10:30 AM" },
    { id: "2", text: "I'm good! What about you?", sender: "me", time: "10:32 AM" },
  ]);
  // Function to get the current time in HH:MM AM/PM format
  const getCurrentTime = () => {
    const now = new Date();
    let hours = now.getHours();
    const minutes = now.getMinutes();
    const ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12 || 12; // Convert 24-hour time to 12-hour format
    return `${hours}:${minutes < 10 ? "0" : ""}${minutes} ${ampm}`;
  };
  const sendMessage = () => {
    if (inputText.trim().length > 0) {
      const newMessage = {
        id: Date.now().toString(),
        text: inputText,
        sender: "me",
        time: getCurrentTime(),
      };
      setMessages([...messages, newMessage]);
      setInputText("");

      // Scroll to the latest message
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  };

  return (
    <>
      <Header title="Post Hoon" />
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.chatContainer}
      >
        {/* Chat Messages */}
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={[styles.message, item.sender === "me" ? styles.myMessage : styles.otherMessage]}>
              <Text style={styles.messageText}>{item.text}</Text>
              <Text style={styles.timeText}>{item.time}</Text>
            </View>
          )}
          contentContainerStyle={styles.chatContainerWrapper}
        />

        {/* Message Input Box */}
        <View style={styles.chatinputContainer}>
          <TextInput
            style={styles.chatInput}
            placeholder="Message..."
            value={inputText}
            onChangeText={setInputText}
          />
          <TouchableOpacity style={styles.sendBtn} onPress={sendMessage}>
            <Icon
              name="arrow-forward"
              size={26}
              style={{ color: appColors.white }}
            />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </>
  );
}

export default Chat