import React, { useState } from "react";
import { View, Text, RefreshControl, ScrollView, TouchableOpacity, ImageBackground } from 'react-native';
import Header from '../Header';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import { useNavigation } from "@react-navigation/native";
import styles from "../../utils/styles";
import SpaceBox from "../Common/SpaceBox";
import Modal from "react-native-modal";

function ExchangeShift() {
  const navigation = useNavigation();


  return (
    <>
      <Header title='Exchange Shift' />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>
          <View>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <Text style={{ fontSize: 18, flex: 1, textAlign: 'center' }}>
                      April, 2024
                    </Text>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <Text style={{ fontSize: 18, flex: 1 }}>
                      #5896
                    </Text>
                    <Text style={[styles.companyEmail, { fontSize: 16, }]}>
                      Mon, Apr 01, 2024 14:51:45
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Post Site</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>Test Demo 1</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Start Time</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>15:00:00</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>End Time</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>1hr 30min</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Shift Hours</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>1hr 30min</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <TouchableOpacity style={[styles.OnBoardingbtn, { marginLeft: 'auto', marginTop: 5, backgroundColor: '#2360FB', paddingHorizontal: 30, flex: 'inherit' }]} onPress={() => navigation.navigate('selectguard')}>
                    <Text style={[styles.OnBoardingbtntext, { color: '#fff', fontSize: 18, letterSpacing: 0.6 }]}>Select Shift</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

export default ExchangeShift;