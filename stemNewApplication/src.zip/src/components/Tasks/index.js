import { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, RefreshControl, ScrollView, StyleSheet, Alert } from 'react-native';
import { convertUTCToLocal, DayOfWeek, PriorityStatus, showErrorToast, showSuccessToast, WeekDaysNames } from '../../utils/appHelpers';
import { useDispatch, useSelector } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/Feather';

import Header from '../Header';
import { showConfirmationBox } from '../Common/Confirmation';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { getRefresh } from '../../redux/refreshSlice';
import styles from '../../utils/styles';

const Index = ({ route, navigation }) => {
  const { siteId } = route.params;

  const dispatch = useDispatch();
  const [tasks, setTasks] = useState([]);
  const [isDataFetched, setIsDataFetched] = useState(false);
  const refresh = useSelector((state) => getRefresh(state, 'tasks'));

  const getTasks = async () => {
    dispatch(setSpinner(true));
    try {
      const response = await api.getPostSiteTask(siteId);

      if (response?.status == 200) {
        setTasks(response.data ?? []);
      } else {
        setTasks([]);
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message || 'Failed to fetch tasks');
    } finally {
      setIsDataFetched(true);
      dispatch(setSpinner(false));
    }
  };

  const handleReminderDelete = async (reminder_id) => {
    showConfirmationBox(
      'Delete Reminder',
      'Are you sure you want to delete this reminder?',
      async () => {
        dispatch(setSpinner(true));
        try {
          const formData = new FormData();
          formData.append('reminder_id', reminder_id);

          const response = await api.deleteReminder(formData);

          if (response.status === 200) {
            const updatedReminders = tasks.filter((item) => item.id !== reminder_id);
            setTasks(updatedReminders);
            showSuccessToast(response?.message || 'Reminder deleted successfully');
          } else {
            showErrorToast(response?.message || 'Failed to delete the reminder');
          }
        } catch (error) {
          showErrorToast(error?.message || 'An error occurred while deleting the reminder');
        } finally {
          dispatch(setSpinner(false));
        }
      }
    );
  };

  const handleConfirmation = async (reminder_id, currentStatus) => {
    const newStatus = currentStatus === '1' ? '0' : '1';
    try {
      const formData = new FormData();
      formData.append('reminder_id', reminder_id);
      formData.append('status', newStatus);

      const response = await api.markReminder(formData);

      if (response?.status === 200) {
        setTasks((prev) =>
          prev.map((reminder) =>
            reminder.id === reminder_id ? { ...reminder, status: newStatus } : reminder
          )
        );
        showSuccessToast(response?.message);
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message);
    }
  };

  useEffect(() => {
    getTasks();
  }, [refresh]);

  return (
    <>
      <Header title="Tasks" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={() => getTasks()}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 50 }}
          showsVerticalScrollIndicator={false}>
          {tasks?.length > 0 && <Text style={styles.settingTitle}>TASKS</Text>}

          {isDataFetched && tasks?.length === 0 ? (
            <View style={styles.noRecordsContainer}>
              <Image
                source={require('../../assets/images/not-found.png')}
                style={styles.noRecordsImage}
              />
              <Text style={styles.noRecordsText}>No Data Found</Text>
            </View>
          ) : (
            tasks?.map((task, index) => (
              // <TouchableOpacity
              //   key={index}
              //   style={[styles.settingTab, {borderRadius:15, marginVertical:0, paddingVertical:5}]}
              //   onPress={() => navigation.navigate('taskDetails', { task })}>
              //   <View style={{flex:1}}>
              //     <Text style={[styles.settingTabTitle, {fontSize:16, fontWeight:'900', marginLeft:0, marginBottom:10}]}>{task?.task_name ?? '--'}</Text>
              //     <Text style={iStyles.subtitle}>
              //       Date: {convertUTCToLocal(task?.created_on, 'MMM DD, YYYY')}
              //     </Text>
              //     <Text style={iStyles.priorityText}>
              //       Scheduled: {WeekDaysNames(task?.schedule_days)}
              //     </Text>

              //   </View>
              //   <View style={{marginBottom:5}}>
              //     <Icon name={'chevron-right'} size={20} style={[styles.roundedGrey, styles.secondaryIcon]} />
              //     <TouchableOpacity
              //       onPress={(e) => {
              //         e.stopPropagation();
              //         handleConfirmation(task?.id, task?.status);
              //       }}
              //       style={{ paddingHorizontal: 10 }}>
              //     </TouchableOpacity>
              //   </View> 
              // </TouchableOpacity>

              <TouchableOpacity
                key={index}
                style={[iStyles.card]}
                onPress={() => navigation.navigate('taskDetails', { task })}>
                <View style={iStyles.leftBorder}></View>

                <View style={iStyles.cardContent}>
                  <View style={iStyles.cardHeader}>
                    <Text style={iStyles.title}>{task?.task_name ?? '--'}</Text>
                    <View style={iStyles.statusContainer}>
                      <Text style={iStyles.statusNumber}> {task?.status?.toUpperCase()}</Text>
                    </View>
                  </View>
                  <View style={iStyles.scheduleContainer}>
                    <Icon name="calendar" size={16} color="#007bff" />
                    <Text style={iStyles.scheduleText}>{WeekDaysNames(task?.schedule_days)}</Text>
                  </View>
                  <View style={iStyles.divider}></View>
                  <Text style={iStyles.description}>
                    {task?.description ? (task?.description.length > 100 ? `${task?.description.slice(0, 100)}...` : task?.description) : ""}
                  </Text>
                </View>
              </TouchableOpacity>


            ))
          )}
        </ScrollView>
      </View>


    </>
  );
}

const iStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollView: {
    flexGrow: 1,
    paddingBottom: 100,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginHorizontal: 15,
    marginVertical: 10,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginHorizontal: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  chevronIcon: {
    color: '#888',
  },
  cardBody: {
    paddingTop: 5,
  },
  subtitle: {
    fontSize: 13,
    color: '#666',
    marginBottom: 5,
  },
  priorityText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#007bff',
    marginBottom: 10,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '900',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 10,
  },
  statusAction: {
    fontSize: 14,
    fontWeight: '600',
  },
  noDataContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  noDataImage: {
    width: 150,
    height: 150,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  noDataText: {
    fontSize: 16,
    color: '#666',
  },
  footer: {
    padding: 15,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  addButton: {
    backgroundColor: '#003c8f', // Dark blue color
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    flexDirection: 'row',
    marginHorizontal: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
    overflow: 'hidden',
  },
  leftBorder: {
    width: 5,
    backgroundColor: '#007bff',
  },
  cardContent: {
    flex: 1,
    padding: 15,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusText: {
    backgroundColor: '#c8e6c9',
    color: '#388e3c',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 5,
    marginRight: 5,
  },
  statusNumber: {
    backgroundColor: '#ffcdd2',
    color: '#d32f2f',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 5,
  },
  scheduleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  scheduleText: {
    fontSize: 14,
    color: '#333',
    marginLeft: 5,
  },
  divider: {
    height: 1,
    backgroundColor: '#90caf9',
    marginVertical: 5,
  },
  description: {
    fontSize: 13,
    color: '#666',
  },
});

export default Index;
