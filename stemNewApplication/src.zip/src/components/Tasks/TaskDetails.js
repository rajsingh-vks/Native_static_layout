import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
import Header from '../Header';
import { convertUTCToLocal, showSuccessToast, WeekDaysNames } from '../../utils/appHelpers';
import { setSpinner } from '../../redux/appSlice';
import Input from '../Common/Input';
import { useDispatch, useSelector } from 'react-redux';
import { getUser } from '../../redux/userSlice';
import { useEffect, useState } from 'react';
import validateForm from '../../utils/validateForm';
import styles from '../../utils/styles';

const TaskDetails = ({ route, navigation }) => {
  const { task } = route.params;
  const user = useSelector(getUser);
  const dispatch = useDispatch();

  const [disabled, setDisabled] = useState(true);
  const [fields, setFields] = useState({
    notes: task?.notes,
  });

  const rules_notes = {
    notes: ['required', 'string'],
  };

  const handleInputChange = (field, value) => {
    setFields((prevState) => ({ ...prevState, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    dispatch(setSpinner(true));


    try {
      let formData = new FormData();
      formData.append('guard_id', user?.id);
      formData.append('notes', fields?.notes);
      formData.append('task_id', task?.id);

      console.log(formData, "formData");

      const response = await api.taskMarkAsCompleted(formData)


      if (response?.status) {
        showSuccessToast(response?.message);
        navigation.goBack();
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error?.data?.message);
    } finally {
      dispatch(setSpinner(false));
    }
  };

  useEffect(() => {
    let rules = rules_notes;
    let valStat = validateForm(fields, rules);
    setDisabled(!valStat?.status);
  }, [fields]);
  return (
    <>
      <Header title="Task Info" />
      <View style={[styles.container]}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}>

          <TouchableOpacity
            style={[isStyles.card]}
            onPress={() => navigation.navigate('taskDetails', { task })}>
            <View style={isStyles.leftBorder}></View>

            <View style={isStyles.cardContent}>
              <View style={isStyles.cardHeader}>
                <Text style={isStyles.title}>{task?.task_name ?? '--'}</Text>
                <View style={isStyles.statusContainer}>
                  <Text style={isStyles.statusNumber}>{convertUTCToLocal(task?.created_on, 'MMM DD, YYYY')}</Text>
                </View>
              </View>
              <View style={isStyles.scheduleContainer}>
                <Icon name="calendar" size={16} color="#007bff" />
                <Text style={isStyles.scheduleText}>{WeekDaysNames(task?.schedule_days)}</Text>
              </View>

              <View style={isStyles.divider}></View>
              <Text style={isStyles.description}>
                {task?.description ?? ""}
              </Text>
            </View>
          </TouchableOpacity>


          <View style={isStyles.cardContainer}>
            <View style={isStyles.infoRow}>
              <Text style={isStyles.label}>Start Time</Text>
              <Text style={isStyles.value}>{task?.start_time.map((ele) => ele.start_time) ?? "--"}</Text>
            </View>
            <View style={isStyles.infoRow}>
              <Text style={isStyles.label}>Duration</Text>
              <Text style={isStyles.value}>{task?.max_duration ?? '--'}</Text>
            </View>

          </View>



          <View>
            <Input
              type="textarea"
              numberOfLines={4}
              style={{ height: 80 }}
              label="Note"
              value={fields.notes}
              required={true}
              placeholder="Note"
              placeholderTextColor="#CDCDCD"
              inputStyle={{ paddingHorizontal: 5 }}
              onChangeText={(value) => handleInputChange('notes', value)}
            />
          </View>
          <View style={{ height: 50, marginBottom: 20 }}>
            <TouchableOpacity
              style={disabled ? styles.disabledBtn : styles.Authbtn}
              disabled={disabled}
              onPress={handleSubmit}
            >
              <Text style={styles.Authbtntext}>Save</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </>
  );
};

const isStyles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },


  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    flexDirection: 'row',
    marginHorizontal: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
    overflow: 'hidden',
  },
  leftBorder: {
    width: 5,
    backgroundColor: '#007bff',
  },
  cardContent: {
    flex: 1,
    padding: 15,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusText: {
    backgroundColor: '#c8e6c9',
    color: '#388e3c',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 5,
    marginRight: 5,
  },
  statusNumber: {
    backgroundColor: 'white',
    color: '#d32f2f',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 5,
  },
  scheduleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  scheduleText: {
    fontSize: 14,
    color: '#333',
    marginLeft: 5,
  },
  divider: {
    height: 1,
    backgroundColor: '#90caf9',
    marginVertical: 5,
  },
  description: {
    fontSize: 13,
    color: '#666',
  },
  cardContainer: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
    marginBottom: 10,
    marginHorizontal: 15,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  label: {
    fontSize: 14,
    color: '#333',
  },
  value: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#001F54',
  },
  statusMarked: {
    alignSelf: 'flex-end',
    backgroundColor: '#FFEBEE',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 5,
  },
  status: {
    color: '#D32F2F',
    fontSize: 14,
    fontWeight: 'bold',
  },
  divider: {
    height: 1,
    backgroundColor: '#90caf9',
    marginTop: 5,
  },

});

export default TaskDetails;
