import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, TouchableWithoutFeedback, Image, Keyboard, KeyboardAvoidingView, Platform, ScrollView, } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import Input from '../Common/Input';
import LinearProgress from '../Common/LinearProgress';
import SpaceBox from '../Common/SpaceBox';
import api from '../../services/api';
import { logout } from '../../services/logout';
import { setSpinner, getPopupModal, setPopupModal } from '../../redux/appSlice';
import validateForm from '../../utils/validateForm';
import { showErrorToast, showSuccessToast, passwordStrength } from '../../utils/appHelpers';
import styles from '../../utils/styles';

const Profile = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const popup = useSelector(getPopupModal);
  const [isLoader, setIsLoader] = useState(false);
  const [eyeIcon, setEyeIcon] = useState('eye-off');
  const [passVisible, setPassVisible] = useState(false);
  const [strength, setStrength] = useState(0);
  const [disabled, setDisabled] = useState(true);
  

  const [fields, setFields] = useState({
    password: '',
    confirm_password: '',
  });
  const rules_password = {
    password: ['required', 'string'],
    confirm_password: ['required', 'string'],
  };

  const handleInputChange = (field, value) => {
    setFields((prevState) => ({ ...prevState, [field]: value }));
  };

  // Show Hide Password
  const showPassword = () => {
    if (passVisible) {
      setPassVisible(false);
      setEyeIcon('eye-off');
    } else {
      setPassVisible(true);
      setEyeIcon('eye');
    }
  }

  const handleSubmit = async () => {
    dispatch(setSpinner(true));
    
    try {
      let formData = new FormData();
      formData.append('password', fields.password);
      formData.append('confirm_password', fields.confirm_password);
      
      let response = await api.changePassword(formData);
      if (response?.status) {
        showSuccessToast(response?.message || 'Password changed successfully.', true);
      } else {
        showErrorToast(response?.message || 'Failed to change password');
      }

      dispatch(setSpinner(false));
    } catch (error) {
      dispatch(setSpinner(false));
      showErrorToast('Something went wrong. Contact support.');
    }
  };

  useEffect(() => {
    let rules = rules_password;
    let valStat = validateForm(fields, rules);
    
    let strength = passwordStrength(fields?.password);
    setStrength(strength);

    if (valStat?.status == true && fields?.password == fields?.confirm_password && strength == 1) {
      setDisabled(false);
    } else {
      setDisabled(true);
    }
  }, [fields]);

  // For redirecting to login page after change password.
  useEffect(() => {
    if(popup?.visible == false && popup?.navigate == true){
      dispatch(setPopupModal({ navigate: false}),);
      logout();
      navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
    }
  }, [popup]);

  return (
    <>
      <Header title='Change Password'/>
      <KeyboardAvoidingView 
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>

        <ScrollView
          contentContainerStyle={{ flexGrow: 1 }} 
          keyboardShouldPersistTaps="handled">

          <View style={[styles.container, {paddingTop:20}]}>
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}> 
              <View style={[{flex:1}]}>
                <Text style={styles.settingTitle}>PASSWORD INFO</Text>
                <View style={[styles.settingTab, { marginVertical: 5,flexDirection:'column' }]}>
                  <Text style={{fontSize:16, fontWeight:'700'}}>
                    A strong password is at least 8 characters long. Use a combination of uppercase and lowercase letters, numbers, and symbols.
                  </Text>
                </View>
                <View style={[ {width:'auto', flex:1} ]}>
                  <View style={[styles.settingTab, { marginVertical: 10,flexDirection:'column' }]}>
                    <Input
                      type='text'
                      label='New Password'
                      value={fields.password}
                      leftIcon={<Icon name="lock" size={20} color='#465c9e' />}
                      rightIcon={
                        <Icon name={eyeIcon} size={20} color='#465c9e' onPress={() => showPassword()} />
                      }
                      placeholder="Enter your password"
                      placeholderTextColor="#CDCDCD"
                      secureTextEntry={!passVisible}
                      inputStyle={{ paddingHorizontal: 5 }}
                      onChangeText={(value) => handleInputChange('password', value)}
                    />
                    <LinearProgress strength={strength}></LinearProgress>
                    <SpaceBox height={10} />
                    
                    <Input
                      type='text'
                      label='Confirm Password'
                      value={fields.confirm_password}
                      leftIcon={<Icon name="lock" size={20} color='#465c9e' />}
                      rightIcon={
                        <Icon name={eyeIcon} size={20} color='#465c9e' onPress={() => showPassword()} />
                      }
                      placeholder="Enter your confirm password"
                      placeholderTextColor="#CDCDCD"
                      secureTextEntry={!passVisible}
                      inputStyle={{ paddingHorizontal: 5 }}
                      onChangeText={(value) => handleInputChange('confirm_password', value)}
                    />
                    <SpaceBox height={10} />
                  </View>
                </View>
              </View>
            </TouchableWithoutFeedback>

            <View style={[styles.btnContainer, {height:'auto', marginHorizontal:0}]}>
              <TouchableOpacity
                style={[disabled ? styles.disabledBtn : styles.Authbtn, {height:50}]}
                onPress={handleSubmit} disabled={disabled}>
                <Text style={styles.Authbtntext}>
                  Confirm
                </Text>
              </TouchableOpacity>
            </View>
          </View>
          
        </ScrollView>
      </KeyboardAvoidingView>
    </>
  );
}

export default Profile;