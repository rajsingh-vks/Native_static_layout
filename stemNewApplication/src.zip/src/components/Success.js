import React, { useState, useEffect, useRef } from 'react';
import { ActivityIndicator, Image, StyleSheet, Text, View } from 'react-native';
import { useDispatch } from 'react-redux';
import { useNavigation, CommonActions } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import SpaceBox from './Common/SpaceBox';
import appColors from '../utils/appColors';
import styles from '../utils/styles';

const Success = ({ route }) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const { type, token } = route.params || {};
  const [isLoading, setIsLoading] = useState(true);

  // Redirect to Login page
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false); 
      navigation.dispatch(
        CommonActions.reset({
          index: 0, // Reset to the first route in the stack
          routes: [{ name: 'Login' }],
        })
      );
    }, 2000);

    return () => {
      clearTimeout(timer);
      setIsLoading(false); // Hide indicator if the component unmounts
    };
  }, [navigation]);

  return (
    <>
      <View style={[styles.container, {alignItems: 'center', backgroundColor:'#FFF', paddingTop:40}]}>
        <Text style={[styles.authTitle, {fontSize:25}]}>Registration Successful</Text>
        <SpaceBox height={30}/>

        <View style={[styles.authImageWrapper, {marginVertical:20}]}>
          <Image
            source={require('../assets/images/ic_login.png')}
            style={[styles.authImage]}
          />
        </View>
        <SpaceBox height={50}/>

        <View style={{flex:1, alignItems: 'center',}}>
          <Text style={[{fontSize:30, fontWeight:'500'}]}>
            Thank You!
          </Text>

          <Text style={[styles.authsubtitle, {fontSize:18, fontWeight:'400'}]}>
            Your account has been created successfully. 
          </Text>
        </View>
        {isLoading && (
          <ActivityIndicator size="large" color={appColors.blueHeader} />
        )}
        <SpaceBox height={50}/>
      </View>
    </>
  );
};

export default Success;
