import * as React from 'react';
import { View, Text, ScrollView, TouchableOpacity, RefreshControl, ImageBackground } from 'react-native';
import { useNavigation } from '@react-navigation/native';

import Header from '../Header';
import styles from '../../utils/styles';

function Message() {
  const navigation = useNavigation();

  return (
    <>
      <Header title="Messages" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>
          <View>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 12, marginBottom: 10 }]}
              onPress={() => navigation.navigate('chat')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#2360FB', width: 50, height: 50, position: 'relative' }]}>
                      <ImageBackground
                        source={require('../../assets/images/Ellipse_921.png')}
                        resizeMode="cover"
                        style={[{ height: 50, width: 50, margin: 'auto' }]}>
                      </ImageBackground>
                      <View style={styles.greenDot}></View>
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 18, flex: 1, color: '#000E42', marginLeft: 10 }]}>
                        Park Hoon
                      </Text>
                      <Text style={[styles.companyEmail, { fontSize: 13, flex: 1, verticalAlign: 'middle', marginLeft: 10 }]}>
                        Be aware! your duty is starting after 2 hours.
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
              <View style={[styles.absoluteLeftLine, { left: 'auto', top: 2, right: -20, width: 100 }]}>
                <Text>09:00 AM</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 12, marginBottom: 10 }]}
              onPress={() => navigation.navigate('chat')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#2360FB', width: 50, height: 50, position: 'relative' }]}>
                      <ImageBackground
                        source={require('../../assets/images/Ellipse_924.png')}
                        resizeMode="cover"
                        style={[{ height: 50, width: 50, margin: 'auto' }]}>
                      </ImageBackground>
                      <View style={styles.greenDot}></View>
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 18, flex: 1, color: '#000E42', marginLeft: 10 }]}>
                        Park Hoon
                      </Text>
                      <Text style={[styles.companyEmail, { fontSize: 13, flex: 1, verticalAlign: 'middle', marginLeft: 10 }]}>
                        Be aware! your duty is starting after 2 hours.
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
              <View style={[styles.absoluteLeftLine, { left: 'auto', top: 2, right: -20, width: 100 }]}>
                <Text>09:00 AM</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 12, marginBottom: 10 }]}
              onPress={() => navigation.navigate('chat')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#2360FB', width: 50, height: 50, position: 'relative' }]}>
                      <ImageBackground
                        source={require('../../assets/images/Ellipse_925.png')}
                        resizeMode="cover"
                        style={[{ height: 50, width: 50, margin: 'auto' }]}>
                      </ImageBackground>
                      <View style={styles.greenDot}></View>
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 18, flex: 1, color: '#000E42', marginLeft: 10 }]}>
                        Park Hoon
                      </Text>
                      <Text style={[styles.companyEmail, { fontSize: 13, flex: 1, verticalAlign: 'middle', marginLeft: 10 }]}>
                        Be aware! your duty is starting after 2 hours.
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
              <View style={[styles.absoluteLeftLine, { left: 'auto', top: 2, right: -20, width: 100 }]}>
                <Text>09:00 AM</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 12, marginBottom: 10 }]}
              onPress={() => navigation.navigate('chat')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#2360FB', width: 50, height: 50, position: 'relative' }]}>
                      <ImageBackground
                        source={require('../../assets/images/Ellipse_923.png')}
                        resizeMode="cover"
                        style={[{ height: 50, width: 50, margin: 'auto' }]}>
                      </ImageBackground>
                      <View style={styles.greenDot}></View>
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 18, flex: 1, color: '#000E42', marginLeft: 10 }]}>
                        Park Hoon
                      </Text>
                      <Text style={[styles.companyEmail, { fontSize: 13, flex: 1, verticalAlign: 'middle', marginLeft: 10 }]}>
                        Be aware! your duty is starting after 2 hours.
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
              <View style={[styles.absoluteLeftLine, { left: 'auto', top: 2, right: -20, width: 100 }]}>
                <Text>09:00 AM</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 12, marginBottom: 10 }]}
              onPress={() => navigation.navigate('chat')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#2360FB', width: 50, height: 50, position: 'relative' }]}>
                      <ImageBackground
                        source={require('../../assets/images/Ellipse_924.png')}
                        resizeMode="cover"
                        style={[{ height: 50, width: 50, margin: 'auto' }]}>
                      </ImageBackground>
                      <View style={[styles.greenDot, {}]}></View>
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 18, flex: 1, color: '#000E42', marginLeft: 10 }]}>
                        Park Hoon
                      </Text>
                      <Text style={[styles.companyEmail, { fontSize: 13, flex: 1, verticalAlign: 'middle', marginLeft: 10 }]}>
                        Be aware! your duty is starting after 2 hours.
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
              <View style={[styles.absoluteLeftLine, { left: 'auto', top: 2, right: -20, width: 100 }]}>
                <Text>09:00 AM</Text>
              </View>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

export default Message