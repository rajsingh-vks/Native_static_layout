import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, Image, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import SpaceBox from '../Common/SpaceBox';
import api from '../../services/api';
import { logout } from '../../services/logout';
import { getUser, setUser } from '../../redux/userSlice';
import { setSpinner } from '../../redux/appSlice';
import constants from '../../utils/constants';
import styles from '../../utils/styles';


const Profile = () => {
  const navigation = useNavigation();
  const user = useSelector(getUser);
  const dispatch = useDispatch();

  const handleLogout = async () => {
    if (user?.token) {
      dispatch(setSpinner(true));
      let formData = new FormData();
      formData.append('id', user?.id);
      api
        .userLogout()
        .then(async res => {
          if (res?.status === 200) {
            navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
            logout();
          } else {
            setError(res?.data?.message);
          }
        }).catch(function (error) {
          showErrorToast(error?.data?.message);
        }
      )
        .finally(() => {
          dispatch(setSpinner(false));
        });
        
    }
  }

  const init = async () => {
    try {
      const user = await AsyncStorage.getItem(constants.storageKeys.USER);
      const userData = user ? JSON.parse(user) : null;
      dispatch(setUser(userData));

    } catch (e) {
      console.log('Error : ', e.message);
      navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
    }
  }

  useEffect(() => {
    setTimeout(() => {
      init();
    }, 1000);
  }, []);

  return (
    <>
      <Header 
        title='Profile' 
        rightIcon={ <>
          <View style={styles.headerRight}>
            <TouchableOpacity
              onPress={() => navigation.navigate('updateProfile')}
              style={styles.drawerTouch}>
              <Icon name='border-color' style={[styles.drawerIcon, { fontSize: 18 }]} />
            </TouchableOpacity>
          </View>
        </>}
      />
      
      <View style={[styles.container]}>
        <Text style={styles.settingTitle}>PERSONAL INFO</Text>
        <View style={[styles.settingTab, { marginVertical: 5, flexDirection:'column' }]}>
          <View style={{flexDirection:'row', marginVertical: 5}}>
            <View style={styles.iconWrapper}>
              <Icon name='email' style={styles.personalInfoIcon}/>
            </View>
            <View style={[{flex:1, marginLeft:10, }]}>
              <Text style={styles.profileDetailTitle}>Email</Text>
              <Text style={styles.profileDetailSubTitle}>{user?.email}</Text>
            </View>
            <View style={{justifyContent:'center'}}>
              {/* <Icon name={'alpha-v-circle'} size={25}  style={{color:'green', fontWeight:'bold'}}/> */}
              <Text style={{color:'white',backgroundColor:'green', padding:4, fontWeight:'bold',borderRadius:10,fontSize:10}}>Verified</Text>
            </View>
          </View>
          <View style={{ flexDirection:'row', marginVertical: 5}}>
            <View style={styles.iconWrapper}>
              <Icon name='phone' style={styles.personalInfoIcon}/>
            </View>
            <View style={[{flex:1, marginLeft:10, }]}>
              <Text style={styles.profileDetailTitle}>Contact Number</Text>
              <Text style={styles.profileDetailSubTitle}>+{user?.country_code} {user?.mobile_no}
              </Text>
            </View>
            <View style={{justifyContent:'center'}}>
              <Text style={{color:'white',backgroundColor:'green', padding:4, fontWeight:'bold',borderRadius:10,fontSize:10}}>Verified</Text>
            </View>
          </View>
          <View style={{ flexDirection:'row', marginVertical: 5}}>
            <View style={styles.iconWrapper}>
              <Icon name='google-maps' style={styles.personalInfoIcon}/>
            </View>
            <View style={[{marginLeft:10}]}>
              <Text style={styles.profileDetailTitle}>Address</Text>
              <Text style={styles.profileDetailSubTitle}>{user?.address ?? 'N/A'}</Text>
            </View>
          </View>
        </View>

        <SpaceBox height={20}/>
        <Text style={styles.settingTitle}>HIRING INFO</Text>
        <View style={[styles.settingTab, { marginVertical: 5, flexDirection:'column' }]}>
          <View style={{flexDirection:'row', marginVertical: 5}}>
            <View style={styles.iconWrapper}>
              <Icon name='calendar' style={styles.personalInfoIcon}/>
            </View>
            <View style={[{marginLeft:10}]}>
              <Text style={styles.profileDetailTitle}>Hire Date: </Text>
              <Text style={styles.profileDetailSubTitle}>{user?.hire_date ?? '--'}</Text>
            </View>
          </View>
          <View style={{ flexDirection:'row', marginVertical: 5}}>
            <View style={styles.iconWrapper}>
              <Icon name='card' style={styles.personalInfoIcon}/>
            </View>
            <View style={[{marginLeft:10}]}>
              <Text style={styles.profileDetailTitle}>Employee Number: </Text>
              <Text style={styles.profileDetailSubTitle}>{user?.employee_number ?? '--'}</Text>
            </View>
          </View>
          <View style={{ flexDirection:'row', marginVertical: 5}}>
            <View style={styles.iconWrapper}>
              <Icon name='phone' style={styles.personalInfoIcon}/>
            </View>
            <View style={[{marginLeft:10}]}>
              <Text style={styles.profileDetailTitle}>Emergency Contact</Text>
              <Text style={styles.profileDetailSubTitle}>{user?.emergency_contact ?? '--'}</Text>
            </View>
          </View>
        </View>
      </View>

      <View style={[styles.btnContainer]}>
        <TouchableOpacity
          style={styles.Authbtn}
          onPress={handleLogout}>
          <Text style={styles.Authbtntext}>
            Logout
          </Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

export default Profile