import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Label } from '@react-navigation/elements';
import { useDispatch, useSelector } from 'react-redux';
import PhoneInput from 'react-native-international-phone-number';

import Header from '../Header';
import Input from '../Common/Input';
import SpaceBox from '../Common/SpaceBox';
import api from '../../services/api';
import { getUser, setUser } from '../../redux/userSlice';
import { setSpinner } from '../../redux/appSlice';
import { showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import styles from '../../utils/styles';

// Utility function to derive flag emoji from country ISO code
const getFlagEmoji = (countryCode) => {
  return countryCode
    ? String.fromCodePoint(...[...countryCode.toUpperCase()].map((char) => 127397 + char.charCodeAt()))
    : '';
};

function UpdateProfile() {
  const navigation = useNavigation();
  const user = useSelector(getUser);
  const dispatch = useDispatch();

  const [isLoader, setIsLoader] = useState(false);

  const [fields, setFields] = useState({
    first_name: '',
    last_name: '',
    email: '',
    mobile_no: '',
    address: '',
    user_id: '',
    company_id: '',
    country_code: '',
    country_iso_code: '',
  });

  const [selectedCountry, setSelectedCountry] = useState({ callingCode: '', cca2: '', flag: '' });

  // Set initial values based on the user object
  useEffect(() => {
    if (user) {
      const flag = getFlagEmoji(user.country_iso_code || 'IN'); // Generate flag if not available
      setFields({
        first_name: user.first_name || '',
        last_name: user.last_name || '',
        email: user.email || '',
        mobile_no: user.mobile_no || '',
        address: user.address || '',
        user_id: user.id || '',
        company_id: user.company_id || '',
        country_code: user.country_code || '',
        country_iso_code: user.country_iso_code || '',
      });

      setSelectedCountry({
        callingCode: user.country_code?.replace('+', '') || '',
        cca2: user.country_iso_code || 'IN',
        flag: flag,
      });
    }
  }, [user]);

  // Handle input changes for text fields
  const handleInputChange = (field, value) => {
    setFields((prevState) => ({ ...prevState, [field]: value }));
  };

  // Handle phone number input changes
  const handlePhoneInputChange = (phoneNumber) => {
    setFields((prevState) => ({ ...prevState, mobile_no: phoneNumber }));
  };

  // Handle selected country changes
  // const handleSelectedCountryChange = (country) => {
  //   console.log('Selected Country:', country);

  //   setSelectedCountry(country);
  //   setFields((prevState) => ({
  //     ...prevState,
  //     country_code: `+${country?.callingCode || ''}`,
  //     country_iso_code: country?.cca2 || 'IN',
  //     flag: country?.flag || getFlagEmoji(country?.cca2 || 'IN'),
  //   }));
  // };

  const handleSelectedCountryChange = (country) => {
    console.log('Selected Country:', country);
  
    const callingCode = country?.callingCode.replace('+', '');
  
    setSelectedCountry(country);
    setFields((prevState) => ({
      ...prevState,
      country_code: callingCode, // Save without "+"
      country_iso_code: country?.cca2 || 'IN',
      flag: country?.flag || getFlagEmoji(country?.cca2 || 'IN'),
    }));
  };
  
  
  

  // Handle form submission
  const handleSubmit = async () => {
    try {
      dispatch(setSpinner(true));

      const formData = new FormData();
      formData.append('first_name', fields.first_name.trim());
      formData.append('last_name', fields.last_name.trim());
      formData.append('email', fields.email.trim());
      formData.append('mobile_no', fields.mobile_no.trim());
      formData.append('country_code', fields.country_code.trim());
      formData.append('country_iso_code', fields.country_iso_code.trim());
      formData.append('address', fields.address.trim());
      formData.append('user_id', fields.user_id);

      const response = await api.updateUserProfile(formData);
      if (response?.data?.status) {
        dispatch(setUser(response.data));
        showSuccessToast(response?.data?.message || 'Profile updated successfully');
        navigation.navigate('profile');
      } else {
        showErrorToast(response?.data?.message || 'Failed to update profile');
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      showErrorToast('An error occurred while updating the profile');
    } finally {
      dispatch(setSpinner(false));
    }
  };

  return (
    <>
      <Header title="Update Profile" />
      <View style={[styles.container]}>
        <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
          <Text style={styles.settingTitle}>PERSONAL INFO</Text>
          <View style={[styles.settingTab, { marginVertical: 5, flexDirection:'column' }]}>
            <Input
              type='text'
              label='First Name'
              value={fields.first_name}
              placeholder="Enter your first name"
              placeholderTextColor="#CDCDCD"
              style={{marginVertical:5}}
              onChangeText={(value) => handleInputChange('first_name', value)}
            />
            <Input
              type='text'
              label='Last Name'
              value={fields.last_name}
              placeholder="Enter your last name"
              placeholderTextColor="#CDCDCD"
              style={{marginVertical:5}}
              onChangeText={(value) => handleInputChange('last_name', value)}
            />
            <Input
              type='text'
              label='Email'
              value={fields.email}
              placeholder="Enter your email"
              placeholderTextColor="#CDCDCD"
              style={{marginVertical:5}}
              onChangeText={(value) => handleInputChange('email', value)}
            />
            <View style={{ marginVertical: 5 }}>
              <Label style={styles.label}>Phone Number</Label>
              <PhoneInput
                value={fields.mobile_no} // Mobile number field
                selectedCountry={selectedCountry}
                onChangePhoneNumber={(value) => handlePhoneInputChange(value)}
                onChangeSelectedCountry={handleSelectedCountryChange}
                placeholder="Enter phone number"
                containerStyle={{
                  backgroundColor: '#fff',
                  padding: 10,
                }}
                textInputStyle={{
                  fontSize: 16,
                }}
                flagStyle={{
                  width: 30,
                  height: 20,
                }}
              />
            </View>

            <SpaceBox height={5}/>
            <Label style={styles.label}>Address</Label>
            <Input
              type="textarea"
              style={styles.inputFieldTextarea}
              numberOfLines={4}
              value={fields.address}
              placeholder="Address"
              onChangeText={(value) => handleInputChange('address', value)}
            />
          </View>
        </ScrollView>
      </View>

      <View style={[styles.btnContainer]}>
        <TouchableOpacity
          style={styles.Authbtn}
          onPress={handleSubmit}
          disabled={isLoader}
        >
          <Text style={styles.Authbtntext}>Save
          </Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

export default UpdateProfile;
