import { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, RefreshControl, ScrollView, StyleSheet } from 'react-native';
import { showErrorToast } from '../../utils/appHelpers';
import { useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { getRefresh } from '../../redux/refreshSlice';
import styles from '../../utils/styles';

const Index = ({ route }) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const { site_id } = route.params;
  const refresh = useSelector((state) => getRefresh(state, 'CheckLists'));

  const [isDataFetched, setIsDataFetched] = useState(false); // Track whether data fetching is complete
  const [checklists, setCheckLists] = useState([]);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');

  const getCheckLists = async () => {
    dispatch(setSpinner(true));
    try {
      const response = await api.CheckListing(site_id, page, search);
      if (response?.status === 200) {
        setCheckLists(response?.data ?? []);
      } else {
        setCheckLists([]);
        showErrorToast(response?.data?.message);
      }
    } catch (error) {
      showErrorToast(error.data?.message || 'Failed to fetch checkLists');
    } finally {
      setIsDataFetched(true);
      dispatch(setSpinner(false));
    }
  };

  useEffect(() => {
    getCheckLists();
  }, [refresh]);

  return (
    <>
      <Header title="CheckList" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={() => getCheckLists()}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 50 }}
          showsVerticalScrollIndicator={false}>
          {checklists?.length > 0 && <Text style={styles.settingTitle}>CHECK LISTS</Text>}

          {isDataFetched && checklists?.length === 0 ? (
            <View style={styles.noRecordsContainer}>
              <Image
                source={require('../../assets/images/not-found.png')}
                style={styles.noRecordsImage}
              />
              <Text style={styles.noRecordsText}>No Data Found</Text>
            </View>
          ) : (
            checklists?.map((item, index) => (


              <TouchableOpacity
                key={index}
                style={[styles.settingTab, { borderRadius: 15, marginVertical: 0, paddingVertical: 5 }]}
                onPress={() => navigation.navigate('checkListDetails', { item })}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.settingTabTitle, { fontSize: 16, fontWeight: '900', marginLeft: 0, marginBottom: 10 }]}>{item?.name ?? '--'}</Text>
                  <Text>
                    {item?.post_site?.post_site_name}
                  </Text>

                  <Text style={iStyles.subtitle}>
                     {item?.tags?.length}
                  </Text>

                </View>
                <View style={{ marginBottom: 5 }}>
                  <Icon name={'chevron-right'} size={20} style={[styles.roundedGrey, styles.secondaryIcon]} />

                </View>
              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>


    </>
  );
}

const iStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollView: {
    flexGrow: 1,
    paddingBottom: 100,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginHorizontal: 15,
    marginVertical: 10,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginHorizontal: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  chevronIcon: {
    color: '#888',
  },
  cardBody: {
    paddingTop: 5,
  },
  subtitle: {
    fontSize: 13,
    color: '#666',
    marginBottom: 5,
  },
  priorityText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#007bff',
    marginBottom: 10,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '900',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 10,
  },
  statusAction: {
    fontSize: 14,
    fontWeight: '600',
  },
  noDataContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  noDataImage: {
    width: 150,
    height: 150,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  noDataText: {
    fontSize: 16,
    color: '#666',
  },
  footer: {
    padding: 15,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  addButton: {
    backgroundColor: '#003c8f', // Dark blue color
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default Index;
