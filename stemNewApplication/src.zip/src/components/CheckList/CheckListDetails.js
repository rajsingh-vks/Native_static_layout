import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import ImageViewing from "react-native-image-viewing";
import Header from '../Header';
import moment from 'moment';
import { CheckListStatus } from '../../utils/appHelpers';
import { useState } from 'react';

const CheckListDetails = ({ route, navigation }) => {
  const { item } = route?.params;
  console.log(item,"ELE");

  const [isViewerVisible, setIsViewerVisible] = useState(false);
  const [images, setImages] = useState([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);


  const openImage = (imageUri, index) => {
    setImages([{ uri: imageUri }]);
    setCurrentImageIndex(index);
    setIsViewerVisible(true);
  };


  const renderTag = (tag) => {
    const completedTag = item?.completed_tags?.find((ct) => ct?.tag === tag);

    return (
      <View key={tag} style={styles.card}>
        <View style={styles.infoRow}>
          <View style={styles.iconWrapper}>
            <Icon name="account" style={styles.icon} />
          </View>
          <View style={styles.textWrapper}>
            <Text style={styles.infoTitle}>Item Name</Text>
            <Text style={styles.infoSubtitle}>{tag ?? '--'}</Text>
          </View>
        </View>

        <View style={styles.infoRow}>
          <View style={styles.iconWrapper}>
            <Icon name="clock" style={styles.icon} />
          </View>
          <View style={styles.textWrapper}>
            <Text style={styles.infoTitle}>Completed Time</Text>
            <Text style={styles.infoSubtitle}>
              {completedTag?.notes?.[0]?.updated_on
                ? moment(completedTag?.notes[0].updated_on).format('MMMM Do, YYYY [at] h:mm A')
                : '--'}
            </Text>
          </View>
        </View>

        <View style={styles.infoRow}>
          <View style={styles.iconWrapper}>
            <Icon name="note-text" style={styles.icon} />
          </View>
          <View style={styles.textWrapper}>
            <Text style={styles.infoTitle}>Notes</Text>
            <Text style={styles.infoSubtitle}>
              {completedTag?.notes?.map((note) => note?.notes).join(', ') ?? '--'}
            </Text>
          </View>
        </View>

        <View style={styles.infoRow}>
          <View style={styles.iconWrapper}>
            <Icon name="flag" style={styles.icon} />
          </View>
          <TouchableOpacity onPress={() => !completedTag && navigation.navigate('checkListStatusMarker', { item,tag })} style={styles.textWrapper}>

            <Text style={styles.infoTitle}>Status</Text>
            <Text style={styles.infoSubtitle}>
              {CheckListStatus(completedTag ? "Completed" : "Pending")}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.infoRow}>

          <View style={styles.textWrapper}>
            <Text style={styles.infoTitle}>Attachment</Text>
            {completedTag?.attachments?.length > 0 ? (
              <View>
                {completedTag.attachments.map((att, index) => (
                  <TouchableOpacity
                    style={styles.attachmentContainer}
                    onPress={() => openImage(att?.attachment, index)}
                    key={index}
                  >
                    <Image
                      key={`attachment-${index}`}
                      source={{ uri: att?.attachment }}
                      style={{ width: 100, height: 100, marginVertical: 5 }}
                      resizeMode="contain"
                      onError={(e) => console.log('Image Load Error:', e.nativeEvent.error)}
                    />
                  </TouchableOpacity>
                ))}
              </View>
            ) : (
              <Text style={styles.infoSubtitle}>No Attachments</Text>
            )}
          </View>
        </View>

        <ImageViewing
          images={images}
          imageIndex={currentImageIndex}
          visible={isViewerVisible}
          onRequestClose={() => setIsViewerVisible(false)}
        />

      </View>
    );
  };

  return (
    <>
      <Header title="CheckList Info" />
      <View style={styles.container}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}>
          {item.tags?.map(renderTag)}
        </ScrollView>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 3,
    marginBottom: 15,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  iconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#e0e0e0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    fontSize: 20,
    color: '#3b5998',
  },
  textWrapper: {
    marginLeft: 10,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  infoSubtitle: {
    fontSize: 14,
    color: '#666',
  },
  attachmentContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  attachmentImage: {
    width: '48%',
    height: 120,
    marginBottom: 10,
    borderRadius: 10,
    backgroundColor: '#f4f4f4',
  },
});

export default CheckListDetails;
