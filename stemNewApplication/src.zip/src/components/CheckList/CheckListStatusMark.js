import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Image } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import Header from '../Header';
import Input from '../Common/Input';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import styles from '../../utils/styles';
import { getUser } from '../../redux/userSlice';
import validateForm from '../../utils/validateForm';
import DocumentPicker from 'react-native-document-picker';

function CheckListStatusMark({ route, navigation }) {
  const { item,tag } = route.params || {};
  console.log(item,tag,"ELE");
  

  const [disabled, setDisabled] = useState(true);
  const [files, setFiles] = useState([]);
  const [fields, setFields] = useState({
    notes: item?.notes || "",
    attachment: item?.attachments?.attachments || null,

  });

  const user = useSelector(getUser);
  const dispatch = useDispatch();
  const rules_checklist = {
    notes: ['required', 'string'],


  };

  const handleInputChange = (field, value) => {
    setFields((prevState) => ({ ...prevState, [field]: value }));
  };

  const handleImageUpload = async () => {
    try {
      const result = await DocumentPicker.pickSingle({
        type: [DocumentPicker.types.images],
      });

      setFields((prevState) => ({
        ...prevState,
        image: {
          uri: result.uri,
          type: result.type,
          name: result.name,
        },
      }));
    } catch (error) {
      if (DocumentPicker.isCancel(error)) {
        console.log('User canceled the document picker');
      } else {
        console.error('Error selecting document:', error);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      let formData = new FormData();

      formData.append("id", item?.id);
      formData.append("notes", fields?.notes?.trim());
      formData.append("tag_value", tag || "");
      if (fields.image) {
        formData.append('attachment', {
          uri: fields.image.uri,
          type: fields.image.type,
          name: fields.image.name,
        });
      }

      const response = await api.checkListStatusMark(formData);
      
      if (response?.status) {
        showSuccessToast(response?.message);
        navigation.navigate('checkList');
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      console.error('Error updating status:', error);
      showErrorToast('An error occurred while saving the status');
    } finally {
      dispatch(setSpinner(false));
    }
  };



  useEffect(() => {
    let rules = rules_checklist;
    let valStat = validateForm(fields, rules);
    if (valStat?.status == true) {
      setDisabled(false);
    } else {
      setDisabled(true);
    }
  }, [fields]);

  return (
    <>
      <Header title={'Check list'} />

      <View style={[{ flex: 1, backgroundColor: '#fff', paddingHorizontal: 15, paddingTop: 20 }]}>
        <View style={[styles.card_template, { width: 'auto', boxShadow: 'none', backgroundColor: '#fff', padding: 0 }]}>


          <View style={{ marginVertical: 5 }}>
            <Input
              type="textarea"
              numberOfLines={4}
              style={{ height: 80 }}
              label="Note"
              value={fields.notes}
              required={true}
              placeholder="Note"
              placeholderTextColor="#CDCDCD"
              inputStyle={{ paddingHorizontal: 5 }}
              onChangeText={(value) => handleInputChange('notes', value)}
            />
          </View>
          <View style={{ marginVertical: 5 }}>
            <Text style={styles.label}>
              Attachment
            </Text>
            <View style={isStyles.attachmentBox}>
              <TouchableOpacity style={isStyles.uploadButton} onPress={handleImageUpload}>
                <Image
                  source={{
                    uri: 'https://img.icons8.com/ios-filled/50/upload-to-cloud.png',
                  }}
                  style={isStyles.uploadIcon}
                />
                <Text style={isStyles.uploadText}>Upload Document</Text>
              </TouchableOpacity>
              <Text style={isStyles.fileGuidelines}>
                Allowed file types: jpeg, jpg, png (Max file size: 10MB)
              </Text>
            </View>
            {fields.image && (
              <View style={isStyles.imagePreview}>
                <Image source={{ uri: fields.image.uri }} style={isStyles.image} />
                <Text style={isStyles.imageName}>{fields.image.name}</Text>
              </View>
            )}
          </View>



        </View>

        <View style={{ height: 50, marginBottom: 20 }}>
          <TouchableOpacity
            style={disabled ? styles.disabledBtn : styles.Authbtn}
            disabled={disabled}
            onPress={handleSubmit}
          >
            <Text style={styles.Authbtntext}>Save</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
}
const isStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 15,
    paddingTop: 20,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 3,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 5,
  },
  pickerWrapper: {
    borderWidth: 1,
    borderColor: '#CDCDCD',
    borderRadius: 5,
  },
  inputGroup: {
    marginVertical: 5,
  },
  attachmentBox: {
    borderWidth: 1,
    borderColor: '#CDCDCD',
    borderStyle: 'dashed',
    borderRadius: 5,
    padding: 15,
    alignItems: 'center',
  },
  uploadButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  uploadIcon: {
    width: 24,
    height: 24,
    marginRight: 10,
  },
  uploadText: {
    color: '#007BFF',
    fontSize: 16,
  },
  fileGuidelines: {
    color: '#888',
    fontSize: 12,
    marginTop: 10,
    textAlign: 'center',
  },
  imagePreview: {
    marginTop: 15,
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    padding: 10,
    borderRadius: 5,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 5,
    marginBottom: 10,
  },
  imageName: {
    fontSize: 12,
    color: '#666',
  },
  buttonContainer: {
    height: 50,
    marginBottom: 20,
  },
  authBtn: {
    backgroundColor: '#007BFF',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  authBtnText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  disabledBtn: {
    backgroundColor: '#ccc',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
});


export default CheckListStatusMark;
