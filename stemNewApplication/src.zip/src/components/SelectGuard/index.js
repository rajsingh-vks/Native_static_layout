import React, { useState } from "react";
import { View, Text, RefreshControl, ScrollView, TouchableOpacity, ImageBackground } from 'react-native';
import Header from '../Header';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import { useNavigation } from "@react-navigation/native";
import styles from "../../utils/styles";
import SpaceBox from "../Common/SpaceBox";
import Modal from "react-native-modal";

function SelectGuard() {
  const navigation = useNavigation();
  const [isModalVisible, setModalVisible] = useState(false);

  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };

  return (
    <>
      <Header title='Exchange Shift' />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>
          <View>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
              onPress={() => navigation.navigate('shiftsExchangeRequest')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#2360FB', width: 35, height: 35 }]}>
                      <Text style={[styles.companyName, { fontSize: 18, flex: 1, color: '#fff', verticalAlign: 'middle' }]}>
                        W
                      </Text>
                    </View>
                    <Text style={[styles.companyName, { fontSize: 20, flex: 1, verticalAlign: 'middle', marginLeft: 15 }]}>
                      April, 2024
                    </Text>
                  </View>
                </View>
              </View>
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc', left: 'auto', right: '0', height: '120%', top: '40%' }]}></View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
              onPress={() => navigation.navigate('shiftsExchangeRequest')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#2360FB', width: 35, height: 35 }]}>
                      <Text style={[styles.companyName, { fontSize: 18, flex: 1, color: '#fff', verticalAlign: 'middle' }]}>
                        J
                      </Text>
                    </View>
                    <Text style={[styles.companyName, { fontSize: 20, flex: 1, verticalAlign: 'middle', marginLeft: 15 }]}>
                       John Smith
                    </Text>
                  </View>
                </View>
              </View>
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc', left: 'auto', right: '0', height: '120%', top: '40%' }]}></View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
              onPress={() => navigation.navigate('shiftsExchangeRequest')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#2360FB', width: 35, height: 35 }]}>
                      <Text style={[styles.companyName, { fontSize: 18, flex: 1, color: '#fff', verticalAlign: 'middle' }]}>
                        M
                      </Text>
                    </View>
                    <Text style={[styles.companyName, { fontSize: 20, flex: 1, verticalAlign: 'middle', marginLeft: 15 }]}>
                       Michael
                    </Text>
                  </View>
                </View>
              </View>
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc', left: 'auto', right: '0', height: '120%', top: '40%' }]}></View>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

export default SelectGuard;