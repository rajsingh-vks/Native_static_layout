import React, { useState } from "react";
import { View, Text, RefreshControl, ScrollView, TouchableOpacity, ImageBackground } from 'react-native';
import Header from '../Header';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import { useNavigation } from "@react-navigation/native";
import styles from "../../utils/styles";
import SpaceBox from "../Common/SpaceBox";
import Modal from "react-native-modal";

function ShiftsExchangeRequest() {
  const navigation = useNavigation();
  const [isModalVisible, setModalVisible] = useState(false);

  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };

  return (
    <>
      <Header title='Shifts Exchange Request' />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>
          <View>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10, backgroundColor: '#081D6E' }]}
              onPress={toggleModal}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={[{ flexDirection: 'row' }]}>
                    <Text style={[styles.companyName, { fontSize: 18, flex: 1, color: '#fff' }]}>
                      # 1607
                    </Text>
                  </View>
                  <SpaceBox height={5} />
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#2f3d80', width: 30, height: 30, marginRight: 12 }]}>
                      <Icon2
                        name={'calendar'}
                        size={20}
                        style={{ color: '#fff' }}
                      />
                    </View>
                    <Text style={[styles.companyEmail, { marginTop: 2, fontSize: 16, color: '#fff' }]}>
                      Mon, Apr 01, 2024 14:51:45
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16, color: '#fff' }]}>Receiver Status</Text>
                  <Text style={[{ flex: 1, color: '#fff', fontSize: 15, textAlign: 'right' }]}>Accepted</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16, color: '#fff' }]}>Admin Status</Text>
                  <Text style={[{ flex: 1, color: '#fff', fontSize: 15, textAlign: 'right' }]}>Pending</Text>
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
              onPress={() => navigation.navigate('exchangeShift')}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={[{ flexDirection: 'row' }]}>
                    <Text style={[styles.companyName, { fontSize: 18, flex: 1 }]}>
                      John Walk’s Shift Details (Sender)
                    </Text>
                  </View>
                  <SpaceBox height={5} />
                  <View style={{ flexDirection: 'row' }}>
                    <Text style={{ fontSize: 18, flex: 1 }}>
                      #5896
                    </Text>
                    <Text style={[styles.companyEmail, { fontSize: 16, }]}>
                      Thu, Apr 01, 2024
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Post Site</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>Test Demo 1</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Start Time</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>15:00:00</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>End Time</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>1hr 30min</Text>
                </View>
                <View style={[{ flexDirection: 'row', marginVertical: 2 }]}>
                  <Text style={[{ flex: 1, fontSize: 16 }]}>Shift Hours</Text>
                  <Text style={[{ flex: 1, color: '#4D4D4D', fontSize: 15, textAlign: 'right' }]}>1hr 30min</Text>
                </View>
              </View>
            </TouchableOpacity>
          </View>
        </ScrollView>

        <Modal
          isVisible={isModalVisible}
          onBackdropPress={toggleModal}
          style={styles.shiftModal}>
          <View style={styles.shiftModalContent}>
            <Text style={styles.shiftModalText}>Confirmation</Text>
            <ImageBackground
              source={require('../../assets/images/confirmation_image.png')}
              resizeMode="cover"
              style={[{ height: 171, width: 190, margin: 'auto', marginBottom: 20 }]}>

            </ImageBackground>
            <Text style={[styles.shiftModalText, { textAlign: 'center' }]}>Are you sure you want to submit
              this shift exchange request?</Text>
            <View style={{ flexDirection: 'row' }}>
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={toggleModal}
                style={[
                  styles.OnBoardingbtn,
                  {
                    borderColor: "#2360FB",
                    borderWidth: 1,
                    backgroundColor: 'transparent',
                  },
                ]}>
                <Text style={[styles.OnBoardingbtntext, { color: '#2360FB', fontSize: 18, letterSpacing: 0.6 }]}>
                  Cancel
                </Text>
              </TouchableOpacity>
              <View style={{ width: 15 }} />
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={toggleModal}
                style={[styles.OnBoardingbtn, { backgroundColor: '#2360FB' }]}>
                <Text style={[styles.OnBoardingbtntext, { color: '#fff', fontSize: 18, letterSpacing: 0.6 }]}>
                  Ok
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
    </>
  );
}

export default ShiftsExchangeRequest;