import { useCallback, useEffect,  useState } from 'react';
import { Alert, ActivityIndicator, View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { PERMISSIONS, RESULTS, check, request } from 'react-native-permissions';
import { useFocusEffect } from '@react-navigation/native';
import MapView, { Marker } from 'react-native-maps';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import SpaceBox from '../Common/SpaceBox';
import api from '../../services/api';
import location from '../../utils/locationHelper';
import { showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import { showConfirmationBox } from '../Common/Confirmation';
import appColors from '../../utils/appColors';
import styles from '../../utils/styles';

const PostDetails = ({ route, navigation }) => {
  const { site } = route.params;
  const [siteLat, setSiteLat] = useState('');
  const [siteLong, setSiteLong] = useState('');
  const [distance, setDistance] = useState('');
  const [isMapVisible, setIsMapVisible] = useState(false);

  const initLoading = async () => {
    try {
      const distance = await location.getDistanceFromCurrentLocation(site.latitude, site.longitude);
      if(distance > 1000){
        const distKm = distance/1000;
        const distMiles = distKm * 0.621371;
        setDistance(`${distMiles.toFixed(2)} miles`);
      }else{
        setDistance(`${distance} m`);
      }
      console.log("Distance:", distance);
    } catch (error) {
      console.error("Error fetching location:", error);
    }
  }

  useFocusEffect(
    useCallback(() => {
      // Mount MapView when the screen is focused
      setIsMapVisible(true);
      return () => {
        // Unmount MapView when the screen is unfocused
        setIsMapVisible(false);
      };
    }, [])
  );

  useEffect(() => {
    if (site) {
      setSiteLat(site.latitude);
      setSiteLong(site.longitude);
    }
    initLoading();
  }, []);

  return (
    <>
      <Header title={site?.post_site_name || 'Post Site'} />
      <View style={{flex:1, backgroundColor:'#FFF'}}>
        <ScrollView 
          contentContainerStyle={{ flexGrow: 1}}
          showsVerticalScrollIndicator={false}>
            
          {/* Map View */}
          {isMapVisible && (
          <View style={{ flex: 1 }}>
            <MapView
              style={{flex:1}}
              mapType='hybrid'
              initialRegion={{
                latitude: siteLat,
                longitude: siteLong,
                latitudeDelta: 0.0922,
                longitudeDelta: 0.0421,
              }}
              zoomControlEnabled={true}>
              <Marker
                coordinate={{
                  latitude: siteLat,
                  longitude: siteLong,
                }}
                title={site?.post_site_name}
                description={site?.address}
              />
            </MapView>
          </View>
          )}
        </ScrollView>

        <View style={iStyles.distanceView}>
          <Text style={{color:appColors.blueHeader, fontSize:16, fontWeight:'bold'}}>Address :</Text>
          <SpaceBox height={5} />
          <Text style={{color:'#aaa', fontSize:14, fontWeight:'bold'}}>{site?.address || 'Not Available'}</Text>
          <Text style={{color:appColors.dark500, fontSize:14, fontWeight:'bold', marginVertical:2}}>
            Distance from your location: {distance!=''?distance:(
              <ActivityIndicator size={15} color={appColors.blueHeader} />
            )}
          </Text>
        </View>

        {/* Cards Section */}
        <View style={[iStyles.cardWrapper, { }]}>
          {[
            { title: 'Post Orders', icon: 'file-document', color: '#EAF3FF', borderColor: '#eee', path:'postOrders', param:{ site_id: site?.id || ''}},
            { title: 'Checklist', icon: 'check-circle-outline', color: '#FFEEF0', borderColor: '#eee', path:'checkList', param:{ site_id: site?.id || '' }},
            { title: 'Tasks', icon: 'clipboard-text', color: '#EAF3FF', borderColor: '#eee', path:'tasks', param:{ siteId: site?.id || '' }},
            { title: 'Visitors', icon: 'account-group', color: '#EAF3FF', borderColor: '#eee', path:'visitors', param:{ siteId: site?.id || '' }},
            { title: 'Panic Mode', icon: 'alert-circle', color: '#FFEEF0', borderColor: '#eee', path:'', param:{ site_id: site?.id || '' }},
            { title: 'Reports', icon: 'chart-box-outline', color: '#FFF7E5', borderColor: '#eee', path:'', param:{ site_id: site?.id || '' }},
            { title: 'Site Tours', icon: 'chart-box-outline', color: '#FFF7E5', borderColor: '#eee', path:'siteTours', param:{ siteId: site?.id || '' }},
            { title: 'Scan Tag', icon: 'qrcode-scan', color: '#FFF7E5', borderColor: '#eee', path:'scanTag', param:{ siteId: site?.id || '' }},

          ].map((item, index) => (
            <TouchableOpacity
              key={index}
              style={[
                iStyles.card,
                {backgroundColor: '#EAF3FF', borderColor: appColors.lightBlue, borderWidth: 1 },
              ]}
              onPress={() => {if(item.path != '')navigation.navigate(item.path, item?.param)}}>
              <Icon name={item.icon} size={30} color={appColors.blueHeader} style={iStyles.icon} />
              <Text style={iStyles.cardTitle}>{item.title}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </>
  );
}

const iStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  distanceView: {
    borderWidth:1, 
    borderColor:'#ccc', 
    borderRadius:10, 
    paddingVertical:10, 
    paddingHorizontal:10, 
    marginHorizontal: 20, 
    marginTop:20
  },
  webview: {
    height: 250,
  },
  buttonWrapper: {
    height: 50,
    width: '90%',
    alignSelf: 'center',
    marginTop: 20,
  },
  redbtn: {
    backgroundColor: '#FF4B55',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
    borderRadius: 8,
  },
  greenbtn: {
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
    borderRadius: 8,
  },
  Authbtntext: {
    color: '#FFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
  cardWrapper: {
    backgroundColor:'#fff',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    paddingVertical: 15,
  },
  card: {
    width: '28%',
    height: 100,
    margin: 5,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    marginBottom: 5,
  },
  cardTitle: {
    fontSize: 14,
    textAlign: 'center',
    color: '#000',
  },
});

export default PostDetails;
