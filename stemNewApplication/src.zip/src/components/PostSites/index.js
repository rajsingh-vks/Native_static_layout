import { useCallback, useEffect, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, RefreshControl, StyleSheet } from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { useDispatch } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialIcons';


import Header from '../Header';
import Input from '../Common/Input';
import SpaceBox from '../Common/SpaceBox';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { showErrorToast } from '../../utils/appHelpers';
import styles from '../../utils/styles';

const Post = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();

  const [isDataFetched, setIsDataFetched] = useState(false); // Track whether data fetching is complete
  const [postSites, setPostSites] = useState([]);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  
  const getpostSites = async () => {
    try {
      dispatch(setSpinner(true)); 
      const response = await api.getPostSites(search, page);

      if (response.status === 200) {
        setPostSites(response?.data ?? []);
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message || 'Failed to fetch post sites');
    } finally {
      setIsDataFetched(true); 
      dispatch(setSpinner(false)); 
    }
  };

  useEffect(() => {
    getpostSites();
  }, [search]);

  useFocusEffect(
    useCallback(() => {
      getpostSites();
    }, [])
  );

  return (
    <>
      <Header title="Post Sites" />
      <View style={[styles.container]}>
        <ScrollView 
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={() => getpostSites()}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}>

          <Input type='text' 
            leftIcon={<Icon name='search' size={20}/>}
            // rightIcon={
            //   <TouchableOpacity style={{borderWidth:1, paddingHorizontal:10, borderRadius:10}} onPress={getpostSites(search, page)}>
            //     <Text>Search</Text>
            //   </TouchableOpacity>
            // }
            placeholder='Search in post sites'
            onChangeText={(val) => setSearch(val)}
            style={{marginBottom:10, backgroundColor:'#FFF', borderColor:'#eee'}}
          />

          {/* Show "not-found" image only after data not found */}
          {isDataFetched && postSites?.length === 0 ? (
            <View style={customStyles.noRecordsContainer}>
              <Image
                source={require('../../assets/images/not-found.png')}
                style={customStyles.noRecordsImage}
              />
              <Text style={customStyles.noRecordsText}>No Postsites found.</Text>
            </View>
          ) : (
            <View>
              { postSites?.map((site, index) => (
              <TouchableOpacity
                key={index}
                style={[styles.settingTab, { padding: 15, marginBottom: 10 }]}
                onPress={() => navigation.navigate('postDetails', { site })}>
                  
                <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc', left: '0', height: '60%', top: '40%',}]}></View>
                <View style={[styles.companyDetails]}>
                  <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                    <Text style={[styles.companyName, { fontSize: 18 }]}>
                    {site?.post_site_name ?? '--'}
                    </Text>
                    <SpaceBox height={5} />
                    <View style={{ flexDirection: 'row' }}>
                      <Icon
                        name={'location-pin'}
                        size={16}
                        style={{ color: '#1d61f4', marginRight: 5 }}
                      />
                      <Text style={styles.companyEmail}>
                        {site?.address ?? '--'}
                      </Text>
                    </View>
                  </View>

                  <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                  
                  <View style={[{ flexDirection: 'row' }]}>
                    <View style={[styles.notification, { flex: 1, paddingHorizontal: 0, paddingBottom:5 }]}>
                      <TouchableOpacity style={{ flexDirection: 'row',justifyContent: 'center' }}
                      onPress={() => navigation.navigate('postDetails', { site })}>
                        <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14,color:'#1d61f4' }]}>
                          View Details
                        </Text>
                        <Icon name={'arrow-forward'} size={16} style={{ color: '#1d61f4', marginLeft: 5 }} />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
              ))}
            </View>
          )}
        </ScrollView>
      </View>
    </>
  );
}

export default Post;

const customStyles = StyleSheet.create({
  noRecordsContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 50,
  },
  noRecordsImage: {
    width: 100,
    height: 100,
    resizeMode: 'contain',
  },
  noRecordsText: {
    marginTop: 10,
    fontSize: 16,
    color: '#A6A8A9',
  },
});
