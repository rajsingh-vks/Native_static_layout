import React, { useState, useEffect } from 'react';
import { Keyboard, KeyboardAvoidingView, ScrollView, Image, View, Text, TextInput, TouchableOpacity } from 'react-native';
import { useDispatch } from 'react-redux';
import { useNavigation } from '@react-navigation/native';
import { Label } from '@react-navigation/elements';
import PhoneInput from 'react-native-international-phone-number';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Input from './Common/Input';
import LinearProgress from './Common/LinearProgress';
import SpaceBox from './Common/SpaceBox';
import api from '../services/api';
import validateForm from '../utils/validateForm';
import { hidePopup, showPopup, showErrorToast, passwordStrength } from '../utils/appHelpers';
import { setSpinner } from '../redux/appSlice';
import appColors from '../utils/appColors';
import styles from '../utils/styles';

const SignUp = () => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [selectedCountry, setSelectedCountry] = useState({ callingCode: '+1', cca2: 'US', flag: '' });
  const [flag, setCountryFlag] = useState('');
  const [passVisible, setPassVisible] = useState(false);
  const [eyeIcon, setEyeIcon] = useState('eye-off');
  const [strength, setStrength] = useState(0);
  const [keyboardHeight, setKeyboardHeight] = useState(0);
  const [disabled, setDisabled] = useState(true);

  const [fields, setFields] = useState({
    full_name: '',
    email: '',
    mobile_no: '',
    password: '',
    country_code: '',
    country_iso_code: '',
  });
  const rules = {
    full_name: ['required', 'string'],
    email: ['required', 'email'],
    mobile_no: ['required', 'string', 'digits:10'],
    password: ['required', 'string'],
    country_code: ['required', 'string'],
    country_iso_code: ['required', 'string'],
  };

  // Handle form inputs
  const handleInputChange = (field, value) => {
    setFields((prevState) => ({ ...prevState, [field]: value }));
  };

  const handlePhoneInputChange = (phoneNumber) => {
    setFields((prevState) => ({ ...prevState, mobile_no: phoneNumber.replace(/\s+/g, '') }));
  };

  // const handleSelectedCountryChange = (country) => {
  //   setSelectedCountry(country);
  //   setFields((prevState) => ({
  //     ...prevState,
  //     country_code: country?.callingCode.replace('+', '') || '',
  //     country_iso_code: country?.cca2 || '',
  //     flag: country?.flag || '',
  //   }));
  //   setCountryFlag(country?.flag || '');
  // };

  const handleSelectedCountryChange = (country) => {
  
    const callingCode = country?.callingCode.replace('+', '');
  
    setSelectedCountry(country);
    setFields((prevState) => ({
      ...prevState,
      country_code: callingCode, 
      country_iso_code: country?.cca2 || 'IN',
      flag: country?.flag || getFlagEmoji(country?.cca2 || 'IN'),
    }));
  };

  const showPassword = () => {
    if(passVisible){
      setPassVisible(false);
      setEyeIcon('eye-off');
    }else{
      setPassVisible(true);
      setEyeIcon('eye');
    }
  }

  // Guard Signup process
  const handleSignup = () => {
    Keyboard.dismiss();
    dispatch(setSpinner(true));

    let valStat = validateForm(fields, rules);
    if(valStat?.status == true){
      api
      .guardSignup({ fields: fields })
      .then(res => {
        dispatch(setSpinner(false));
        if (res?.status == '200') {
          navigation.navigate('VerifyOTP', {
            type: 'phone',
            token: res?.data?.token,
            email: res?.data?.email,
            phone: res?.data?.mobile_no,
            country_code: res?.data?.country_code,
            message: res?.message,
          });
          setFields({});
        }else{
          console.log(res?.message);
        }
      })
      .catch(function (error) {
        dispatch(setSpinner(false));
        showPopup('error', error?.data?.message);
      });
    }else{
      dispatch(setSpinner(false));
      showPopup('error', 'Please enter valid signup data.');
    }
  }

  // Validation check on field value changes
  useEffect(() => {
    let valStat = validateForm(fields, rules);

    let strength = passwordStrength(fields?.password);
    setStrength(strength);
    
    if(valStat?.status == true && strength == 1){
      setDisabled(false);
    }else{
      setDisabled(true);
    }
  }, [fields]);

  // Initial load actions
  useEffect(() => {
    hidePopup();
  }, []);

  // Keyboard Height Manage
  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      Platform.OS === 'android' ? 'keyboardDidShow' : 'keyboardWillShow',
      (event) => {
        setKeyboardHeight(20);
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      Platform.OS === 'android' ? 'keyboardDidHide' : 'keyboardWillHide',
      () => {
        setKeyboardHeight(0);
      }
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView
        contentContainerStyle={{ flexGrow: 1, backgroundColor:'#FFF'}} 
        keyboardShouldPersistTaps="handled">

        <View style={[styles.container, {paddingTop:0}]}>
          <View style={[styles.authImageWrapper, {flex:1}]}>
            <Image
              source={require('../assets/images/ic_login.png')}
              style={[styles.authImage]}
            />
          </View>

          <View style={[styles.auth, {paddingBottom:20,}]}>
            <Text style={styles.authTitle}>Guard Registration</Text>
            <SpaceBox height={10}/>

            <View style={{ marginVertical: 5, }}>
              <Input 
                type='text'
                label='Full Name'
                leftIcon={<Icon name="account" size={20} color={appColors.iconColor}/>}
                placeholder="Enter your UserName"
                placeholderTextColor="#CDCDCD"
                inputStyle={{paddingHorizontal:5}}
                onChangeText={(value) => handleInputChange('full_name', value)}
              />
            </View>
            <View style={{ marginVertical: 5 }}>
              <Input 
                type='text'
                label='Email'
                leftIcon={<Icon name="email" size={20} color={appColors.iconColor}/>}
                placeholder="Enter your email"
                placeholderTextColor="#CDCDCD"
                inputStyle={{paddingHorizontal:5}}
                onChangeText={(value) => handleInputChange('email', value)}
              />
            </View>  
            <View style={{ marginVertical: 5 }}>
              <Label style={styles.label}>Phone Number</Label>
              <PhoneInput
                value={fields.mobile_no} // Mobile number field
                defaultCountry="US"
                selectedCountry={selectedCountry}
                onChangePhoneNumber={(value) => handlePhoneInputChange(value)}
                onChangeSelectedCountry={handleSelectedCountryChange}
                placeholder="Enter phone number"
                containerStyle={{
                  backgroundColor: '#fff',
                  padding: 10,
                }}
                textInputStyle={{
                  fontSize: 16,
                }}
                flagStyle={{
                  width: 100,
                  height: 20,
                }}
                phoneInputStyles={{
                  container: {
                    borderColor: '#ccc',
                  },
                }}
              />
            </View>
            <View style={{ marginVertical: 5 }}>
              <Input 
                type='text'
                label='Password'
                leftIcon={<Icon name="lock" size={20} color={appColors.iconColor}/>}
                rightIcon={
                  <Icon name={eyeIcon} size={20} color={appColors.iconColor} onPress={()=>showPassword()}/>
                }
                placeholder="Enter your password"
                placeholderTextColor="#CDCDCD"
                secureTextEntry={!passVisible}
                inputStyle={{paddingHorizontal:5}}
                onChangeText={(value) => handleInputChange('password', value)}
              />
              <LinearProgress strength={strength}></LinearProgress>
            </View>
          </View>
          {/* <SpaceBox height={10}/> */}

          <View style={[styles.btnContainer, {bottom: keyboardHeight, height:'auto', marginTop:0, marginHorizontal:0}]}>
            <TouchableOpacity
              style={[disabled ? styles.disabledBtn : styles.Authbtn, {height:50}]}
              onPress={handleSignup} disabled={disabled}>
              <Text style={styles.Authbtntext}>SIGN UP</Text>
            </TouchableOpacity>
            <View style={[styles.authBottom, {marginVertical:10}]}>
              <Text>Already have an account?</Text> 
              <TouchableOpacity onPress={() => navigation.replace('Login')}>
                <Text style={{ fontWeight: 'bold', color: 'red' }}> Sign in</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

      </ScrollView>
    </KeyboardAvoidingView>
  );
}

export default SignUp;