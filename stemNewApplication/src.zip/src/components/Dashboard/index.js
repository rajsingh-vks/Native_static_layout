import { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, View, Text, TouchableOpacity, Image, RefreshControl, ScrollView, Button } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon3 from 'react-native-vector-icons/AntDesign';

import Header from '../Header';
import ClockTimer from '../Common/ClockTimer';
import SpaceBox from '../Common/SpaceBox';
import api from '../../services/api';
import { getUser } from '../../redux/userSlice';
import { setSpinner } from '../../redux/appSlice';
import { getRefresh } from '../../redux/refreshSlice';
import { convertUTCToLocal, showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import location from '../../utils/locationHelper';
import styles from '../../utils/styles';
import appStyles from '../../utils/appStyles';
import appColors from '../../utils/appColors';


const Dashboard = ({ navigation, route }) => {
  const [camera, setCamera] = useState(false);
  const user = useSelector(getUser);
  const dispatch = useDispatch();
  const refresh = useSelector(state => getRefresh(state, 'dashboard'),);

  const [company, setCompany] = useState({});
  const [shift, setShift] = useState({});
  const [checkinData, setCheckinData] = useState(2);
  const [shiftFetch, setShiftFetch] = useState(false);
  const [coords, setCoords] = useState({});

  const initDashboard = async () => {
    try {
      dispatch(setSpinner(true));
      getDashboardData();
      // getShiftDetails();

      // Get Checkin/Checkout History 
      // getCheckinHistory();
    } catch (error) {
      dispatch(setSpinner(false));
      console.error("Error getting location:", error);
    }
  }

  const getDashboardData = async () => {
    try {
      const response = await api.getDashboardData();
      if (response?.data) {
        setCompany(response?.data?.company);
        setShift(response?.data?.shift_data);
        setShiftFetch(true);

        // Get Current Checkin/Checkout status 
        getCheckInStatus();
      }
    } catch (error) {
      console.log(error.data.message);
      // showErrorToast(error.data.message || 'Failed to fetch shifts.');
    } finally {
      setShiftFetch(true);
      dispatch(setSpinner(false)); // Hide global spinner
    }
  }

  const getCheckInStatus = async () => {
    try {
      const response = await api.getCheckinStatus(user?.id);
      if (response?.data) {
        setCheckinData(response.data);
      }
    } catch (error) {
      console.log(error.message || 'Failed to get your checkin status.');
      // showErrorToast(error.message || 'Failed to get your checkin status.');
    } finally {
      dispatch(setSpinner(false)); // Hide global spinner
    }
  }

  const clockedRequest = async () => {
    
    if (checkinData?.status != 1 && !shift?.id) {
      showErrorToast("You don't have any active shift for the selected Company.");
      return false;
    }
    
    const hasPermission = await location.hasPermissions();
    if (hasPermission) {
      try {
        
        dispatch(setSpinner(true));
        
        //  Get Guards location & Shift Details 
        const position = await location.getLocation();
        const { latitude, longitude } = position.coords;
        
        if (latitude != '' && longitude != '') {
          setCoords({ latitude, longitude });
          setCamera(true);
        }
      } catch (error) {
        showErrorToast('Error in getting your location data. Try again!!!');
        console.error("Error getting location:", error);
      }finally{
        dispatch(setSpinner(false));
      }
    } else {
      Alert.alert('Guardix require location permission for better user experience. Please enable your location and grant location permission to Guardix.');
      return false;
    }
  }

  const getShiftDetails = async () => {
    try {
      const response = await api.currentShift();
      if (response?.data) {
        setShift(response?.data);
        setShiftFetch(true);

        // Get Current Checkin/Checkout status 
        getCheckInStatus();
      }
    } catch (error) {
      console.log(error.data.message);
      // showErrorToast(error.data.message || 'Failed to fetch shifts.');
    } finally {
      setShiftFetch(true);
      dispatch(setSpinner(false)); // Hide global spinner
    }
  }

  const submitClockRequest = async (selfie = {}) => {
    try {
      dispatch(setSpinner(true));
      let formData = new FormData();
      if (checkinData?.status == 1) {
        formData.append('shift_id', checkinData?.shift?.id);
        formData.append('post_site_id', checkinData?.shift?.post_site[0]?.value);
        formData.append('activity_type', 2);
      } else {
        formData.append('shift_id', shift?.id);
        formData.append('post_site_id', shift?.post_site?.value);
        formData.append('activity_type', 1);
      }
      formData.append('latitude', coords?.latitude || '');
      formData.append('longitude', coords?.longitude || '');
      formData.append('confirmation_picture', selfie);
      // console.log(formData);

      const response = await api.clockedRequest(formData);
      if (response?.status == 200) {
        showSuccessToast(response?.message || 'Clock-In status updated successfully.');

        // Get Current Checkin/Checkout status 
        getCheckInStatus();
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      console.log(JSON.stringify(error, null, 5));
      showErrorToast(error?.data?.message || 'An error occurred.');
    } finally {
      dispatch(setSpinner(false)); // Hide global spinner
    }
  }

  useEffect(() => {
    if (route.params?.successMsg) {
      showSuccessToast(route.params.successMsg)
    } else if (route.params?.errorMsg) {
      showErrorToast(route.params?.errorMsg)
    }
    if (route.params?.reload) {
      refresh();
    }
  }, [route.params]);

  useEffect(() => {
    if (!user.company_id || user.company_id == '') {
      navigation.navigate('company');
    }
  }, [user.company_id]);

  useEffect(() => {
    initDashboard();
  }, [refresh]);

  return (
    <>
      <Header title={company?.company_name || 'Guardix'} subTitle=''/>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={false}
            onRefresh={() => initDashboard()}
          />
        }
        showsVerticalScrollIndicator={false}>
        <View style={styles.dashboard}>
          {/* Welcome Section */}
          <View style={[styles.cardWrapper, { margin: '10' }]}>
            {/* <Image
              style={styles.imgAndTxt}
              source={require('../../assets/images/ic_officer.png')}
            /> */}
            <View style={{backgroundColor:'#FFF', borderRadius:30, padding:10}}>
              <Icon2 name={'account'} size={40} style={{ color: appColors.blueHeader }} />
            </View>
            
            <View style={styles.userDetails}>
              <Text style={[appStyles.textSecondary]}>Good Morning</Text>
              <SpaceBox height={5}/>
              <Text style={[styles.userDetailsTitle]}>
                {user?.full_name}
              </Text>
            </View>
            {/* <TouchableOpacity style={[checkinData.status == 1 ? styles.fingerPrint2 : styles.fingerPrint]} onPress={() => clockedRequest()}>
              <Image source={require('../../assets/images/fingerPrint.png')} />
            </TouchableOpacity> */}
          </View>

          {/* Confirmed Shift for the day */}
          { (shiftFetch && Object.keys(shift).length != 0) &&
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10, backgroundColor: '#081D6E' }]}>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <Text style={[styles.companyName, { fontSize: 18, color: '#fff' }]}>
                    {shift?.post_site?.label}
                  </Text>
                  <SpaceBox height={5} />
                  <View style={{ flexDirection: 'row' }}>
                    <Icon name={'location-pin'} size={16} style={{ color: '#ffca00', marginRight: 5 }} />
                    <Text style={[styles.companyEmail, { color: '#fff' }]}>
                      {shift?.post_site?.address}
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row' }]}>
                  <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                    <View style={[styles.tabIconCircle, { backgroundColor: 'rgba(35, 96, 251, 0.6)' }]}>
                      <Icon2 name={'calendar-today'} size={22} style={{ color: '#ffca00' }} />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16, color: '#ffff', opacity: 0.9 }}>Date</Text>
                      <Text style={[styles.tabIconTitle, {color: '#ffff'}]}>
                        {shift?.start_date_time ? convertUTCToLocal(shift?.start_date_time, 'DD MMM YY', false) : "N/A"}
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                    <View style={[styles.tabIconCircle, { backgroundColor: 'rgba(35, 96, 251, 0.6)' }]}>
                      <Icon2 name={'clock'} size={22} style={{ color: '#ffca00' }} />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16, color: '#ffff', opacity: 0.9 }}>Date</Text>
                      <Text style={[styles.tabIconTitle, {color: '#ffff'}]}>
                        {shift?.start_date_time ? convertUTCToLocal(shift?.start_date_time, 'HH:mm', false) : "N/A"}
                          - 
                        {shift?.end_date_time ? convertUTCToLocal(shift?.end_date_time, 'HH:mm', false) : "N/A"}
                      </Text>
                    </View>
                  </View>
                </View>

                <TouchableOpacity
                  style={[styles.settingTab, { borderRadius: 5, marginVertical: 5, paddingHorizontal: 10, backgroundColor: '#2360FB' }]} onPress={() => navigation.navigate('confirmed')}>
                  <View style={[styles.companyDetails, { flexDirection: 'row' }]}>
                    <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                      <Text style={[styles.companyName, { color: '#fff', fontSize: 18 }]}>
                        Shift Details
                      </Text>
                    </View>
                    <Icon3 name={'caretright'} size={20} style={[styles.secondaryIcon, { color: '#fff', fontSize: 24 }]} />
                  </View>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          }

          {/* Today's Timer */}
          {/* <ClockTimer maxDuration={checkinData?.status == 1 ? checkinData.max_duration : 0} enabled={checkinData.status == 1 ? true : false} /> */}

          {/* Shift Info */}
          {/* <View style={[styles.checkinoutcard, { backgroundColor: '#EAF3FF', borderColor: 'rgb(216, 233, 242)', borderWidth: 1, padding: 10, borderRadius: 8 }]}>
            <Text style={[styles.tbodyBold, { flex: 1, color: 'rgba(8, 29, 110, 0.9)' }]}>
              Shift: {shift?.shift_title || ''}
            </Text>

            {shiftFetch ? (
              Object.keys(shift).length != 0 ? (
                <Text style={[styles.tbodyBold, {fontWeight:'normal', color:'rgba(8, 29, 110, 0.9)'}]}>
                  {shift?.start_date_time ? convertUTCToLocal(shift?.start_date_time, 'HH:mm', false) : ""} - {shift?.end_date_time ? convertUTCToLocal(shift?.end_date_time, 'HH:mm') : ""}
                </Text>
              ) : (
                <Text style={[styles.tbodyBold, { fontWeight: 'normal', color: 'rgba(8, 29, 110, 0.9)' }]}>N/A</Text>
              )
            ) : (
              <ActivityIndicator size={15} color={appColors.blueHeader} />
            )}
          </View> */}
          {/* <VisionCamera show={camera} setShow={setCamera} onCapture={submitClockRequest} /> */}

          {/* Clock-In & Clock-Out */}
          {/* <View style={styles.cardWrapper}>
            <View style={[styles.checkinoutcard, { backgroundColor: '#c7eedc' }]}>
              <View style={{ flex: 1, justifyContent: 'center' }}>
                <Icon3
                  name="clockcircleo"
                  size={25}
                  style={{ color: 'green', fontWeight: 'bold', justifyContent: 'center' }}
                />
              </View>
              <View style={{ flex: 3 }}>
                <Text style={[styles.textPrimary]}>Clock In</Text>
                <Text style={[styles.textPrimary, { fontWeight: 'bold' }]}>
                  {checkinData.status == 1 && checkinData?.created_on ? convertUTCToLocal(checkinData?.created_on, 'HH:mm:ss') : '00:00:00'}
                </Text>
              </View>
            </View>
            <View style={[styles.checkinoutcard, { backgroundColor: '#c7eedc' }]}>
              <View style={{ flex: 1, justifyContent: 'center' }}>
                <Icon3
                  name="clockcircleo"
                  size={25}
                  style={{ color: 'green', fontWeight: 'bold', justifyContent: 'center' }}
                />
              </View>
              <View style={{ flex: 3 }}>
                <Text style={[styles.textPrimary]}>Clock Out</Text>
                <Text style={[styles.textPrimary, { fontWeight: 'bold' }]}>
                  {checkinData.status == 2 && checkinData?.created_on ? convertUTCToLocal(checkinData?.created_on, 'HH:mm:ss') : '00:00:00'}
                </Text>
              </View>
            </View>
          </View> */}

          {/* Quick Links */}
          <View style={styles.cardWrapper}>
            <TouchableOpacity style={[styles.card, { backgroundColor: '#fdefcc' }]} onPress={() => navigation.navigate('shifts', { type: 'All' })}>
              <View style={styles.iconCircle}>
                <Icon2 name={'calendar-clock'} size={30} style={{ color: '#fcb82f' }} />
              </View>
              <Text style={styles.cardTitle}>Schedule</Text>
              <View style={[styles.absoluteLine, { backgroundColor: '#fcbd24' }]}></View>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.card, { backgroundColor: '#e4ebfe' }]} onPress={() => navigation.navigate('shifts', { type: 'Open' })}>
              <View style={styles.iconCircle}>
                <Icon2 name={'file-document-outline'} size={30} style={{ color: '#346dfa' }} />
              </View>
              <Text style={styles.cardTitle}>Open Shifts</Text>
              <View style={[styles.absoluteLine, { backgroundColor: '#275ffc' }]}></View>
            </TouchableOpacity>
          </View>
          <View style={styles.cardWrapper}>
            <TouchableOpacity style={[styles.card, styles.cardFirst, { backgroundColor: '#ffe3e2' }]}>
              <View style={styles.iconCircle}>
                <Icon2 name={'bus-clock'} size={30} style={{ color: '#f65052' }} />
              </View>
              <Text style={styles.cardTitle}>Dispatch</Text>
              <View style={[styles.absoluteLine, { backgroundColor: '#ff5052' }]}></View>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.card, { backgroundColor: '#c7eedc' }]}>
              <View style={styles.iconCircle}>
                <Icon2 name={'bus-double-decker'} size={30} style={{ color: '#00cb83' }} />
              </View>
              <Text style={styles.cardTitle}>Vehicle Patrol</Text>
              <View style={[styles.absoluteLine, { backgroundColor: '#02cc83' }]}></View>
            </TouchableOpacity>
          </View>

          {/* Time Clock */}
          {/* <View style={styles.cardWrapper}>
            <TouchableOpacity style={[styles.card, styles.subCard, { backgroundColor: '#e1bee8' }]}>
              <View style={styles.iconCircle}>
                <Icon2 name={'clock-outline'} size={30} style={[styles.iconCard, { color: '#1554f1' }]} />
              </View>
              <Text style={[styles.cardTitle, styles.subCartTitle]}>Time Clock</Text>
              <View style={[styles.absoluteLine, { backgroundColor: '#46158a' }]}></View>
            </TouchableOpacity>
          </View> */}

          {/* Admin Notification */}
          <Text style={styles.dashboardSubTitle}>Admin Notification</Text>
          <View style={styles.adminCardWrapper}>
            <TouchableOpacity style={styles.notification}>
              <View style={[styles.iconCircle, { backgroundColor: '#e2eaff' }]}>
                <Icon2 name={'account-cog'} size={30} style={ { color: '#1d61f4' }} />
              </View>
              <View style={{ justifyContent: 'center' }}>
                <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 20 }]}>National Utilities</Text>
                <Text style={{ marginLeft: 20 }}>Posted 1hr ago</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.notification}>
              <View style={[styles.iconCircle, { backgroundColor: '#e2eaff' }]}>
                <Icon2 name={'account-cog'} size={30} style={{ color: '#1d61f4' }} />
              </View>
              <View style={{ justifyContent: 'center' }}>
                <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 20 }]}>National Utilities</Text>
                <Text style={{ marginLeft: 20 }}>Posted 1hr ago</Text>
              </View>
            </TouchableOpacity>
            {/* <View style={{ backgroundColor: '#e1e1e1', height: 1 }}></View>
            <Image
              source={require('../../assets/images/ic_officer.png')}
              style={styles.notificationBanner}
            /> */}
          </View>
        </View>
      </ScrollView>
    </>
  );
}

export default Dashboard;