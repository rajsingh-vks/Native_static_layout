import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, RefreshControl, ScrollView, Image } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../../Header';
import SpaceBox from '../../Common/SpaceBox';
import api from '../../../services/api';
import { useDispatch, useSelector } from 'react-redux';
import { getRefresh } from '../../../redux/refreshSlice';
import { setSpinner } from '../../../redux/appSlice';
import { showErrorToast, WeekDaysNames } from '../../../utils/appHelpers';
import styles from '../../../utils/styles';

const Index = () => {
  const dispatch = useDispatch();
  const [siteTours, setSiteTours] = useState([]);
  const [isDataFetched, setIsDataFetched] = useState(false);
  const refresh = useSelector((state) => getRefresh(state, 'siteToursReports'));

  const getSiteToursReports = async () => {
    dispatch(setSpinner(true));
    try {
      const response = await api.getSiteTourReports();
      if (response?.status == 200) {
        setSiteTours(response.data ?? []);
      } else {
        setSiteTours([]);
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message || 'Failed to fetch siteTours');
    } finally {
      setIsDataFetched(true);
      dispatch(setSpinner(false));
    }
  };

  useEffect(() => {
    getSiteToursReports();
  }, [refresh]);

  return (
    <>
      <Header title='Site Tour Reports' />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={getSiteToursReports}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>

          {isDataFetched && siteTours?.length === 0 ? (
            <View style={styles.noRecordsContainer}>
              <Image
                source={require('../../../assets/images/not-found.png')}
                style={styles.noRecordsImage}
              />
              <Text style={styles.noRecordsText}>No Data Found</Text>
            </View>
          ) : (
            siteTours?.map((tour, index) => (
              <TouchableOpacity
                key={index}
                style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}>
                <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc' }]}></View>
                <View style={[styles.companyDetails]}>
                  <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                    <Text style={[styles.companyName, { fontSize: 18 }]}>
                      {tour?.tour_name ?? "--"}
                    </Text>
                    <SpaceBox height={5} />
                    <View style={{ flexDirection: 'row' }}>
                      <Icon
                        name={'calendar-today'}
                        size={16}
                        style={{ color: '#1d61f4', marginTop: 2 }}
                      />
                      <Text style={styles.companyEmail}>
                      {" "} {WeekDaysNames(tour?.selected_days)}
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                  <View style={[{ flexDirection: 'row' }]}>
                    <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                      <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                        <Icon2
                          name={'clock'}
                          size={22}
                          style={{ color: '#1d61f4' }}
                        />
                      </View>
                      <View style={{ justifyContent: 'center' }}>
                        <Text style={{ marginLeft: 5, fontSize: 16 }}>Start</Text>
                        <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>{tour?.start_time[0]?.label ?? "--"}</Text>
                      </View>
                    </View>
                    <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                      <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                        <Icon2
                          name={'clock'}
                          size={22}
                          style={{ color: '#1d61f4' }}
                        />
                      </View>
                      <View style={{ justifyContent: 'center' }}>
                        <Text style={{ marginLeft: 5, fontSize: 16 }}>End</Text>
                        <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>00:00:00</Text>
                      </View>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>
    </>
  );
}

export default Index;
