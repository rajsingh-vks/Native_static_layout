import React from 'react';
import { View, Text, ScrollView, RefreshControl, StyleSheet, TouchableOpacity } from 'react-native';
import Header from '../Header';
import { useDispatch, useSelector } from 'react-redux';
import { getRefresh } from '../../redux/refreshSlice';
import { setSpinner } from '../../redux/appSlice';
import api from '../../services/api';
import { showErrorToast } from '../../utils/appHelpers';
import styles from '../../utils/styles';

const reportsData = [
  { id: 1, title: 'Check-In/Out Report', count: 12, path: 'check-in-out-report', },
  { id: 2, title: 'Checklist Report', count: 9, path: 'checklists-report' },
  { id: 3, title: 'Site Tour Report', count: 53, path: 'site-tours-report' },
  { id: 4, title: 'Task Report', count: 34, path: 'tasks-report' }
];

const Index = ({ navigation }) => {
  const dispatch = useDispatch();
  const refresh = useSelector((state) => getRefresh(state, 'tasks'));

  const getReports = async () => {
    dispatch(setSpinner(true));
    try {
      const response = await api.getPostSiteTask();
      if (response?.status !== 200) {
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message || 'Failed to fetch reports');
    } finally {
      dispatch(setSpinner(false));
    }
  };

  return (
    <>
      <Header title="Reports" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={<RefreshControl refreshing={false} onRefresh={getReports} />}
          contentContainerStyle={styles.scrollView}>
          <Text style={styles.settingTitle}>Reports</Text>
          <View style={isStyles.gridContainer}>
            {reportsData.map((report) => (
              <TouchableOpacity key={report.id} style={isStyles.card}
                onPress={() => navigation.navigate(report.path)}>
                <View style={isStyles.badge}><Text style={isStyles.badgeText}>{report.count}</Text></View>
                <Text style={isStyles.cardText}>{report.title}</Text>
                <View style={isStyles.bottomBorder} />
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </View>
    </>
  );
};

const isStyles = StyleSheet.create({

  scrollView: {
    flexGrow: 1,
    paddingBottom: 50,
  },

  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    // paddingHorizontal: 10, 
  },

  card: {
    width: '31%',
    backgroundColor: 'white',
    paddingVertical: 30,
    marginVertical: 8,
    borderRadius: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
    position: 'relative',
  },

  badge: {
    backgroundColor: '#3b82f6',
    width: 35,
    height: 35,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  badgeText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 14,
  },
  cardText: {
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    paddingHorizontal: 5
  },
  bottomBorder: {
    width: '60%',
    height: 3,
    backgroundColor: '#3b82f6',
    position: 'absolute',
    bottom: 0,
    left: '20%',
    borderRadius: 12,
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10
  }
});

export default Index;
