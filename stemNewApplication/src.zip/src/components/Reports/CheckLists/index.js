import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, RefreshControl, ScrollView, Image } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../../Header';
import styles from '../../../utils/styles';
import SpaceBox from '../../Common/SpaceBox';
import { setSpinner } from '../../../redux/appSlice';
import api from '../../../services/api';
import { useDispatch, useSelector } from 'react-redux';
import { showErrorToast, WeekDaysNames } from '../../../utils/appHelpers';
import { getRefresh } from '../../../redux/refreshSlice';

const Index = () => {
  const dispatch = useDispatch();
  const [checkList, setCheckList] = useState([]);
  const [isDataFetched, setIsDataFetched] = useState(false);
  const refresh = useSelector((state) => getRefresh(state, 'checklistReports'));

  const getCheckListReports = async () => {
    dispatch(setSpinner(true));
    try {
      const response = await api.getChecklist();
      if (response?.status == 200) {
        setCheckList(response.data ?? []);
      } else {
        setCheckList([]);
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message || 'Failed to fetch checkList');
    } finally {
      setIsDataFetched(true);
      dispatch(setSpinner(false));
    }
  };

  useEffect(() => {
    getCheckListReports();
  }, [refresh]);


  return (
    <>
      <Header title='Check List Reports' />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={getCheckListReports}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>
          
          {isDataFetched && checkList?.length === 0 ? (
            <View style={styles.noRecordsContainer}>
              <Image
                source={require('../../../assets/images/not-found.png')}
                style={styles.noRecordsImage}
              />
              <Text style={styles.noRecordsText}>No Data Found</Text>
            </View>
          ) : (
            checkList?.map((item, index) => (
              <TouchableOpacity
                key={index}
                style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}>
                <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc' }]}></View>
                <View style={[styles.companyDetails]}>
                  <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                    <Text style={[styles.companyName, { fontSize: 18 }]}>
                      {item?.name ?? "--"}
                    </Text>
                    <SpaceBox height={5} />
                    <View style={{ flexDirection: 'row' }}>
                      <Icon
                        name={'description'}
                        size={16}
                        style={{ color: '#1d61f4', marginTop: 2 }}
                      />
                      <Text style={styles.companyEmail}>
                        {" "}{item?.description ? item.description.slice(0, 100) + "..." : "--"}
                      </Text>

                    </View>
                  </View>
                  <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                  <View style={[{ flexDirection: 'row' }]}>
                    <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                      <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                        <Icon2
                          name={'clock'}
                          size={22}
                          style={{ color: '#1d61f4' }}
                        />
                      </View>
                      <View style={{ justifyContent: 'center' }}>
                        <Text style={{ marginLeft: 5, fontSize: 16 }}>Start Time</Text>
                        <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>{item?.start_time ?? "--"}</Text>
                      </View>
                    </View>
                    <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                      <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                        <Icon2
                          name={'clock'}
                          size={22}
                          style={{ color: '#1d61f4' }}
                        />
                      </View>
                      <View style={{ justifyContent: 'center' }}>
                        <Text style={{ marginLeft: 5, fontSize: 16 }}>End Time</Text>
                        <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>{item?.start_time ?? "--"}</Text>
                      </View>
                    </View>
                  </View>

                </View>
              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>
    </>
  );
}

export default Index;
