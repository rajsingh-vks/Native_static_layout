import { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, RefreshControl, ScrollView, Button } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon3 from 'react-native-vector-icons/AntDesign';
import MapView, { Marker } from 'react-native-maps';

import Header from '../Header';
import styles from '../../utils/styles';
import SpaceBox from '../Common/SpaceBox';

function ShiftsDetails() {

  return (
    <>
      <Header title='Shifts Details' />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
            // onRefresh={getCompanies}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>
          <View>
            <Text style={styles.settingTitle}>You have 2 shifts today</Text>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10, backgroundColor: '#081D6E' }]}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <Text style={[styles.companyName, { fontSize: 18, color: '#fff' }]}>
                    National Utilities
                  </Text>
                  <SpaceBox height={5} />
                  <View style={{ flexDirection: 'row' }}>
                    <Icon
                      name={'location-pin'}
                      size={16}
                      style={{ color: '#ffca00', marginTop: 2 }}
                    />
                    <Text style={[styles.companyEmail, { color: '#fff' }]}>
                      1700 Hickory Dr, Fort Worth, TX 76117, USA
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row' }]}>
                  <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                    <View style={[styles.iconCircle, { backgroundColor: 'rgba(35, 96, 251, 0.6)', width: 35, height: 35 }]}>
                      <Icon2
                        name={'calendar-today'}
                        size={22}
                        style={{ color: '#ffca00' }}
                      />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16, color: '#ffff', opacity: 0.9 }}>Date</Text>
                      <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14, color: '#ffff' }]}>2024-01-25</Text>
                    </View>
                  </View>
                  <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                    <View style={[styles.iconCircle, { backgroundColor: 'rgba(35, 96, 251, 0.6)', width: 35, height: 35 }]}>
                      <Icon2
                        name={'clock'}
                        size={22}
                        style={{ color: '#ffca00' }}
                      />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16, color: '#ffff', opacity: 0.9 }}>Date</Text>
                      <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14, color: '#ffff' }]}>09:00A.M - 07:00 P.M</Text>
                    </View>
                  </View>
                </View>

                <TouchableOpacity
                  style={[styles.settingTab, { borderRadius: 5, marginVertical: 5, paddingHorizontal: 10, backgroundColor: '#2360FB' }]}
                >
                  <View style={[styles.companyDetails, { flexDirection: 'row' }]}>
                    <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                      <Text style={[styles.companyName, { color: '#fff', fontSize: 18 }]}>
                        Start Shift
                      </Text>
                    </View>
                    <TouchableOpacity>
                      <Icon3 name={'caretright'} size={20} style={[styles.secondaryIcon, { color: '#fff', fontSize: 24 }]} />
                    </TouchableOpacity>
                  </View>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
            >
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc', left: '0', height: '60%', top: '40%' }]}></View>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <Text style={[styles.companyName, { fontSize: 18 }]}>
                    Notes
                  </Text>
                  <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                  <View style={{ flexDirection: 'row' }}>
                    <Text style={styles.companyEmail}>
                      **GUARD IS NEEDED TO MONITOR/SECURE THE LOCATION DURING OVERNIGHT WORK AND IS NOT TO LEAVE THE STORE FOR ANY REASON. PLEASE OBTAIN FURTHER INSTRUCTIONS FROM MANAGEMENT WHEN ARRIVING ON SITE**
                    </Text>
                  </View>
                </View>
              </View>
            </TouchableOpacity>


            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}>
              <View style={[styles.companyDetails, {flex: 1}]}>
                <MapView
                  style={{ width: "100%", height: 300, }}
                  mapType='hybrid'
                  initialRegion={{
                    latitude: 37.78825,
                    longitude: -122.4324,
                    latitudeDelta: 0.0922,
                    longitudeDelta: 0.0421,
                  }}
                  zoomControlEnabled={true}>
                  <Marker
                    coordinate={{ latitude: 37.78825, longitude: -122.4324 }}
                    title="Marker Title"
                    description="Marker Description"
                  />
                </MapView>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.settingTab, { padding: 20, marginBottom: 10, backgroundColor: '#081D6E' }]}
            >
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <Text style={[styles.companyName, { fontSize: 18, color: '#fff' }]}>
                    Distance Left
                  </Text>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View>
                  <Text style={[styles.companyName, { fontSize: 26, color: '#fff' }]}>
                    50 min
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

export default ShiftsDetails;
