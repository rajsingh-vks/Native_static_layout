import React, { useState, useRef, useEffect, Fragment } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Animated, Easing, Alert, ActivityIndicator, Image, Platform } from "react-native";
import appStyles from "../../../utils/appStyles";
import CloseButton from "./CloseButton";
import appColors from "../../../utils/appColors";
import Icon from "react-native-vector-icons/Ionicons";
import { showErrorToast, showSuccessToast } from "../../../utils/appHelpers";
import api from "../../../services/api";
import { useSelector } from "react-redux";
import { getUser } from "../../../redux/userSlice";
import location from "../../../utils/locationHelper";
import SpaceBox from "../../Common/SpaceBox";

interface ClockinProcessModalProps {
  checkinData: any
  selfie: any;
  checkinDetails: any;
  captureSelfie: () => void;
  onClose: () => void;
  onSuccess: () => void
}

type Location = {
  latitude: number;
  longitude: number;
}

const ClockinProcessModal: React.FC<ClockinProcessModalProps> = ({ onClose, onSuccess, captureSelfie, selfie, checkinData }) => {

  const user = useSelector(getUser);
  const progress = useRef(new Animated.Value(0)).current;
  const [step, setStep] = useState<number>(1);
  const [uniformed, setUniformed] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [coords, setCoords] = useState<Location | null>(null)
  const [checkinDetails] = useState(checkinData)
  const [fetchingLocation, setFetchingLocation] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [clockinSuccess, setClockinSuccess] = useState(false);
  const shift = checkinData?.shift;

  const handleValidate = (): boolean => {
    if (step === 1 && !uniformed) {
      setErrorMessage("Please select one.");
      return false;
    }
    else if (step === 2 && !selfie) {
      setErrorMessage("Selfie is required.");
      return false;
    }
    else if (step === 3 && !confirmed) {
      setErrorMessage("Confirmation is required.");
      return false;
    }
    return true;
  }

  const handleNext = () => {
    if (handleValidate()) {
      if (step < 3) {
        setStep(step + 1);
        !!errorMessage && setErrorMessage(null)
      } else {
        fetchCurrentLocation();
      }
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    } else {
      onClose();
    }
  };

  const fetchCurrentLocation = async () => {
    if (checkinDetails?.status != 1 && !shift?.id) {
      showErrorToast("You don't have any active shift for the selected Company.");
      return false;
    }
    const hasPermission = await location.hasPermissions();
    if (hasPermission) {
      try {
        setFetchingLocation(true)
        const position = await location.getLocation();
        const { latitude, longitude } = position.coords;
        console.log('Current Location:', latitude, longitude);
        if (latitude != '' && longitude != '') {
          setFetchingLocation(false)
          submitClockRequest({ latitude, longitude })
        }
      } catch (error) {
        showErrorToast('Error in getting your location data. Try again!!!');
        console.error("Error getting location:", error);
      } finally {
        fetchingLocation && setFetchingLocation(false)
      }
    } else {
      Alert.alert('Guardix require location permission for better user experience. Please enable your location and grant location permission to Guardix.');
      return false;
    }
  }

  const submitClockRequest = async (coords: { latitude: number; longitude: number; }) => {
    try {
      setSubmitting(true)
      let formData = new FormData();
      if (checkinDetails?.status == 1) {
        formData.append('shift_id', shift?.id);
        formData.append('post_site_id', shift?.post_site[0]?.value);
        formData.append('activity_type', 2);
      } else {
        formData.append('shift_id', shift?.id);
        formData.append('post_site_id', shift?.post_site[0]?.value);
        formData.append('activity_type', 1);
      }
      formData.append('latitude', coords?.latitude || '');
      formData.append('longitude', coords?.longitude || '');
      formData.append('confirmation_picture', selfie);
      formData.append('is_fully_uniformed', uniformed ? 1 : 0);

      const response: any = await api.clockedRequest(formData);

      if (response?.status == 200) {
        if (response?.data?.id) {
          setClockinSuccess(true);
          onSuccess();
        } else if (response?.message) {
          setErrorMessage(response?.message)
        }
      }
    } catch (error: any) {
      showErrorToast(error?.message || 'An error occurred.');
    } finally {
      setSubmitting(false)
    }
  }

  const animateProgress = (currentStep: number) => {
    Animated.timing(progress, {
      toValue: currentStep / 3,
      duration: 500,
      easing: Easing.ease,
      useNativeDriver: false,
    }).start();
  };

  useEffect(() => {
    animateProgress(step);
  }, [step]);

  useEffect(() => {
    selfie && errorMessage && setErrorMessage(null)
  },[selfie])

  return (
    clockinSuccess ?
      <View style={[styles.container, { minHeight: 140, }]}>
        <View style={[appStyles.alignItemsCenter, appStyles.justifyContentCenter, appStyles.mt5]}>
          <View style={[{ height: 60, width: 60, backgroundColor: appColors.blue }, appStyles.roundedCircle, appStyles.justifyContentCenter, appStyles.alignItemsCenter]}>
            <Icon name="checkmark-circle" size={40} color={appColors.white} />
          </View>
          <Text style={[appStyles.textPrimary, appStyles.textCenter, appStyles.mt3, appStyles.fw700, { color: appColors.dark300 }]}>
            Your Shift Start Successfully
          </Text>
          <SpaceBox height={Platform.OS === 'ios' ? 55 : 40} />
        </View>
      </View> :
      <Fragment>
        {(fetchingLocation || submitting) ?
          <View style={[styles.container, { minHeight: 140, }]}>
            <View style={[appStyles.justifyContentCenter, appStyles.mt5]}>
              <ActivityIndicator color={appColors.blue} size={'large'} />
              <Text style={[appStyles.textPrimary, appStyles.textCenter, appStyles.mt2]}>
                {fetchingLocation && 'Finding location...'}
                {submitting && 'Submitting...'}
              </Text>
            </View>
          </View>
          :
          <View style={styles.container}>
            <View style={[appStyles.row, appStyles.justifyContentBetween, appStyles.alignItemsCenter, appStyles.mb5]}>
              <Text style={[appStyles.textPrimary, appStyles.fw700, { fontSize: 15, color: appColors.dark300 }]}>
                {step} of 3
              </Text>
              <CloseButton onPress={onClose} />
            </View>

            {/* Stepper Progress Bar */}
            <View style={styles.progressBarContainer}>
              <Animated.View
                style={[
                  styles.progressBar,
                  {
                    width: progress.interpolate({
                      inputRange: [0, 1],
                      outputRange: ["0%", "100%"],
                    }),
                  },
                ]}
              />
            </View>

            {/* Step 1: Uniform Confirmation */}
            {step === 1 && (
              <>
                <Text style={styles.title}>Please confirm you are fully uniformed?</Text>

                <TouchableOpacity style={styles.radioItem} onPress={() => {
                  setUniformed("yes")
                  setStep(1)
                }}>
                  <Icon
                    name={uniformed === "yes" ? "radio-button-on" : "radio-button-off"}
                    size={24}
                    color={uniformed === "yes" ? "#007BFF" : "#aaa"}
                  />
                  <Text style={styles.radioLabel}>Yes</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.radioItem} onPress={() => {
                  setUniformed("no")
                  setStep(1)

                }}>
                  <Icon
                    name={uniformed === "no" ? "radio-button-on" : "radio-button-off"}
                    size={24}
                    color={uniformed === "no" ? "#007BFF" : "#aaa"}
                  />
                  <Text style={styles.radioLabel}>No</Text>
                </TouchableOpacity>
              </>
            )}

            {/* Step 2: Information Confirmation */}
            {step === 2 && (
              <>
                <Text style={styles.title}>Take a picture of yourself for confirmation?</Text>
                {selfie?.uri && (
                  <View style={[appStyles.row, appStyles.justifyContentCenter]}>
                    <Image source={{ uri: selfie.uri }} style={styles.selfie} />
                  </View>
                )}
                <TouchableOpacity activeOpacity={0.8} style={[styles.dashContainer]} onPress={captureSelfie}>
                  <Icon name="camera" size={24} color={appColors.blue} />
                  <Text style={styles.dashText}>
                    {!selfie ? 'Click Pic' : 'Change Pic'}
                  </Text>
                </TouchableOpacity>
              </>
            )}

            {/* Step 3: Read Notes */}
            {step === 3 && (
              <>
                <Text style={styles.title}>Read the site notes and provide confirmation</Text>
                <Text style={[styles.title, { color: appColors.dark400 }]}>Notes</Text>
                <View style={[appStyles.border, appStyles.w100, { backgroundColor: '#B8C7FF' }]}></View>
                <Text style={styles.noteText}>
                  ***Guard is needed to monitor/secure the location during overnight work and is not to leave the store for
                  any reason. Please obtain further instructions from management when arriving on site.***
                </Text>
                <TouchableOpacity style={styles.checkboxContainer}
                  onPress={() => setConfirmed(!confirmed)}
                >
                  <Icon name={confirmed ? "checkbox" : "square-outline"} size={24} color={confirmed ? appColors.blue : appColors.dark300} />
                  <Text style={[appStyles.textPrimary, appStyles.fw700, appStyles.ms1, { color: appColors.dark300 }]}>Confirmed</Text>
                </TouchableOpacity>
              </>
            )}

            {/* Error Message */}
            {!!errorMessage && <Text style={[appStyles.textDanger,]}>{errorMessage}</Text>}

            {/* Navigation Buttons */}
            <View style={styles.buttonContainer}>
              {step > 1 && (
                <TouchableOpacity style={[styles.button, { backgroundColor: '#fff' }]} onPress={handleBack}>
                  <Text style={[styles.buttonText, { color: appColors.dark300 }]}>Back</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity style={styles.button} onPress={handleNext}>
                <Text style={styles.buttonText}>{step === 3 ? "Submit" : "Next"}</Text>
              </TouchableOpacity>
            </View>
            <SpaceBox height={Platform.OS === 'ios' ? 40 : 28} />
          </View>
        }
      </Fragment>
  );
};

export default ClockinProcessModal;

const styles = StyleSheet.create({
  modal: { justifyContent: "flex-end", margin: 0 },
  container: { backgroundColor: "white", paddingHorizontal: 20, borderTopLeftRadius: 20, borderTopRightRadius: 20 },
  progressBarContainer: { height: 6, width: "100%", backgroundColor: "#ddd", borderRadius: 5, overflow: "hidden", marginBottom: 20 },
  progressBar: { height: "100%", backgroundColor: "#007BFF" },
  title: { fontSize: 18, fontWeight: '600', marginBottom: 10 },
  text: { fontSize: 16, color: "#555", marginBottom: 10 },
  noteText: { fontSize: 14, color: "#555", marginVertical: 10 },
  checkboxContainer: { flexDirection: "row", alignItems: "center", marginTop: 10, marginBottom: 10 },
  buttonContainer: { flexDirection: "row", justifyContent: "space-between", marginTop: 20 },
  button: { backgroundColor: "#007BFF", paddingVertical: 12, borderRadius: 4, flex: 1, marginHorizontal: 5 },
  buttonText: { color: "white", textAlign: "center", fontWeight: "bold" },
  radioItem: { flexDirection: "row", alignItems: "center", paddingVertical: 8 },
  radioUnselected: { fontSize: 18, color: "#ccc", marginRight: 10 },
  radioSelected: { fontSize: 18, color: "#007BFF", marginRight: 10 },
  radioLabel: { fontSize: 16, color: "#333", marginLeft: 4 },
  dashContainer: { borderWidth: 1, borderColor: appColors.blue, borderStyle: 'dashed', backgroundColor: '#E2E8FF', width: '100%', height: 100, marginVertical: 10, borderRadius: 6, alignItems: 'center', justifyContent: 'center' },
  dashText: { fontSize: 13, color: appColors.blue, fontWeight: 'bold', marginTop: 2 },
  selfie: {
    width: 100,
    height: 100,
    borderRadius: 6,
    marginBottom: 10
  }
});
