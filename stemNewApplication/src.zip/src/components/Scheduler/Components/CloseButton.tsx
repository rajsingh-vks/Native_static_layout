import { StyleSheet, TouchableOpacity } from 'react-native';
import React from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
import appColors from '../../../utils/appColors';
import appStyles from '../../../utils/appStyles';

type CloseButtonProps = {
  onPress: () => void;
};

const CloseButton: React.FC<CloseButtonProps> = ({ onPress }) => {
  return (
    <TouchableOpacity onPress={onPress} style={[appStyles.border, appStyles.roundedCircle, styles.button]}>
      <Icon name="close" size={18} color={appColors.blue} />
    </TouchableOpacity>
  );
};

export default CloseButton;

const styles = StyleSheet.create({
  button: {
    justifyContent: 'center',
    alignItems: 'center',    
    borderColor: appColors.blue,
    borderWidth: 1.5,
    width: 22,
    height: 22,    
  },
});