import { StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import appStyles from '../../../utils/appStyles'
import CloseButton from './CloseButton'
import appColors from '../../../utils/appColors'
import SpaceBox from '../../Common/SpaceBox'
import Svg, { Circle } from 'react-native-svg'
import moment from 'moment'

type Props = {
  checkinData: any,
  onClose: () => void,
  onClockin: () => void
}

const StartClockinModal = ({ checkinData, onClose, onClockin }: Props) => {
  const size = 102;
  const strokeWidth = 7;

  const today = moment().format('YYYY-MM-DD');
  let startTime = moment(`${today} ${checkinData?.shift?.start_time}`, 'YYYY-MM-DD HH:mm:ss');
  let endTime = moment(`${today} ${checkinData?.shift?.end_time}`, 'YYYY-MM-DD HH:mm:ss');

  if (endTime.isBefore(startTime)) {
    endTime.add(1, 'day');
  }

  const totalDuration = endTime.diff(startTime, 'seconds');
  const [elapsedTime, setElapsedTime] = useState(moment().diff(startTime, 'seconds'));

  useEffect(() => {
    if (checkinData?.status === 1) {
      const interval = setInterval(() => {
        setElapsedTime(moment().diff(startTime, 'seconds'));
      }, 1000);

      return () => clearInterval(interval);
    }
  }, []);

  const clampedElapsedTime = Math.max(0, Math.min(elapsedTime, totalDuration));
  const progress = (clampedElapsedTime / totalDuration) * 100;
  const remainingTime = Math.max(totalDuration - clampedElapsedTime, 0);

  // Circle animation values
  const radius = checkinData?.status === 1 ? (size - strokeWidth) / 2 : 0;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  // Format time as HH:MM
  const formatTime = (seconds: number) => {
    if (checkinData?.status === 2) return '00 : 00';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${String(hours).padStart(2, '0')} : ${String(minutes).padStart(2, '0')}`;
  };

  return (
    <View style={[{ minHeight: 290, paddingHorizontal: 18 }]}>
      <View style={[appStyles.row, appStyles.justifyContentBetween]}>
        <Text style={[appStyles.textPrimary, { fontSize: 15, color: appColors.dark300, fontWeight: 'bold' }]}>
          {checkinData?.shift_status === 1 ? 'End ' : 'Start '} Shift
        </Text>
        <CloseButton onPress={onClose} />
      </View>
      <View style={{ alignItems: 'center' }}>
        <View style={[styles.border1]}>
          <View style={[styles.border2]}>
            <Svg width={size} height={size}>
              <Circle
                cx={size / 2}
                cy={size / 2}
                r={radius}
                stroke={appColors.blue}
                strokeWidth={strokeWidth}
                fill="none"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                rotation="-90"
                origin={`${size / 2},${size / 2}`}
              />
            </Svg>
            <View style={[styles.timeTextContainer]}>
              <Text style={[appStyles.textPrimary, { color: appColors.dark300 }, appStyles.fs3, appStyles.fw700]}>
                {formatTime(remainingTime)}
              </Text>
              <Text style={[appStyles.textPrimary, { color: appColors.dark300, fontSize: 11, marginLeft: 3 }, appStyles.fw700]}>
                Hrs{'  '}Mins
              </Text>
            </View>
          </View>
        </View>
      </View>
      <SpaceBox height={10} />
      <TouchableOpacity style={[styles.button]} activeOpacity={0.8} onPress={onClockin}>
        <Text style={[appStyles.textPrimary, styles.buttonText]}>
          {checkinData?.status === 1 ? 'Clock Out' : 'Clock In'}
        </Text>
      </TouchableOpacity>
    </View>
  )
}

export default StartClockinModal

const styles = StyleSheet.create({
  border1: {
    marginVertical: 30,
    borderWidth: 3,
    borderStyle: 'dashed',
    borderColor: '#D8D8D8',
    height: 130,
    width: 130,
    display: 'flex',
    borderRadius: 65,
  },
  border2: {
    flex: 1,
    margin: 7,
    borderWidth: 15,
    borderColor: '#E0E6FF',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 58,
    position: 'relative'
  },
  button: {
    paddingVertical: 12,
    borderRadius: 5,
    backgroundColor: '#2360FB',
  },
  buttonText: {
    fontSize: 14,
    textAlign: 'center',
    color: '#fff',
    fontWeight: 'bold'
  },
  timeTextContainer: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
