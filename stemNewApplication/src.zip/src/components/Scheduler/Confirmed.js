import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, View, Text, TouchableOpacity, RefreshControl, ScrollView, Button } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import MapView, { Marker } from 'react-native-maps';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon3 from 'react-native-vector-icons/AntDesign';

import Header from '../Header';
import SpaceBox from '../Common/SpaceBox';
import location from '../../utils/locationHelper';
import { convertUTCToLocal, showErrorToast } from '../../utils/appHelpers';
import appColors from '../../utils/appColors';
import styles from '../../utils/styles';
import { BottomSheetBackdrop, BottomSheetModal, BottomSheetView } from '@gorhom/bottom-sheet';
import StartClokinModal from './Components/StartClokinModal';
import ClockinProcessModal from './Components/ClockinProcessModal';
import VisionCamera from '../Common/VisionCamera';
import api from '../../services/api';
import { useDispatch, useSelector } from 'react-redux';
import { getUser } from '../../redux/userSlice';
import { setSpinner } from '../../redux/appSlice';

const Confirmed = ({ route }) => {

  const user = useSelector(getUser);
  const [checkinData, setCheckinData] = useState({});
  const [shift, setShift] = useState(route.params?.shift);
  const [siteLat, setSiteLat] = useState('');
  const [siteLong, setSiteLong] = useState('');
  const [distance, setDistance] = useState('');
  const [distanceLoading, setDistanceLoading] = useState(false);
  const [isMapVisible, setIsMapVisible] = useState(false);
  const [camera, setCamera] = useState(false);
  const [selfie, setSelfie] = useState(null);
  const dispatch = useDispatch();

  const RenderBackdrop = useCallback(
    (props) => (
      <BottomSheetBackdrop
        {...props}
        pressBehavior={'none'}
        disappearsOnIndex={-1}
        appearsOnIndex={0}
      />
    ),
    []
  );

  const handleCaptureSelfie = useCallback(() => {
    setCamera(true);
  }, [])

  // Start clockin Modal Sheet
  const clockinModalRef = useRef(null);
  const showClockinModal = useCallback(() => {
    clockinModalRef.current.present();
  }, []);
  const handleCloseClockinModal = useCallback(() => {
    clockinModalRef.current.dismiss();
  }, [])

  // Clockin Process Modal Sheet
  const clockinProcessModalRef = useRef(null);
  const showClockinProcessModal = useCallback(() => {
    clockinModalRef.current.dismiss();
    clockinProcessModalRef.current.present();
  }, []);
  const handleCloseClockinProcessModal = useCallback(() => {
    clockinProcessModalRef.current.dismiss();
  }, [])

  const handleClockinSuccess = useCallback(() => {
    setTimeout(() => {
      handleCloseClockinProcessModal();
      getCheckinStatus();
    }, 1500);
  }, [])

  const initLoading = async () => {
    try {
      setDistanceLoading(true)
      const distance = await location.getDistanceFromCurrentLocation(shift?.post_site?.latitude, shift?.post_site?.longitude); 

      if (distance > 1000) {
        const distKm = distance / 1000;
        setDistance(`${distKm.toFixed(2)} km`);
      } else {
        setDistance(`${distance} m`);
      }
      console.log("Distance:", distance);
    } catch (error) {
      console.error("Error fetching location:", error);
    } finally {
      setDistanceLoading(false);
    }
  }

  const getCheckinStatus = async () => {
    try {
      dispatch(setSpinner(true));
      if (!!route.params?.shift) return;
      const dashboard = await api.getDashboardData();
      if (dashboard?.data) {
        setShift(dashboard?.data?.shift_data);
      }
      const checkinStatus = await api.getCheckinStatus(user?.id);
      if (checkinStatus?.data) {
        setCheckinData(checkinStatus?.data);
      }
    } catch (error) {
      showErrorToast(error?.message);
    } finally {
      dispatch(setSpinner(false));
    }
  }

  useFocusEffect(
    useCallback(() => {
      // Mount MapView when the screen is focused
      setIsMapVisible(true);
      return () => {
        // Unmount MapView when the screen is unfocused
        setIsMapVisible(false);
      };
    }, [])
  );

  useEffect(() => {
    if (shift) {
      initLoading();
      setSiteLat(shift?.post_site?.latitude);
      setSiteLong(shift?.post_site?.longitude);
    }
  }, [shift]);

  useEffect(() => {
    getCheckinStatus();
  }, [])

  return (
    <>
      <Header title='Shifts Details' />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={getCheckinStatus}
            />
          }
          contentContainerStyle={{ flexGrow: 1 }}
          showsVerticalScrollIndicator={false}>

          <View>
            {/* <Text style={styles.settingTitle}>You have 2 shifts today</Text> */}
            <View style={[styles.settingTab, { padding: 20, marginBottom: 10, backgroundColor: '#081D6E' }]}>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <Text style={[styles.companyName, { fontSize: 18, color: '#fff' }]}>
                    {shift?.post_site?.label}
                  </Text>
                  <SpaceBox height={5} />
                  <View style={{ flexDirection: 'row' }}>
                    <Icon name={'location-pin'} size={16} style={{ color: '#ffca00', marginRight: 5 }} />
                    <Text style={[styles.companyEmail, { color: '#fff' }]}>
                      {shift?.post_site?.address}
                    </Text>
                  </View>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View style={[{ flexDirection: 'row' }]}>
                  <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                    <View style={[styles.iconCircle, { backgroundColor: 'rgba(35, 96, 251, 0.6)' }]}>
                      <Icon2 name={'calendar-today'} size={22} style={{ color: '#ffca00' }} />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16, color: '#ffff', opacity: 0.9 }}>Date</Text>
                      <Text style={[styles.tabIconTitle, { color: '#ffff' }]}>
                        {shift?.start_date_time ? convertUTCToLocal(shift?.start_date_time, 'DD MMM YY', false) : "N/A"}
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                    <View style={[styles.tabIconCircle, { backgroundColor: 'rgba(35, 96, 251, 0.6)' }]}>
                      <Icon2 name={'clock'} size={22} style={{ color: '#ffca00' }} />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={{ marginLeft: 5, fontSize: 16, color: '#ffff', opacity: 0.9 }}>Date</Text>
                      <Text style={[styles.tabIconTitle, { color: '#ffff' }]}>
                        {shift?.start_date_time ? convertUTCToLocal(shift?.start_date_time, 'HH:mm', false) : "N/A"}
                        -
                        {shift?.end_date_time ? convertUTCToLocal(shift?.end_date_time, 'HH:mm', false) : "N/A"}
                      </Text>
                    </View>
                  </View>
                </View>

                <TouchableOpacity
                  disabled={!!route.params?.shift}
                  style={[
                    styles.settingTab,
                    {
                      borderRadius: 5,
                      marginVertical: 5,
                      paddingHorizontal: 10,
                      backgroundColor: '#2360FB',
                      opacity: !!route.params?.shift ? 0.6 : 1
                    }]}
                  onPress={showClockinModal}
                >
                  <View style={[styles.companyDetails, { flexDirection: 'row' }]}>
                    <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                      <Text style={[styles.companyName, { color: '#fff', fontSize: 18 }]}>
                        {checkinData?.status === 1 ? 'End ' : 'Start '}
                        Shift
                      </Text>
                    </View>
                    <Icon3 name={'caretright'} size={20} style={[styles.secondaryIcon, { color: '#fff', fontSize: 24 }]} />
                  </View>
                </TouchableOpacity>
              </View>
            </View>

            <View style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}>
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc' }]}></View>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <Text style={[styles.companyName, { fontSize: 18 }]}>
                    Notes
                  </Text>
                  <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                  <View style={{ flexDirection: 'row' }}>
                    <Text style={styles.companyEmail}>
                      {shift?.note != '' ? shift?.note : 'No notes available for this shift.'}
                    </Text>
                  </View>
                </View>
              </View>
            </View>

            {/* Map View */}
            {isMapVisible && siteLat && siteLong && (
              <View style={{ flex: 1, backgroundColor: '#FFF', borderRadius: 5, height: 300, paddingHorizontal: 10, paddingVertical: 8, marginVertical: 10, borderColor: '#eee', borderWidth: 1 }}>
                <MapView
                  style={{ flex: 1, borderRadius: 5 }}
                  mapType='standard'
                  initialRegion={{
                    latitude: siteLat,
                    longitude: siteLong,
                    latitudeDelta: 0.0922,
                    longitudeDelta: 0.0421,
                  }}
                  zoomControlEnabled={true}>
                  <Marker
                    coordinate={{
                      latitude: siteLat,
                      longitude: siteLong,
                    }}
                    title={shift?.post_site?.label}
                    description={shift?.post_site?.address}
                  />
                </MapView>
              </View>
            )}

            <View style={[styles.settingTab, { padding: 20, marginBottom: 10, backgroundColor: '#081D6E' }]}>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <Text style={[styles.companyName, { fontSize: 18, color: '#fff' }]}>
                    Distance Left
                  </Text>
                </View>
                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
                <View>
                  <Text style={[styles.companyName, { fontSize: 25, color: '#fff' }]}>
                    {distance}
                  </Text>
                  {distanceLoading && (
                    <ActivityIndicator size={20} color={appColors.white} />
                  )}
                </View>
              </View>
            </View>
          </View>
        </ScrollView>
      </View>

      {/* Start clockin modal */}
      <BottomSheetModal
        ref={clockinModalRef}
        backdropComponent={RenderBackdrop}
        handleIndicatorStyle={{ height: 0, opacity: 0 }}
        backgroundStyle={{ backgroundColor: appColors.white }}
      >
        <BottomSheetView>
          <StartClokinModal
            checkinData={checkinData}
            onClose={handleCloseClockinModal}
            onClockin={() => {
              selfie && setSelfie(null)
              showClockinProcessModal()
            }}
          />
        </BottomSheetView>
      </BottomSheetModal>

      {/* Clockin Process modal */}
      <BottomSheetModal
        ref={clockinProcessModalRef}
        backdropComponent={RenderBackdrop}
        handleIndicatorStyle={{ height: 0, opacity: 0 }}
        backgroundStyle={{ backgroundColor: appColors.white }}
        enableDynamicSizing
      >
        <BottomSheetView>
          <ClockinProcessModal
            selfie={selfie}
            checkinData={checkinData}
            captureSelfie={handleCaptureSelfie}
            onClose={handleCloseClockinProcessModal}
            onSuccess={handleClockinSuccess}
          />
        </BottomSheetView>
      </BottomSheetModal>

      {/* Vision Camera */}
      <VisionCamera
        show={camera}
        setShow={setCamera}
        onCapture={setSelfie}
      />
    </>
  );
}

export default Confirmed;
