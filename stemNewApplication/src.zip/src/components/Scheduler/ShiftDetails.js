import { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, RefreshControl, ScrollView, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import SpaceBox from '../Common/SpaceBox';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { getUser } from '../../redux/userSlice';
import { convertUTCToLocal, refresh, showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import appColors from '../../utils/appColors';
import styles from '../../utils/styles';

const ShiftDetails = ({ route }) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const { shift } = route.params;
  const user = useSelector(getUser);
  const [disabled, setDisabled] = useState(true);

  function calculateTimeDifference(time1, time2) {
    // Parse the times using moment
    const momentTime1 = moment(time1);
    const momentTime2 = moment(time2);

    // Calculate the difference in seconds
    const diffInSeconds = Math.abs(momentTime1.diff(momentTime2, "seconds"));

    // Convert seconds to HH:mm:ss format
    const hours = Math.floor(diffInSeconds / 3600);
    const minutes = Math.floor((diffInSeconds % 3600) / 60);
    const seconds = diffInSeconds % 60;

    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
  }

  const saveConfirm = async () => {
    let formData = new FormData();
    formData.append('shift_id', shift.id);
    formData.append('guard_id', user.id);
    formData.append('status', 1);
    // console.log(formData);

    try {
      dispatch(setSpinner(true)); // Show global spinner

      const response = await api.confirmShift(formData);
      if (response?.status == 200) {
        showSuccessToast(response?.message || 'Shift updated successfully.');
        refresh('shifts');
        navigation.goBack();
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      console.log(JSON.stringify(error, null, 5));
      showErrorToast(error?.data?.message || 'An error occurred.');
    } finally {
      dispatch(setSpinner(false)); // Hide global spinner
    }
  }

  useEffect(() => {
    if (shift?.start_date_time) {
      const today = new Date();
      const shiftDate = convertUTCToLocal(shift?.start_date_time, 'YYYY-MM-DD');

      const momentToday = moment(today);
      const momentShiftDate = moment(shiftDate, 'YYYY-MM-DD');

      if (momentShiftDate.isBefore(momentToday, 'day')) {
        setDisabled(true);
      } else {
        setDisabled(false);
      }
    }
  }, []);

  return (
    <>
      <Header title='Shift Details' />
      <View style={[styles.container]}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}>

          {/* <View style={[styles.shiftTab]}>
            <View style={[styles.companyDetails, { flexDirection: 'column',}]}>
              <View style={[styles.shiftDataRow]}>
                <Text style={{fontWeight:'700'}}>Shift: #{shift?.shift_title}</Text>
                
                {shift?.is_confirmed ? (
                    <Text style={[styles.greenTag]}>Confirmed</Text>
                  ) : (
                    <Text style={[styles.redTag]}>Unconfirmed</Text>
                  )
                }
              </View>
              <View style={[styles.shiftDataRow]}>
                <Text style={{fontWeight:'700'}}>{shift?.client?.label}</Text>
                <Text>
                  {shift?.start_date_time ? convertUTCToLocal(shift?.start_date_time, 'dddd, DD MMM YY') : "N/A"}
                </Text>
              </View>
              <View style={[styles.shiftDataRow]}>
                <Text style={{fontWeight:'700'}}>Post Site</Text>
                <Text>{shift?.post_site?.label}</Text>
              </View>
              <View style={[styles.shiftDataRow]}>
                <Text style={{fontWeight:'700'}}>Start Time</Text>
                <Text>
                  {shift?.start_date_time ? convertUTCToLocal(shift?.start_date_time, 'HH:mm:ss') : "N/A"}
                </Text>
              </View>
              <View style={[styles.shiftDataRow]}>
                <Text style={{fontWeight:'700'}}>End Time</Text>
                <Text>
                  {shift?.end_date_time ? convertUTCToLocal(shift?.end_date_time, 'HH:mm:ss') : "N/A"}
                </Text>
              </View>
              <View style={[styles.shiftDataRow]}>
                <Text style={{fontWeight:'700'}}>Shift Hours</Text>
                <Text>{calculateTimeDifference(shift?.start_date_time, shift?.end_date_time)}</Text>
              </View>
              <View style={[styles.shiftDataRow, {borderBottomWidth:0}]}>
                <Text style={{fontWeight:'700'}}>Breaks</Text>
                <Text>{shift?.breaks.length}</Text>
              </View>
            </View>
          </View> */}

          <View
            style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}>
            <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc' }]}></View>
            <View style={[styles.companyDetails]}>
              <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                <Text style={[styles.companyName, { fontSize: 18 }]}>
                  {shift?.post_site?.label}
                </Text>
                <SpaceBox height={5} />
                <View style={{ flexDirection: 'row' }}>
                  <Icon
                    name={'location-pin'}
                    size={16}
                    style={{ color: '#1d61f4', marginTop: 2 }}
                  />
                  <Text style={styles.companyEmail}>
                    {shift?.post_site?.address}
                  </Text>
                </View>
              </View>
              <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>
              <View style={[{ flexDirection: 'row' }]}>
                <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                  <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                    <Icon2
                      name={'clock'}
                      size={22}
                      style={{ color: '#1d61f4' }}
                    />
                  </View>
                  <View style={{ justifyContent: 'center' }}>
                    <Text style={{ marginLeft: 5, fontSize: 16 }}>Start</Text>
                    <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>{shift?.start_date_time ? convertUTCToLocal(shift?.start_date_time, 'HH:mm:ss') : "N/A"}</Text>
                  </View>
                </View>
                <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                  <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                    <Icon2
                      name={'clock'}
                      size={22}
                      style={{ color: '#1d61f4' }}
                    />
                  </View>
                  <View style={{ justifyContent: 'center' }}>
                    <Text style={{ marginLeft: 5, fontSize: 16 }}>End</Text>
                    <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>{shift?.end_date_time ? convertUTCToLocal(shift?.end_date_time, 'HH:mm:ss') : "N/A"}</Text>
                  </View>
                </View>
              </View>

              <View style={[{ flexDirection: 'row' }]}>
                <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                  <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                    <Icon2
                      name={'clock'}
                      size={22}
                      style={{ color: '#1d61f4' }}
                    />
                  </View>
                  <View style={{ justifyContent: 'center' }}>
                    <Text style={{ marginLeft: 5, fontSize: 16 }}>Shift Hours</Text>
                    <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>{calculateTimeDifference(shift?.start_date_time, shift?.end_date_time)}</Text>
                  </View>
                </View>
                <View style={[styles.notification, { paddingHorizontal: 0, marginRight: 50 }]}>
                  <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                    <Icon2
                      name={'clock'}
                      size={22}
                      style={{ color: '#1d61f4' }}
                    />
                  </View>
                  <View style={{ justifyContent: 'center' }}>
                    <Text style={{ marginLeft: 5, fontSize: 16 }}>Break</Text>
                    <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>{shift?.breaks.length}</Text>
                  </View>
                </View>
              </View>

              <View style={[{ flexDirection: 'row' }]}>
                <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                  <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                    <Icon2
                      name={'clock'}
                      size={22}
                      style={{ color: '#1d61f4' }}
                    />
                  </View>
                  <View style={{ justifyContent: 'center' }}>
                    <Text style={{ marginLeft: 5, fontSize: 16 }}>#{shift?.shift_title}</Text>
                    <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>{shift?.is_confirmed ? (
                      <Text style={[styles.greenTag]}>Confirmed</Text>
                    ) : (
                      <Text style={[styles.redTag]}>Unconfirmed</Text>
                    )
                    }</Text>
                  </View>
                </View>
              </View>
              <View style={[styles.notification, { paddingHorizontal: 0, }]}>
                <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 35, height: 35 }]}>
                  <Icon2
                    name={'clock'}
                    size={22}
                    style={{ color: '#1d61f4' }}
                  />
                </View>
                <View style={{ justifyContent: 'center' }}>
                  <Text style={{ marginLeft: 5, fontSize: 16 }}>{shift?.client?.label}</Text>
                  <Text style={[styles.cardTitle, { marginTop: 0, marginLeft: 5, fontSize: 14 }]}>{shift?.start_date_time ? convertUTCToLocal(shift?.start_date_time, 'dddd, DD MMM YY') : "N/A"}</Text>
                </View>
              </View>
            </View>
          </View>

          <View style={[styles.shiftTab]}>
            <View style={[styles.companyDetails, { flexDirection: 'column', }]}>
              <Text style={{ fontWeight: '700' }}>Notes</Text>
              <View style={{ paddingTop: 5 }}>
                {shift?.note != '' ? (
                  <Text>{shift?.note}</Text>
                ) : (
                  <Text>No notes available for this shift.</Text>
                )}
              </View>
            </View>
          </View>
          
          {shift?.breaks?.map((sbreak, index) => (
            <View style={[styles.shiftTab]} key={index}>
              <View style={[styles.companyDetails, { flexDirection: 'column', }]}>
                <View style={{ flexDirection: 'row', paddingTop: 5 }}>
                  <Text style={{ flex: 1, fontWeight: '700' }}>Breaks</Text>
                  <Text style={[sbreak.break_type == 1 ? iStyles.paid : iStyles.unpaid]}>{sbreak?.label}</Text>
                </View>
                <View style={{ flexDirection: 'row', paddingTop: 5 }}>
                  <Text>Duration</Text>
                  <Text style={{ flex: 1, textAlign: 'right' }}>{sbreak?.duration}</Text>
                </View>
                <View style={{ flexDirection: 'row', paddingTop: 5 }}>
                  <Text style={{ flex: 1 }}>Allowed times(s)</Text>
                  <Text style={{ flex: 1, textAlign: 'right' }}>x{sbreak?.no_of_time_break_taken}</Text>
                </View>
              </View>
            </View>
            )
          )}
        </ScrollView>
      </View>

      {!shift.is_confirmed &&
        <View style={[styles.btnContainer]}>
          <TouchableOpacity
            disabled={disabled}
            style={[disabled ? styles.disabledBtn : styles.Authbtn]}
            onPress={() => saveConfirm()}>
            <Text style={styles.Authbtntext}>
              Confirm
            </Text>
          </TouchableOpacity>
        </View>
      }
    </>
  );
}

export default ShiftDetails;

const iStyles = StyleSheet.create({
  unpaid: {
    backgroundColor: appColors.orange,
    borderRadius: 15,
    paddingHorizontal: 10,
    paddingVertical: 1,
  },
  paid: {
    backgroundColor: appColors.info,
    borderRadius: 15,
    paddingHorizontal: 10,
    paddingVertical: 1,
  }
})