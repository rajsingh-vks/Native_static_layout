import { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, RefreshControl, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import { Calendar } from 'react-native-calendars';
import moment from 'moment';
import Icon from 'react-native-vector-icons/MaterialIcons';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';


import Header from '../Header';
import SpaceBox from '../Common/SpaceBox';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { getRefresh } from '../../redux/refreshSlice';
import { convertUTCToLocal, showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import appColors from '../../utils/appColors';
import styles from '../../utils/styles';
import Index from '../Tasks';

const Shifts = ({ route }) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const { type } = route.params;
  const refresh = useSelector(state => getRefresh(state, 'shifts'));

  const [isDataFetched, setIsDataFetched] = useState(false); // Track whether data fetching is complete
  const [shifts, setShifts] = useState([]);
  const [page, setPage] = useState(1);
  const [markedDates, setMarkedDates] = useState({});
  const [selected, setSelected] = useState('');
  const today = new Date();
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  const loadShifts = async (byDate = '') => {
    setMarkedDates({});
    dispatch(setSpinner(true)); // Show global spinner
    try {
      const response = await api.shiftsList(type, byDate, page);
      if (response?.data) {
        // Set shifts data for listing shifts rows
        setShifts(response?.data ?? []);

        // Set calendar data
        if (response?.data) {
          let mDates = {};
          let mdate = '';
          let bgColor = '';
          let txtColor = '';

          // Initialize the object with initial selected date
          mDates[byDate] = {
            selected: true, // Blue for selected dates
            selectedColor: appColors.blue,
          }

          for (let i = 0; i < response.data.length; i++) {
            // mdate = moment(response.data[i]?.start_date_time).format("YYYY-MM-DD");
            mdate = convertUTCToLocal(response.data[i]?.start_date_time, 'YYYY-MM-DD', false);
            // mdate = moment.utc(response.data[i]?.start_date_time).local().format('YYYY-MM-DD');

            if (response.data[i].is_confirmed) {
              bgColor = appColors.green;
              txtColor = appColors.white;
            } else {
              bgColor = appColors.red;
              txtColor = appColors.white;
            }

            mDates[mdate] = {
              selected: true, // Blue for selected dates
              selectedColor: appColors.blue, // Blue background for selected dates
              customStyles: {
                container: {
                  backgroundColor: bgColor,
                  borderRadius: 50,
                },
                text: {
                  color: txtColor,
                },
              },
            };
          }
          setMarkedDates(mDates);
        }
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error.message || 'Failed to fetch shifts');
    } finally {
      setIsDataFetched(true); // Mark data fetching as complete
      dispatch(setSpinner(false)); // Hide global spinner
    }
  };

  function calculateTimeDifference(time1, time2) {
    // Parse the times using moment
    const momentTime1 = moment(time1);
    const momentTime2 = moment(time2);

    // Calculate the difference in seconds
    const diffInSeconds = Math.abs(momentTime1.diff(momentTime2, "seconds"));

    // Convert seconds to HH:mm:ss format
    const hours = Math.floor(diffInSeconds / 3600);
    const minutes = Math.floor((diffInSeconds % 3600) / 60);
    const seconds = diffInSeconds % 60;

    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
  }

  useEffect(() => {
    loadShifts(selected);
  }, [refresh]);

  return (
    <>
      <Header title={`${type} Shifts`} />
      <View style={[styles.container]}>
        <View>
          <Calendar
            style={styles.shiftCalendar}
            minDate={moment(today).format('YYYY-MM-DD')}
            onMonthChange={(month) => {
              const fmonth = moment().month(month.month - 1).format('MM');
              setSelected(month.year + '-' + fmonth + '-01');
              loadShifts(month.year + '-' + fmonth + '-01');
              // console.log("Month changed to:", month.year+'-'+fmonth+'-01'); 
            }}
            onDayPress={day => {
              setSelected(day.dateString);
              loadShifts(day.dateString);
            }}
            markedDates={markedDates}
            markingType={'custom'}
            theme={{
              todayBackgroundColor: appColors.curDate,
              todayTextColor: appColors.white,
              selectedDayBackgroundColor: appColors.blue,
              selectedDayTextColor: appColors.white,
            }}
          />
        </View>
        <SpaceBox height={10} />

        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={() => loadShifts(selected)}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}>
 
          {/* Conditional rendering for reminders */}
          {isDataFetched && shifts?.length === 0 ? (
            <View style={styles.noRecordsContainer}>
              <Image
                source={require('../../assets/images/not-found.png')}
                style={styles.noRecordsImage}
              />
              <Text style={styles.noRecordsText}>No shifts found.</Text>
            </View>
          ) : (
            shifts?.map((shift, index) => (
            <TouchableOpacity 
              key={index}
              style={[styles.settingTab, { padding: 20, marginBottom: 10 }]}
              onPress={() => navigation.navigate(shift?.is_confirmed? 'confirmed':'shiftDetails', { shift })}>
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#275ffc' }]}></View>
              
              <View style={[styles.companyDetails]}>
                <View style={styles.tabHeader}>
                  <Text style={[styles.companyName, { fontSize: 18 }]}>
                    {shift?.post_site?.label}
                  </Text>
                  <Text style={[styles.tabStatus, shift?.is_confirmed ? styles.greenTag : styles.redTag]}>
                    {shift?.is_confirmed === true ? 'Confirmed' : 'Unconfirmed'}
                  </Text>
                </View>
                <SpaceBox height={5} />
                <View style={{ flexDirection: 'row' }}>
                  <Icon name={'location-pin'} size={16} style={{ color: '#1d61f4', marginRight: 5 }} />
                  <Text style={styles.companyEmail}>
                    {shift?.post_site?.address}
                  </Text>
                </View>

                <View style={[styles.horizontalLine, { backgroundColor: '#B8C7FF' }]}></View>

                <View style={[{ flexDirection: 'row' }]}>
                  <View style={[styles.notification, { paddingHorizontal: 0, flex: 1 }]}>
                    <View style={[styles.tabIconCircle, { backgroundColor: '#e2eaff' }]}>
                      <Icon2 name={'calendar'} size={22} style={{ color: '#1d61f4' }} />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={styles.tabIconLabel}>Date</Text>
                      <SpaceBox height={3} />
                      <Text style={[styles.tabIconTitle, { color: '#000e42' }]}>
                        {shift?.start_date_time ? convertUTCToLocal(shift?.start_date_time, 'DD MMM YY', false) : "N/A"}
                      </Text>
                    </View>
                  </View>
                  <View style={[styles.notification, { paddingHorizontal: 0 }]}>
                    <View style={[styles.tabIconCircle, { backgroundColor: '#e2eaff' }]}>
                      <Icon2 name={'clock'} size={22} style={{ color: '#1d61f4' }} />
                    </View>
                    <View style={{ justifyContent: 'center' }}>
                      <Text style={styles.tabIconLabel}>Time</Text>
                      <SpaceBox height={3} />
                      <Text style={[styles.tabIconTitle, { color: '#000e42' }]}>
                        {shift?.start_date_time ? convertUTCToLocal(shift?.start_date_time, 'HH:mm', false) : "N/A"}
                         - 
                        {shift?.end_date_time ? convertUTCToLocal(shift?.end_date_time, 'HH:mm', false) : "N/A"}
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>
    </>
  );
}

export default Shifts;
