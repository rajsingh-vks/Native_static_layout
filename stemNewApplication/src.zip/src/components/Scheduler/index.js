import * as React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon2 from 'react-native-vector-icons/MaterialIcons';

import Header from '../Header';
import SpaceBox from '../Common/SpaceBox';
import styles from '../../utils/styles';

function Scheduler() {
  const navigation = useNavigation();

  return (
    <>
      <Header title='Scheduler' />
      <View style={[styles.container]}>
        <ScrollView>
          <Text style={styles.settingTitle}>SHIFTS</Text>
          <TouchableOpacity style={[styles.settingTab, {borderRadius:15, marginVertical:5}]} onPress={() => navigation.navigate('shifts', { type: 'All', })}>
            <Icon name={'calendar-month'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>All Shifts</Text>
            <Icon name={'chevron-right'} size={20} style={[styles.roundedGrey, styles.secondaryIcon]} />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.settingTab, {borderRadius:15, marginVertical:5}]} onPress={() => navigation.navigate('shifts', { type: 'Confirmed', })}>
            <Icon2 name={'event-available'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Confirmed Shifts</Text>
            <Icon name={'chevron-right'} size={20} style={[styles.roundedGrey, styles.secondaryIcon]} />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.settingTab, {borderRadius:15, marginVertical:5}]} onPress={() => navigation.navigate('shifts', { type: 'Unconfirmed', })}>
            <Icon2 name={'event'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Unconfirmed Shifts</Text>
            <Icon name={'chevron-right'} size={20} style={[styles.roundedGrey, styles.secondaryIcon]} />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.settingTab, {borderRadius:15, marginVertical:5}]} onPress={() => navigation.navigate('shifts', { type: 'Open', })}>
            <Icon2 name={'edit-calendar'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Open Shifts</Text>
            <Icon name={'chevron-right'} size={20} style={[styles.roundedGrey, styles.secondaryIcon]} />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.settingTab, {borderRadius:15, marginVertical:5}]}>
            <Icon2 name={'event-repeat'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Exchange Shifts</Text>
            <Icon name={'chevron-right'} size={20} style={[styles.roundedGrey, styles.secondaryIcon]} />
          </TouchableOpacity>

          <SpaceBox height={20} />
          <Text style={styles.settingTitle}>OTHERS</Text>
          <TouchableOpacity style={[styles.settingTab, {borderRadius:15, marginVertical:5}]}>
            <Icon2 name={'av-timer'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Time Off Requests</Text>
            <Icon name={'chevron-right'} size={20} style={[styles.roundedGrey, styles.secondaryIcon]} />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.settingTab, {borderRadius:15, marginVertical:5}]}>
            <Icon2 name={'punch-clock'} size={28} style={styles.primaryIcon} />
            <Text style={styles.settingTabTitle}>Time Logs</Text>
            <Icon name={'chevron-right'} size={20} style={[styles.roundedGrey, styles.secondaryIcon]} />
          </TouchableOpacity>
        </ScrollView>
      </View>
    </>
  );
}

export default Scheduler;