import React, { useState, useEffect } from 'react';
import { View, Text, Keyboard, KeyboardAvoidingView, TouchableOpacity, TouchableWithoutFeedback } from 'react-native';
import { useDispatch } from 'react-redux';
import { useNavigation } from '@react-navigation/native';
import { Button, Label } from '@react-navigation/elements';
import PhoneInput from 'react-native-international-phone-number';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Input from './Common/Input';
import api from '../services/api';
import { setSpinner } from '../redux/appSlice';
import validateForm from '../utils/validateForm';
import { showPopup, hidePopup, showErrorToast } from '../utils/appHelpers';
import styles from '../utils/styles';

function Forgot() {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const [selectedRadio, setSelectedRadio] = useState(1);
  const [activeTab, setActiveTab] = useState('email');
  const [selectedCountry, setSelectedCountry] = useState({ callingCode: '', cca2: '', flag: '' });
  const [flag, setCountryFlag] = useState('');
  const [disabled, setDisabled] = useState(true);
  const [keyboardHeight, setKeyboardHeight] = useState(0);
  
  const [fields, setFields] = useState({
    email: '',
    mobile_no: '',
    country_code: '',
    country_iso_code: '',
  });
  const rules_email = {
    email: ['required', 'email'],
  };
  const rules_mobile = {
    mobile_no: ['required', 'string', 'digits:10'],
    country_code: ['required', 'string'],
    country_iso_code: ['required', 'string'],
  };

  // Handle form Tab
  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  // Handle form inputs
  const handleInputChange = (field, value) => {
    setFields((prevState) => ({ ...prevState, [field]: value }));
  };

  const handlePhoneInputChange = (phoneNumber) => {
    setFields((prevState) => ({ ...prevState, mobile_no: phoneNumber.replace(/\s+/g, '') }));
  };

  const handleSelectedCountryChange = (country) => {
    console.log(country, 'country');
    setSelectedCountry(country);
    setFields((prevState) => ({
      ...prevState,
      country_code: country?.callingCode.replace('+', '') || '',
      country_iso_code: country?.cca2 || '',
      flag: country?.flag || '',
    }));
    setCountryFlag(country?.flag || '');
  };

  const sendOTP = async () => {
    Keyboard.dismiss();
    dispatch(setSpinner(true));

    let rules;
    if(activeTab == 'email'){
      rules = rules_email;
    }else{
      rules = rules_mobile;
    }

    let valStat = validateForm(fields, rules);
    if(valStat?.status == true){
      let formData = new FormData();
      if (activeTab === 'email') {
        formData.append('email', fields?.email);
      } else {
        formData.append("mobile_no", fields.mobile_no ?? "");
        formData.append("country_code", fields.country_code ?? "");
        formData.append("country_iso_code", fields.country_iso_code ?? "");
      }
      formData.append('role_id', 4);

      api
      .forgotPassword(formData)
      .then(async res => {
        dispatch(setSpinner(false));
        if (res?.status == '200') {
          navigation.replace('UserOTP', {
            type: (activeTab == 'email')?'email':'phone',
            token: res?.data?.token,
            email: res?.data?.email,
            phone: res?.data?.mobile_no,
            country_code: res?.data?.country_code,
            message: res?.message,
          });
        } else {
          setError(res?.data?.message);
        }
      })
      .catch(function (error) {
        dispatch(setSpinner(false));
        showErrorToast(error?.data?.message);
      })
    }else{
      dispatch(setSpinner(false));
      showPopup('error', 'Please check your input email.');
    }
  };

  // Check field value changes
  useEffect(() => {
    let rules;
    if(activeTab == 'email'){
      rules = rules_email;
    }else{
      rules = rules_mobile;
    }
   
    let valStat = validateForm(fields, rules);
    if(valStat?.status == true){
      setDisabled(false);
    }else{
      setDisabled(true);
    }
  }, [fields]);

  useEffect(() => {
    setFields({...fields, email:'', mobile_no:''})
  }, []);

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      Platform.OS === 'android' ? 'keyboardDidShow' : 'keyboardWillShow',
      (event) => {
        setKeyboardHeight(40);
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      Platform.OS === 'android' ? 'keyboardDidHide' : 'keyboardWillHide',
      () => {
        setKeyboardHeight(0);
      }
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor:'#FFF' }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.authContainer}>
          <TouchableOpacity
            style={[styles.drawerTouch, {backgroundColor:'transparent', borderColor:'#2c3f83', borderWidth:1}]}
            onPress={() => navigation.navigate('Login')}>
              <Icon name='chevron-left' style={[styles.drawerIcon, {color: '#2c3f83'}]}/>
          </TouchableOpacity>

          <View style={{flex:1}}>
            <View style={[{alignItems:'center'}]}>
              <Text style={[styles.authTitle]}>Forgot Password</Text>
              <Text style={styles.authsubtitle}>Enter your email or phone to reset your password.</Text>
            </View>

            <View style={{ flexDirection: 'row' }}>
              <TouchableOpacity onPress={() => [handleTabChange('email'), setSelectedRadio(1)]} style={styles.radioWrapper}>
                <View style={[styles.radio, {marginLeft:0}]}>
                    {
                      selectedRadio === 1 ? <View style={styles.radioBg}></View> : null
                    }
                </View>
                <Text>Email</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => [handleTabChange('phone'), setSelectedRadio(2)]} style={styles.radioWrapper}>
                <View style={[styles.radio, {marginLeft:0}]}>
                    {
                      selectedRadio === 2 ? <View style={styles.radioBg}></View> : null
                    }
                </View>
                <Text>Phone</Text>
              </TouchableOpacity>
            </View>

            {activeTab === 'email' ? (
              <View>
                <Text style={{color: '#001a66', fontSize:17, fontWeight:'700', marginVertical:10}}>Reset Via Email</Text>
                <View style={{ marginVertical: 5 }}>
                  <Input 
                    type='text'
                    label='Email'
                    value={fields.email}
                    leftIcon={<Icon name="email" size={20} color='#001a66'/>}
                    placeholder="Enter your email"
                    placeholderTextColor="#CDCDCD"
                    inputStyle={{paddingHorizontal:5}}
                    onChangeText={(value) => handleInputChange('email', value)}
                  />
                </View>
              </View>
            ) : (
              <View>
                <Text style={{color: '#001a66', fontSize:17, fontWeight:'700', marginVertical:10}}>Reset Via Phone</Text>
                <View style={{ marginVertical: 5 }}>
                  <Label style={styles.label}>Phone Number</Label>
                  <PhoneInput
                    defaultCountry="US"
                    selectedCountry={selectedCountry}
                    onChangePhoneNumber={(value) => handlePhoneInputChange(value)}
                    onChangeSelectedCountry={handleSelectedCountryChange}
                    placeholder="Enter phone number"
                    containerStyle={{
                      backgroundColor: '#fff',
                      padding: 10,
                    }}
                    textInputStyle={{
                      fontSize: 16,
                    }}
                    flagStyle={{
                      width: 100,
                      height: 20,
                    }}
                  />
                </View>
              </View>
            )}
          </View>

          <View style={[styles.btnContainer, {marginHorizontal:0, bottom: keyboardHeight}]}>
            <TouchableOpacity
              style={disabled ? styles.disabledBtn : styles.Authbtn}
              onPress={sendOTP} disabled={disabled}>
              <Text style={styles.Authbtntext}>
                REQUEST FOR OTP
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

export default Forgot;