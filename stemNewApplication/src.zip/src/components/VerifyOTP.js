import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { useDispatch } from 'react-redux';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import axios from 'axios'; // Ensure axios is imported

import env from '../services/env';
import { showErrorToast, showPopup } from '../utils/appHelpers';
import { setSpinner } from '../redux/appSlice';
import styles from '../utils/styles';

const VerifyOTP = ({ route }) => {
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const { type, token, email, phone, country_code } = route.params || {};
  const [otp, setOtp] = useState(Array(4).fill('')); // Initialize 4 empty strings
  const [disabled, setDisabled] = useState(true);

  const inputRefs = useRef([]);

  // Handle changes in individual input boxes
  const handleChange = (text, index) => {
    const newOtp = [...otp];
    newOtp[index] = text;

    if (text && index < otp.length - 1) {
      inputRefs.current[index + 1]?.focus();
    }

    // Update OTP state
    setOtp(newOtp);
  };

  // Handle Backspace functionality
  const handleBackspace = (index) => {
    const newOtp = [...otp];
    newOtp[index] = '';

    // Move focus to the previous field if the current one is empty
    if (index > 0) {
      inputRefs.current[index - 1]?.focus();
    }

    setOtp(newOtp);
  };

  // Validate OTP and submit
  const validateOTP = async () => {
    const otpCode = otp.join('');
    if (otpCode.length !== 4) {
      showErrorToast('Please enter a valid 4-digit OTP.');
      return;
    }

    const formData = new FormData();
    formData.append('otp', otpCode);
    formData.append('vType', type === 'email' ? 'email' : 'phone');

    try {
      dispatch(setSpinner(true));
      const response = await axios.post(`${env.baseURL}/api/guard-verification/`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Token ${token}`,
        },
      });
      
      if (response?.data?.status === 200) {
        dispatch(setSpinner(false));

        if(response?.data?.user?.account_verified == 1){
          navigation.reset({ index: 0, routes: [{ name: 'Success' }] });
        }else{
          let vType = '';
          if(response?.data?.user?.is_email_verified != 1){
            vType = 'email';
          }else if(response?.data?.user?.is_mobile_verified != 1){
            vType = 'phone';
          }

          if(vType != ''){
            // Reset Otp
            setOtp(Array(4).fill(''));
            
            navigation.navigate('VerifyOTP', {
              type: vType,
              token: token,
              email: response?.data?.user?.email,
              phone: response?.data?.user?.mobile_no,
              country_code: response?.data?.user?.country_code,
              message: response?.data?.message,
            });
          }
        }
      }else{
        dispatch(setSpinner(false));
        console.log(JSON.stringify(response, null, 5));
      }
    } catch (error) {
      dispatch(setSpinner(false));
      
      // Handle error
      if(error?.response?.data?.status == 400){
        showErrorToast(error?.response?.data?.message);
      }else{
        console.log(JSON.stringify(error, null, 5));
        showErrorToast("OTP Validation failed.");
      }
    }
  };

  // Disable submit button if OTP is incomplete
  useEffect(() => {
    setDisabled(otp.some((digit) => digit === ''));
  }, [otp]);

  // Clear OTP when the component mounts
  useEffect(() => {
    // dispatch(setSpinner(false));
    setOtp(Array(4).fill(''));
    return () => {
      // Cleanup logic if necessary
      setOtp(Array(4).fill(''));
    };
  }, []);

  return (
    <View style={styles.authContainer}>
      <TouchableOpacity
        style={[styles.drawerTouch, { backgroundColor: 'transparent', borderColor: '#2c3f83', borderWidth: 1 }]}
        onPress={() => navigation.navigate('SignUp')}
      >
        <Icon name="chevron-left" style={[styles.drawerIcon, { color: '#2c3f83' }]} />
      </TouchableOpacity>

      <View style={[styles.auth, { alignItems: 'center' }]}>
        <Text style={styles.authTitle}>OTP Verification</Text>
        
        {type === 'phone' ? (
          <Text style={[styles.authsubtitle, {fontSize:17}]}>
            To verify your account, please enter the OTP sent to your phone number +{country_code}{phone}
          </Text>
        ) : (
          <Text style={[styles.authsubtitle, {fontSize:17}]}>
            To verify your account, please enter the OTP sent to your email {email}.
          </Text>
        )}
      </View>

      <View style={{ marginTop: 40 }}>
        <Text style={[styles.label, {fontSize:18, textAlign:'center'}]}>Enter OTP</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'center', marginBottom: 20 }}>
          {otp.map((digit, index) => (
            <TextInput
              key={index}
              ref={(el) => (inputRefs.current[index] = el)}
              value={digit}
              onChangeText={(text) => handleChange(text, index)}
              onKeyPress={({ nativeEvent }) => {
                if (nativeEvent.key === 'Backspace' && !digit) {
                  handleBackspace(index);
                }
              }}
              keyboardType="numeric"
              maxLength={1}
              style={{
                width: 50,
                height: 50,
                textAlign: 'center',
                fontSize: 18,
                borderWidth: 1,
                borderColor: '#2c3f83',
                borderRadius: 8,
                marginHorizontal: 5,
                backgroundColor: '#fff',
              }}
            />
          ))}
        </View>
      </View>

      <View style={{ height: 50, marginTop: 50 }}>
        <TouchableOpacity
          style={[styles.Authbtn, { backgroundColor: disabled ? '#bbb' : '#2c3f83' }]}
          onPress={validateOTP}
          disabled={disabled}
        >
          <Text style={styles.Authbtntext}>SUBMIT</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default VerifyOTP;
