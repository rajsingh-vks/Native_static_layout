import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  StyleSheet,
  RefreshControl,
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import DocumentPicker from 'react-native-document-picker';
import Header from '../Header';
import Input from '../Common/Input';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { refresh, showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import { getUser } from '../../redux/userSlice';
import validateForm from '../../utils/validateForm';
import styles from '../../utils/styles';
import { Label } from '@react-navigation/elements';
import PhoneInput from 'react-native-international-phone-number';
import { ScrollView } from 'react-native-gesture-handler';


const getFlagEmoji = (countryCode) => {
  return countryCode
    ? String.fromCodePoint(...[...countryCode.toUpperCase()].map((char) => 127397 + char.charCodeAt()))
    : '';
};
function AddEditVisitor({ route, navigation }) {
  const { visitor,siteId } = route.params || {};
  
  
  const [disabled, setDisabled] = useState(true);
  const [selectedCountry, setSelectedCountry] = useState({ callingCode: '', cca2: '', flag: '' });

const [fields, setFields] = useState({
    name: '',
    id_number: '',
    email: '',
    mobile_no: '',
    company: '',
    country_code: '',
    country_iso_code: '',
    id_image: '',
  });

  const user = useSelector(getUser);
  const dispatch = useDispatch();
  const visitor_rules = {
    name: ['required', 'string'],
  };


   useEffect(() => {
      if (visitor) {
        const flag = getFlagEmoji(visitor.country_iso_code || 'IN'); // Generate flag if not available
        setFields({
          name: visitor?.name || '',
          id_number: visitor?.id_number || '',
          company: visitor?.company || '',
          email: visitor?.email != "null" ? visitor?.email : '',
          company: visitor.company || '',
          mobile_no: visitor.mobile_no || '',
          country_code: visitor.country_code || '',
          country_iso_code: visitor.country_iso_code || '',
        });
  
        setSelectedCountry({
          callingCode: visitor.country_code?.replace('+', '') || '',
          cca2: visitor.country_iso_code || 'IN',
          flag: flag,
        });
      }
    }, [visitor]);



  const handleInputChange = (field, value) => {
    setFields((prevState) => ({ ...prevState, [field]: value }));
  };

   // Handle phone number input changes
   const handlePhoneInputChange = (phoneNumber) => {
    setFields((prevState) => ({ ...prevState, mobile_no: phoneNumber }));
  };

    // Handle selected country changes
    const handleSelectedCountryChange = (country) => {
  
      setSelectedCountry(country);
      setFields((prevState) => ({
        ...prevState,
        country_code: `+${country?.callingCode || ''}`,
        country_iso_code: country?.cca2 || 'IN',
        flag: country?.flag || getFlagEmoji(country?.cca2 || 'IN'),
      }));
    };
  const handleImageUpload = async () => {
    try {
      const result = await DocumentPicker.pickSingle({
        type: [DocumentPicker.types.images],
      });

      setFields((prevState) => ({
        ...prevState,
        image: {
          uri: result.uri,
          type: result.type,
          name: result.name,
        },
      }));
    } catch (error) {
      if (DocumentPicker.isCancel(error)) {
        console.log('User canceled the document picker');
      } else {
        console.error('Error selecting document:', error);
      }
    }
  };

 

  const handleSubmit = async (e) => {
    e.preventDefault();
    dispatch(setSpinner(true));
  
    try {
      let formData = new FormData();
      formData.append("guard_id", user?.id || "");
      formData.append("company_id", user?.company_id || "");
      formData.append("post_site_id", siteId || "");
  
      if (visitor?.id) {
        formData.append("visitor_id", visitor.id);
      }
  
      formData.append("name", fields?.name || "");
      formData.append("id_number", fields?.id_number || "");
      formData.append("company", fields?.company || "");
      formData.append("email", fields?.email || "");
      formData.append("mobile_no", fields?.mobile_no?.trim() || "");
      formData.append("country_code", fields?.country_code?.trim() || "");
      formData.append("country_iso_code", fields?.country_iso_code?.trim() || "");
  

      if (fields?.image?.uri && fields?.image?.type && fields?.image?.name) {
        formData.append("id_image", {
          uri: fields.image.uri,
          type: fields.image.type,
          name: fields.image.name,
        });
      }
  
      const response = visitor?.id
        ? await api.updateVisitor(formData)
        : await api.addVisitor(formData);
  
      if (response?.status) {
        showSuccessToast(response.message);
        navigation.navigate('visitors');
      } else {
        showErrorToast(response?.message || "Something went wrong");
      }
    } catch (error) {
      console.error("Error updating Visitor:", error);
      showErrorToast(error?.data?.message || "An unexpected error occurred");
    } finally {
      dispatch(setSpinner(false));
    }
  };
  

  useEffect(() => {
    let rules = visitor_rules;
    let valStat = validateForm(fields, rules);
    setDisabled(!valStat?.status);
  }, [fields]);

  return (
    <>
      <Header title={visitor?.id ? 'Update Visitor' : 'Add Visitor'} />
      <View style={[{ flex: 1, backgroundColor: '#fff', paddingHorizontal: 15, paddingTop: 20 }]}>
          <ScrollView
                  refreshControl={
                    <RefreshControl
                      refreshing={false}
                      onRefresh={() => getVisitors()}
                    />
                  }
                  contentContainerStyle={{ flexGrow: 1, paddingBottom: 50 }}
                  showsVerticalScrollIndicator={false}>
        <View style={[styles.card_template, { width: 'auto', boxShadow: 'none', backgroundColor: '#fff', padding: 0 }]}>
         

          <View style={{ marginVertical: 5 }}>
            <Input
              type="text"
              label="Full Name"
              value={fields.name}
              placeholder="Full name"
              required={true}
              placeholderTextColor="#CDCDCD"
              inputStyle={{ paddingHorizontal: 5 }}
              onChangeText={(value) => handleInputChange('name', value)}
            />
          </View>

          <View style={{ marginVertical: 5 }}>
            <Input
              type="text"
              label="Id Number"
              value={fields.id_number}
              placeholder="ID number"
              placeholderTextColor="#CDCDCD"
              inputStyle={{ paddingHorizontal: 5 }}
              onChangeText={(value) => handleInputChange('id_number', value)}
            />
          </View>

          <View style={{ marginVertical: 5 }}>
            <Input
              type="text"
              label="Company Name"
              value={fields.company}
              placeholder="Company name"
              placeholderTextColor="#CDCDCD"
              inputStyle={{ paddingHorizontal: 5 }}
              onChangeText={(value) => handleInputChange('company', value)}
            />
          </View>

          <View style={{ marginVertical: 5 }}>
          <Label style={styles.label}>Phone Number</Label>
              <PhoneInput
                value={fields.mobile_no} // Mobile number field
                selectedCountry={selectedCountry}
                onChangePhoneNumber={(value) => handlePhoneInputChange(value)}
                onChangeSelectedCountry={handleSelectedCountryChange}
                placeholder="Phone number"
                containerStyle={{
                  backgroundColor: '#fff',
                  padding: 10,
                }}
                textInputStyle={{
                  fontSize: 16,
                }}
                flagStyle={{
                  width: 30,
                  height: 20,
                }}
              />
          </View>

          <View style={{ marginVertical: 5 }}>
            <Input
              type="text"
              label="Email Address"
              value={fields.email}
              placeholder="Email address"
              placeholderTextColor="#CDCDCD"
              inputStyle={{ paddingHorizontal: 5 }}
              onChangeText={(value) => handleInputChange('email', value)}
            />
          </View>

          

          <View style={{ marginVertical: 5 }}>
            <Text style={styles.label}>
             Id Image
            </Text>
            <View style={isStyles.attachmentBox}>
              <TouchableOpacity style={isStyles.uploadButton} onPress={handleImageUpload}>
                <Image
                  source={{
                    uri: 'https://img.icons8.com/ios-filled/50/upload-to-cloud.png',
                  }}
                  style={isStyles.uploadIcon}
                />
                <Text style={isStyles.uploadText}>Upload Document</Text>
              </TouchableOpacity>
              <Text style={isStyles.fileGuidelines}>
                Allowed file types: jpeg, jpg, png (Max file size: 10MB)
              </Text>
            </View>
            {fields.image && (
              <View style={isStyles.imagePreview}>
                <Image source={{ uri: fields.image.uri }} style={isStyles.image} />
                <Text style={isStyles.imageName}>{fields.image.name}</Text>
              </View>
            )}
          </View>
        </View>
        </ScrollView>
        <View style={{ height: 50, marginBottom: 20 }}>
          <TouchableOpacity
            style={disabled ? styles.disabledBtn : styles.Authbtn}
            disabled={disabled}
            onPress={handleSubmit}
          >
            <Text style={styles.Authbtntext}>Save</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
}

const isStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 15,
    paddingTop: 20,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 3,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 5,
  },
  pickerWrapper: {
    borderWidth: 1,
    borderColor: '#CDCDCD',
    borderRadius: 5,
  },
  inputGroup: {
    marginVertical: 5,
  },
  attachmentBox: {
    borderWidth: 1,
    borderColor: '#CDCDCD',
    borderStyle: 'dashed',
    borderRadius: 5,
    padding: 15,
    alignItems: 'center',
  },
  uploadButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  uploadIcon: {
    width: 24,
    height: 24,
    marginRight: 10,
  },
  uploadText: {
    color: '#007BFF',
    fontSize: 16,
  },
  fileGuidelines: {
    color: '#888',
    fontSize: 12,
    marginTop: 10,
    textAlign: 'center',
  },
  imagePreview: {
    marginTop: 15,
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    padding: 10,
    borderRadius: 5,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 5,
    marginBottom: 10,
  },
  imageName: {
    fontSize: 12,
    color: '#666',
  },
  buttonContainer: {
    height: 50,
    marginBottom: 20,
  },
  authBtn: {
    backgroundColor: '#007BFF',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  authBtnText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  disabledBtn: {
    backgroundColor: '#ccc',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
});

export default AddEditVisitor;
