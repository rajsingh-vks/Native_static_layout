import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import ImageViewing from "react-native-image-viewing";

import Header from '../Header';

const VisitorDetails = ({ route, navigation }) => {
  const { visitor,siteId } = route.params;
  
  
  
  const [isViewerVisible, setIsViewerVisible] = useState(false);
  const [images, setImages] = useState([{ uri: visitor?.image }]); 
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const openImage = (imageUri) => {
    setImages([{ uri: imageUri }]); 
    setIsViewerVisible(true); 
  };

  return (
    <>
      <Header title="Visitor Info" />
      <View style={styles.container}>
        <ScrollView
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}
          showsVerticalScrollIndicator={false}>
          <View style={styles.infoRow}>
            <View style={styles.iconWrapper}>
              <Icon name="account" style={styles.icon} />
            </View>
            <View style={styles.textWrapper}>
              <Text style={styles.infoTitle}>Name</Text>
              <Text style={styles.infoSubtitle}>
                {visitor?.name ?? '--'}
              </Text>
            </View>
          </View>

          <View style={styles.infoRow}>
            <View style={styles.iconWrapper}>
              <Icon name="card-account-details" style={styles.icon} />
            </View>
            <View style={styles.textWrapper}>
              <Text style={styles.infoTitle}>Id Number</Text>
              <Text style={styles.infoSubtitle}>
                {visitor?.id_number ?? '--'}
              </Text>
            </View>
          </View>

          <View style={styles.infoRow}>
            <View style={styles.iconWrapper}>
              <Icon name="domain" style={styles.icon} />
            </View>
            <View style={styles.textWrapper}>
              <Text style={styles.infoTitle}>Company</Text>
              <Text style={styles.infoSubtitle}>
                {visitor?.company ?? '--'}
              </Text>
            </View>
          </View>

          <View style={styles.infoRow}>
            <View style={styles.iconWrapper}>
              <Icon name="phone" style={styles.icon} />
            </View>
            <View style={styles.textWrapper}>
              <Text style={styles.infoTitle}>Phone Number</Text>
              <Text style={styles.infoSubtitle}>
              {visitor?.country_code ? `+${visitor?.country_code} ${visitor?.mobile_no ?? '--'}` : visitor?.mobile_no ?? '--'}

              </Text>
            </View>
          </View>

          <View style={styles.infoRow}>
            <View style={styles.iconWrapper}>
              <Icon name="email" style={styles.icon} />
            </View>
            <View style={styles.textWrapper}>
              <Text style={styles.infoTitle}>Email</Text>
              <Text style={styles.infoSubtitle}>
              {visitor?.email != "null" ? visitor?.email : "--"}
              </Text>
            </View>
          </View>
          

          <View style={styles.infoRow}>
            
            <View style={styles.textWrapper}>
              <Text style={styles.infoTitle}>ID Image</Text>
              <TouchableOpacity onPress={() => openImage(visitor?.image)}>
                <Image
                  source={{ uri: visitor?.id_image }}
                  style={styles.imageThumbnail}
                  resizeMode="cover"
                  onError={(e) =>
                    console.log('Image Load Error:', e.nativeEvent.error)
                  }
                />
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>

        <ImageViewing
          images={images}
          imageIndex={currentImageIndex}
          visible={isViewerVisible}
          onRequestClose={() => setIsViewerVisible(false)}
        />
      </View>

      <View style={styles.btnContainer}>
        <TouchableOpacity
          style={styles.Authbtn}
          onPress={() => navigation.navigate('addEditVisitor', { visitor,siteId })}>
          <Text style={styles.Authbtntext}>Update Visitor</Text>
        </TouchableOpacity>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  iconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#e0e0e0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    fontSize: 20,
    color: '#3b5998',
  },
  textWrapper: {
    marginLeft: 10,
    flex: 1,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  infoSubtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 5,
  },
  imageThumbnail: {
    width: 100,
    height: 100,
    borderRadius: 5,
    marginTop: 10,
  },
  btnContainer: {
    justifyContent: 'center',
    height: 50,
    marginHorizontal: 15,
    bottom: 20,
    marginTop: 10,
  },
  Authbtn: {
    flex: 1,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#001a66',
  },
  Authbtntext: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default VisitorDetails;
