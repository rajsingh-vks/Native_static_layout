import { useCallback, useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, RefreshControl, ScrollView, StyleSheet } from 'react-native';
import { convertUTCToLocal, showErrorToast, showSuccessToast } from '../../utils/appHelpers';
import { useDispatch, useSelector } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import Header from '../Header';
import { showConfirmationBox } from '../Common/Confirmation';
import api from '../../services/api';
import { setSpinner } from '../../redux/appSlice';
import { getRefresh } from '../../redux/refreshSlice';
import styles from '../../utils/styles';
import { getUser } from '../../redux/userSlice';
import { useFocusEffect } from '@react-navigation/native';

const Index = ({ route, navigation }) => {
  const { siteId } = route?.params;
  
  
  const dispatch = useDispatch();
  const [visitors, setVisitors] = useState([]);
  const [search,setSearch] = useState('');
  const [page,setPage] = useState(1);
  const [isDataFetched, setIsDataFetched] = useState(false);
  const refresh = useSelector((state) => getRefresh(state, 'visitors'));
  const user = useSelector(getUser);

  const getVisitors = async () => {
    dispatch(setSpinner(true));
    try {
      const response = await api.visitorList(search,page,siteId,user?.id,user?.company_id);
      console.log(response);
      
      
      if (response?.status == 200) {
        setVisitors(response.data ?? []);
      } else {
        showErrorToast(response?.message);
      }
    } catch (error) {
      showErrorToast(error?.message);
    } finally {
      setIsDataFetched(true);
      dispatch(setSpinner(false));
    }
  };

  const handleVisitorDelete = async (id) => {
    showConfirmationBox(
      'Delete Visitor',
      'Are you sure you want to delete this Visitor?',
      async () => {
        dispatch(setSpinner(true));
        try {
          const formData = new FormData();
          formData.append("visitor_id", id);
          formData.append("action", 4);


          const response = await api.deleteVisitor(formData);

          if (response.status == 200) {
            const updateVisitor = visitors.filter((item) => item.id !== id);
            setVisitors(updateVisitor);
            showSuccessToast(response?.message);
          } else {
            showErrorToast(response?.message);
          }
        } catch (error) {
          showErrorToast(error?.message);
        } finally {
          dispatch(setSpinner(false));
        }
      }
    );
  };

 

  useEffect(() => {
    getVisitors();
  }, [refresh]);

    useFocusEffect(
      useCallback(() => {
        getVisitors(); 
    
        return () => {}; 
      }, [])
    );

  return (
    <>
      <Header title="visitors" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={() => getVisitors()}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 50 }}
          showsVerticalScrollIndicator={false}>
          {visitors?.length > 0 && <Text style={styles.settingTitle}>visitors</Text>}

          {isDataFetched && visitors?.length === 0 ? (
            <View style={styles.noRecordsContainer}>
              <Image
                source={require('../../assets/images/not-found.png')}
                style={styles.noRecordsImage}
              />
              <Text style={styles.noRecordsText}>No Data Found</Text>
            </View>
          ) : (
            visitors?.map((visitor, index) => (
              <TouchableOpacity
                key={index}
                style={[styles.settingTab, { borderRadius: 15, marginVertical: 0, paddingVertical: 5 }]}
                onPress={() => navigation.navigate('visitorDetails', { visitor,siteId })}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.settingTabTitle, { fontSize: 16, fontWeight: '900', marginLeft: 0, marginBottom: 10 }]}>{visitor?.name ?? '--'}</Text>

                  <Text style={iStyles.priorityText}>
                   ID: {visitor?.id_number ?? "--"}
                  </Text>
                  <Text style={iStyles.priorityText}>
                   {visitor?.email != "null" ? visitor?.email : "--"}
                  </Text>
                  <Text style={iStyles.subtitle}>
                    Date: {convertUTCToLocal(visitor?.created_on, 'MMM DD, YYYY')}
                  </Text>

                </View>
                <View style={{ marginBottom: 5 }}>
                  <Icon name={'chevron-right'} size={20} style={[styles.roundedGrey, styles.secondaryIcon]} />
                  <TouchableOpacity
                    onPress={(e) => {
                      e.stopPropagation();
                      handleVisitorDelete(visitor?.id);
                    }}
                    style={{ paddingHorizontal: 10 }}>
                    <Icon name="delete" size={20} color="#dc3545" />
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            ))
          )}
        </ScrollView>
      </View>
      <View style={[styles.btnContainer]}>
        <TouchableOpacity
          style={styles.Authbtn}
          onPress={() => navigation.navigate('addEditVisitor',{siteId })}>
          <Text style={styles.Authbtntext}>
            Add Visitor
          </Text>
        </TouchableOpacity>
      </View>

    </>
  );
}

const iStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollView: {
    flexGrow: 1,
    paddingBottom: 100,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginHorizontal: 15,
    marginVertical: 10,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginHorizontal: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  chevronIcon: {
    color: '#888',
  },
  cardBody: {
    paddingTop: 5,
  },
  subtitle: {
    fontSize: 13,
    color: '#666',
    marginBottom: 5,
  },
  priorityText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#007bff',
    marginBottom: 10,
  },
  statusText: {
    fontSize: 13,
    fontWeight: '900',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 10,
  },
  statusAction: {
    fontSize: 14,
    fontWeight: '600',
  },
  noDataContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  noDataImage: {
    width: 150,
    height: 150,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  noDataText: {
    fontSize: 16,
    color: '#666',
  },
  footer: {
    padding: 15,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  addButton: {
    backgroundColor: '#003c8f', // Dark blue color
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default Index;
