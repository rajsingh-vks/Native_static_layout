import * as React from 'react';
import { View, Text, TouchableOpacity, ScrollView, RefreshControl } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

import Header from '../Header';
import styles from '../../utils/styles';
import SpaceBox from '../Common/SpaceBox';

function Activity() {

  return (
    <>
      <Header title="Activity" />
      <View style={[styles.container]}>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={false}
            />
          }
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>
          <View>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 10, marginBottom: 10 }]}
            >
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#0DA927', left: '0', height: '70%', top: '30%' }]}></View>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={[{ flexDirection: 'row' }]}>
                    <TouchableOpacity style={[styles.companyName, { backgroundColor: '#A4FFB2', borderRadius: 4, paddingVertical: 2, paddingHorizontal: 6 }]}>
                      <Text style={{ color: '#0DA927' }}>Check-In</Text>
                    </TouchableOpacity>
                  </View>
                  <SpaceBox height={8} />
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 45, height: 45, marginRight: 8 }]}>
                      <Icon
                        name={'alarm-outline'}
                        size={30}
                        style={{ color: '#1d61f4' }}
                      />
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 18, fontWeight: 400, flex: 1 }]}>
                        Monday, 12 Feb 2023
                      </Text>
                      <View style={{ flexDirection: 'row' }}>
                        <Text style={[styles.companyEmail, { fontSize: 14, color: '#2360FB' }]}>
                          09:12 AM
                        </Text>
                        <Text style={[styles.companyEmail, { fontSize: 14, marginLeft: 4 }]}>
                          (Check-In)
                        </Text>
                        <View style={styles.roundedBlue}></View>
                        <Text style={[styles.companyEmail, { fontSize: 14, color: '#2360FB' }]}>
                          09:12 AM
                        </Text>
                        <Text style={[styles.companyEmail, { fontSize: 14, marginLeft: 4 }]}>
                          (Check-Out)
                        </Text>
                      </View>
                    </View>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.settingTab, { padding: 10, marginBottom: 10 }]}
            >
              <View style={[styles.absoluteLeftLine, { backgroundColor: '#F63939', left: '0', height: '70%', top: '30%' }]}></View>
              <View style={[styles.companyDetails]}>
                <View style={[styles.companyRow, { flexDirection: 'column', flex: 1 }]}>
                  <View style={[{ flexDirection: 'row' }]}>
                    <TouchableOpacity style={[styles.companyName, { backgroundColor: '#FFA4A4', borderRadius: 4, paddingVertical: 2, paddingHorizontal: 6 }]}>
                      <Text style={{ color: '#F63A3A' }}>Check-Out</Text>
                    </TouchableOpacity>
                  </View>
                  <SpaceBox height={8} />
                  <View style={{ flexDirection: 'row' }}>
                    <View style={[styles.iconCircle, { backgroundColor: '#e2eaff', width: 45, height: 45, marginRight: 8 }]}>
                      <Icon
                        name={'alarm-outline'}
                        size={30}
                        style={{ color: '#1d61f4' }}
                      />
                    </View>
                    <View>
                      <Text style={[styles.companyName, { fontSize: 18, fontWeight: 400, flex: 1 }]}>
                        Monday, 12 Feb 2023
                      </Text>
                      <View style={{ flexDirection: 'row' }}>
                        <Text style={[styles.companyEmail, { fontSize: 14, color: '#2360FB' }]}>
                          09:12 AM
                        </Text>
                        <Text style={[styles.companyEmail, { fontSize: 14, marginLeft: 4 }]}>
                          (Check-In)
                        </Text>
                        <View style={styles.roundedBlue}></View>
                        <Text style={[styles.companyEmail, { fontSize: 14, color: '#2360FB' }]}>
                          09:12 AM
                        </Text>
                        <Text style={[styles.companyEmail, { fontSize: 14, marginLeft: 4 }]}>
                          (Check-Out)
                        </Text>
                      </View>
                    </View>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </>
  );
}

export default Activity