import React, { useEffect, useState } from 'react';
import { SafeAreaView, Image, FlatList, View, Text, StatusBar, TouchableOpacity, Dimensions, ImageBackground } from 'react-native';
// import SplashScreen from 'react-native-splash-screen';
import Lottie from 'lottie-react-native';
import { useDispatch, useSelector } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getUser, setUser } from '../redux/userSlice';

import SpaceBox from '../components/Common/SpaceBox';
import constants from '../utils/constants';
import styles from '../utils/styles';
import appColors from '../utils/appColors';

const { width, height } = Dimensions.get('window');

const slides = [
  {
    id: '1',
    image: require('../assets/images/ic_onboarding1.png'),
    title: 'Scheduling & Workforce\nManagement System for\nSecurity Guard',
    subtitle: 'Bring smoothness & efficiency in your \n operations. Ensure fairness at every step.',
  },
  {
    id: '2',
    image: require('../assets/images/ic_onboarding2.png'),
    title: 'Manage Security Officers.\n Validate their Work & Send\nReports to Clients Instantly',
    subtitle: 'Bring smoothness & efficiency in your \n operations. Ensure fairness at every step.',
  },
];

const Slide = ({ item }) => {
  return (
    <View style={styles.OnBoardingSlideContainer}>
      <Image
        source={item?.image}
        style={styles.OnBoardingImage}
      />
      <View>
        <Text style={styles.OnBoardingtitle}>{item?.title}</Text>
        <Text style={styles.OnBoardingsubtitle}>{item?.subtitle}</Text>
      </View>
    </View>
  );
};

const OnboardingScreen = ({ navigation }) => {
  const dispatch = useDispatch();
  const user = useSelector(getUser)
  const [loading, setLoading] = useState(true);

  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const ref = React.useRef();
  const updateCurrentSlideIndex = e => {
      const contentOffsetX = e.nativeEvent.contentOffset.x;
      const currentIndex = Math.round(contentOffsetX / width);
      setCurrentSlideIndex(currentIndex);
  };

  const goToNextSlide = () => {
      const nextSlideIndex = currentSlideIndex + 1;
      if (nextSlideIndex != slides.length) {
          const offset = nextSlideIndex * width;
          ref?.current.scrollToOffset({ offset });
          setCurrentSlideIndex(currentSlideIndex + 1);
      }
  };

  const skip = () => {
      const lastSlideIndex = slides.length - 1;
      const offset = lastSlideIndex * width;
      ref?.current.scrollToOffset({ offset });
      setCurrentSlideIndex(lastSlideIndex);
  };

  const getStarted = async () => {
    await AsyncStorage.setItem(constants.storageKeys.INIT, '1');
    navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
  }

  const FooterBotton = () => {
    return (
        <View
            style={styles.OnBoardingfooter}>
            {/* Indicator container */}
            <View
                style={styles.IndicatorWrapper}>
                {/* Render indicator */}
                {slides.map((_, index) => (
                    <View
                        key={index}
                        style={[
                            styles.indicator,
                            currentSlideIndex == index && {
                                backgroundColor: "#fff",
                                width: 25,
                            },
                        ]}
                    />
                ))}
            </View>

            {/* Render buttons */}
            <View style={{ marginBottom: 20 }}>
                {currentSlideIndex == slides.length - 1 ? (
                    <View style={{ height: 50 }}>
                        <TouchableOpacity
                            style={styles.OnBoardingbtn}
                            onPress={() => getStarted()}>
                            <Text style={styles.OnBoardingbtntext}>
                                GET STARTED
                            </Text>
                        </TouchableOpacity>
                    </View>
                ) : (
                    <View style={{ flexDirection: 'row' }}>
                        <TouchableOpacity
                            activeOpacity={0.8}
                            style={[
                                styles.OnBoardingbtn,
                                {
                                    borderColor: "#fff",
                                    borderWidth: 1,
                                    backgroundColor: 'transparent',
                                },
                            ]}
                            onPress={skip}>
                            <Text
                                style={{
                                    fontSize: 15,
                                    color:  "#fff",
                                }}>
                                SKIP
                            </Text>
                        </TouchableOpacity>
                        <View style={{ width: 15 }} />
                        <TouchableOpacity
                            activeOpacity={0.8}
                            onPress={goToNextSlide}
                            style={styles.OnBoardingbtn}>
                            <Text
                                style={styles.OnBoardingbtntext}>
                                NEXT
                            </Text>
                        </TouchableOpacity>
                    </View>
                )}
            </View>
        </View>
    );
  };

  const fetchInit = async () => {
    // Get onboard visited status
    const onboardStatus = await AsyncStorage.getItem(constants.storageKeys.INIT);

    try {
      const userData = await AsyncStorage.getItem(constants.storageKeys.USER);
      const user = userData ? JSON.parse(userData) : null;

      if(user){
        dispatch(setUser(user));
      }else{
        if(onboardStatus == '1'){
          navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
        }
        setLoading(false);
      }
    }catch (e) {
      // console.log('Error : ', e.message);
      if(onboardStatus == '1'){
        navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
      }
      setLoading(false);
    }
  }

  useEffect(() => {
    if (user?.token) {
      // Navigate to Dashboard
      // navigation.reset({ index: 0, routes: [{ name: 'Tab' }] });
      navigation.reset({ index: 0, routes: [{ name: 'DrawerNavigation' }] });
      console.log(navigation.getState());
      setLoading(false);
    }
  }, [user])

  useEffect(() => {
    fetchInit()
  }, []);


  return (
    <>
      {loading == true ? (
        <View style={{
          alignItems: 'center',
          justifyContent: 'center',
          height: height,
          backgroundColor: 'rgba(75, 112, 141, 0.3)',
        }}>
          <Lottie
            style={styles.loaderIcon}
            source={require('../assets/lottie/loader.json')}
            autoPlay
            loop
            speed={1.5}
            colorFilters={[
              {
                keypath: 'circle1',
                color: '#1e2f97',
              },
              {
                keypath: 'circle2',
                color: '#5840bb',
              },
              {
                keypath: 'circle3',
                color: '#1aa7ec',
              },
              {
                keypath: 'circle4',
                color: '#45a8d9',
              },
            ]}
          />
        </View>
      ) : (
        <ImageBackground 
          source={require('../assets/images/Onboarding_bg.png')} 
          resizeMode="cover" 
          style={styles.OnboardingContainerImage}>
            <StatusBar backgroundColor={appColors.blueHeader} />
            <FlatList
              ref={ref}
              onMomentumScrollEnd={updateCurrentSlideIndex}
              contentContainerStyle={{ height: height * 0.75 }}
              showsHorizontalScrollIndicator={false}
              horizontal
              data={slides}
              pagingEnabled
              renderItem={({ item }) => <Slide item={item} />}
            />
            <FooterBotton />
        </ImageBackground>
      )}
    </>
  );
};

export default OnboardingScreen;