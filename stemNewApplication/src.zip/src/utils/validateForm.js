const validateForm = (fields, rules = {}, custom_msg = {}) => {
  let errors = {};
  const setError = (field_name = '', ruleName = '') => {
    // replace attribute with field name
    let err_msg = '';
    const [rule_name, rule_value] = splitByFirstColon(ruleName);
    if (error_messages[rule_name]) {
      err_msg = error_messages[rule_name].replace(':attribute', field_name.replace(/_/g, ' '),);
      err_msg = err_msg.replace(' id', '');
      err_msg = err_msg.replace(':value', rule_value);
    }
    if (errors[field_name]) {
      errors[field_name].push(
        custom_msg[`${field_name}.${rule_name}`] || err_msg,
      );
    } else {
      errors = {
        ...errors,
        [field_name]: [custom_msg[`${field_name}.${rule_name}`] || err_msg],
      };
    }
  };

  try {
    field_names = Object.keys(rules);
    field_names.forEach(field_name => {
      if (
        (rules[field_name].includes('optional') && fields[field_name]) ||
        !rules[field_name].includes('optional')
      ) {
        rules[field_name].forEach(ruleName => {
          const [rule_name, ruleValue] = splitByFirstColon(ruleName);
          switch (rule_name) {
            case 'required':
              if (!fields[field_name]) {
                setError(field_name, rule_name);
              }
              break;
            case 'email':
              if (
                !String(fields[field_name])
                  .toLowerCase()
                  .match(
                    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                  )
              ) {
                setError(field_name, rule_name);
              }
              break;
            case 'string':
              if (!typeof fields[field_name] == 'string') {
                setError(field_name, rule_name);
              }
              break;
            case 'integer':
              if (!Number.isInteger(fields[field_name])) {
                setError(field_name, rule_name);
              }
              break;
            case 'boolean':
              if (!typeof fields[field_name] == 'boolean') {
                setError(field_name, rule_name);
              }
              break;
            case 'array':
              if (!Array.isArray(fields[field_name])) {
                setError(field_name, rule_name);
              }
              break;
            case 'maxArrayLenth':
              if (fields[field_name].length > ruleValue) {
                setError(field_name, `${rule_name}:${ruleValue}`);
              }
              break;
            case 'maxIntegerValue':
              if (fields[field_name] > ruleValue) {
                setError(field_name, `${rule_name}:${ruleValue}`);
              }
              break;
            case 'digits':
              if (String(fields[field_name]).length != ruleValue) {
                setError(field_name, `${rule_name}:${ruleValue}`);
              }
              break;
            case 'maxStringLength':
              if (fields[field_name].length > ruleValue) {
                setError(field_name, `${rule_name}:${ruleValue}`);
              }
              break;
            case 'maxDate':
              const maxDate1 = new Date(fields[field_name]);
              const maxDate2 = new Date(ruleValue);
              if (maxDate1.getTime() > maxDate2.getTime()) {
                setError(field_name, `${rule_name}:${ruleValue}`);
              }
              break;
            case 'minDate':
              const minDate1 = new Date(fields[field_name]);
              const minDate2 = new Date(ruleValue);
              if (minDate1.getTime() < minDate2.getTime()) {
                setError(field_name, `${rule_name}:${ruleValue}`);
              }
              break;
            case 'maxTime':
              const maxTime1 = parseTimeToMinutes(fields[field_name]);
              const maxTime2 = parseTimeToMinutes(ruleValue);
              if (maxTime1 > maxTime2) {
                setError(field_name, `${rule_name}:${ruleValue}`);
              }
              break;
            case 'minTime':
              const minTime1 = parseTimeToMinutes(fields[field_name]);
              const minTime2 = parseTimeToMinutes(ruleValue);
              if (minTime1 < minTime2) {
                setError(field_name, `${rule_name}:${ruleValue}`);
              }
              break;
            case 'gtTime':
              const gtTime1 = parseTimeToMinutes(fields[field_name]);
              const gtTime2 = parseTimeToMinutes(ruleValue);
              if (gtTime1 <= gtTime2) {
                setError(field_name, `${rule_name}:${ruleValue}`);
              }
              break;
            case 'numeric':
              if (isNaN(fields[field_name])) {
                setError(field_name, rule_name);
              }
              break;
          }
        });
      }
    });
    return Object.keys(errors).length > 0
      ? { status: false, message: errors }
      : { status: true, message: 'Form validated successfully.' };
  } catch (error) {
    return { status: false, message: 'Something went wrong..!' };
  }
};

export default validateForm;

const error_messages = {
  required: 'The :attribute field is required.',
  email: 'The :attribute must be a valid email address.',
  integer: 'The :attribute must be an integer.',
  boolean: 'The :attribute field must be true or false.',
  array: 'The :attribute must be an array.',
  maxArrayLenth: 'The :attribute must not have more than :value items.',
  maxIntegerValue: 'The :attribute must not be greater than :value.',
  maxStringLength: 'The :attribute must not be greater than :value characters.',
  maxDate: 'The :attribute must not be greater than :value date.',
  minDate: 'The :attribute must be equal to or greater than :value date.',
  maxTime: 'The :attribute must not be greater than :value time.',
  minTime: 'The :attribute must be equal to or greater than :value time.',
  gtTime: 'The :attribute must be greater than :value time.',
  digits: 'The :attribute must be :value digits.',
  numeric: 'The :attribute must be a number.',
  string: 'The :attribute must be a string.',
  url: 'The :attribute must be a valid URL.',
};


function parseTimeToMinutes(timeStr) {
  const [hours, minutes] = timeStr.split(':').map(Number);
  return hours * 60 + minutes;
}

function splitByFirstColon(str) {
  const [first, ...rest] = str.split(':');
  return [first, rest.join(':')];
}
