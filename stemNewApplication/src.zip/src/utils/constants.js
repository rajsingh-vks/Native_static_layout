const settingsTable = {
  USER_ID: "user_id",
  COMPANY_ID: "company_id",
  CLOCKIN_DATE: "clockin_date",
  LOCATION_FETCH_INTERVAL: "location_fetch_interval",
  LOCATION_SUBMIT_INTERVAL: "location_submit_interval",
  LOCATION_MIN_UPDATE_DISTANCE: "location_min_update_distance",
  API_AUTH_TOKEN: "api_auth_token",
  API_BASE_URL: "api_base_url",
}

const storageKeys = {
  VERSION: 'version',
  APP_VERSION: 'app_version',
  USER: 'user',
  FCM_TOPICS: 'fcm_topics',
  LOGIN: 'login',
  LOGOUT: 'logout',
  USER_ROLE: '4',
  INIT: 'init'
}

export default constants = {
  settingsTable,
  storageKeys
}
