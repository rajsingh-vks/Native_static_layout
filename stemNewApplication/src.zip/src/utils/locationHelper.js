import { Alert, NativeModules, Platform } from "react-native";
import * as Permissions from 'react-native-permissions';
import Geolocation from '@react-native-community/geolocation';
import { getDistance } from 'geolib';
import DeviceInfo from "react-native-device-info";

import store from "../redux/store";
import { setLocationPermissionModal, setLocationServiceModal } from "../redux/modalSlice";
import { hidePopup, showErrorToast } from "./appHelpers";
import moment from "moment";
import database from "./database";
import constants from "./constants";
import env from "../services/env";

const { LocationModule } = NativeModules;

/** 
 * This function is used to fetch the permission
 */
async function hasPermissions() {
  const isLocationEnabled = await DeviceInfo.isLocationEnabled();

  if (Platform.OS === 'android') {
    // Check location service status    
    if (!isLocationEnabled) {
      // store.dispatch(setLocationServiceModal(true))
      // hidePopup();
      return false;
    }

    // No need permission check for android api version 23
    if (Platform.Version < 23) {
      return true;
    }
    
    // Check fine location permission
    const fineLocationStatus = await Permissions.check(Permissions.PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
    if (fineLocationStatus === Permissions.RESULTS.GRANTED) { return true; }

    const fineLocationRequest = await Permissions.request(Permissions.PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
    if (fineLocationRequest === Permissions.RESULTS.GRANTED) {
      return true;
    } else {
      store.dispatch(setLocationPermissionModal(true))
      hidePopup();
      return false;
    }
  } else if (Platform.OS === 'ios') {
    const locationWhenInUseStatus = await Permissions.check(Permissions.PERMISSIONS.IOS.LOCATION_WHEN_IN_USE);

    if (locationWhenInUseStatus === Permissions.RESULTS.GRANTED) {
      return true;
    }

    const locationWhenInUseRequest = await Permissions.request(Permissions.PERMISSIONS.IOS.LOCATION_WHEN_IN_USE);

    if (locationWhenInUseRequest === Permissions.RESULTS.GRANTED) {
      return true;
    } else {
      store.dispatch(setLocationPermissionModal(true))
      hidePopup();
      return false;
    }
  } else {
    return true;
  }
}

/** 
 * This function is used to fetch user current location.
 */
async function getCurrentLocation(showError = true) {
  return new Promise(async (resolve, reject) => {
    let watchId = null;
    let timeoutId = null;

    try {
      const checkPermissions = await hasPermissions();

      if (!checkPermissions) {
        resolve(null);
        return;
      }

      timeoutId = setTimeout(() => {
        watchId && Geolocation.clearWatch(watchId);
        showError && showErrorToast('strings.errorLocationTimeout');
        resolve(null);
      }, 25000);

      watchId = Geolocation.watchPosition(
        (position) => {
          watchId !== null && Geolocation.clearWatch(watchId);
          timeoutId && clearTimeout(timeoutId);
          resolve(position);
        },
        (error) => {
          watchId !== null && Geolocation.clearWatch(watchId);
          timeoutId && clearTimeout(timeoutId);
          showError && showErrorToast(error.message);
          resolve(null);
        },
        {
          accuracy: {
            android: 'high',
            ios: 'best',
          },
          enableHighAccuracy: true,
          distanceFilter: 0,
          interval: 900,
          fastestInterval: 500,
        }
      );

    } catch (error) {
      watchId !== null && Geolocation.clearWatch(watchId);
      showError && showErrorToast("Current Location Error: " + error.message);
      resolve(null);
    }
  });
}

const getLocation = async () => {
  return new Promise(async (resolve, reject) => {
    Geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        // console.log("Updated:", latitude, longitude);
        resolve(position);
      },
      (error) => {
        console.log(error);
        reject(error);
      },
      {
        enableHighAccuracy: true,
        timeout: 30000, 
        maximumAge: 0,
      }
    );
  })
};

const getDistanceFromCurrentLocation = (lat, long) => {
  console.log(lat);
  console.log(long);
  return new Promise(async (resolve, reject) => {
    Geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;

        // Calculate the distance to the destination
        const distanceToDestination = getDistance(
          { latitude, longitude },
          { latitude: lat, longitude: long }
        );
        console.log('(Lat:' + latitude + ', ' + 'Long:' + longitude + ')=' + distanceToDestination);
        resolve(distanceToDestination);
      },
      (error) => {
        console.error("Error fetching location: ", error);
        reject(error);
      },
      {
        enableHighAccuracy: true,
        timeout: 30000,
        maximumAge: 0
      }
    );
  });
}

/**
 * Starts the location tracking service by fetching the required settings
 * and saving them to the database. Stops the location service if it is
 * currently running, saves the user details and settings, and then
 * restarts the location service with the new settings. Throws an error
 * if the settings are invalid or if saving the settings fails.
 *
 * @returns {Promise<boolean>} - A promise that resolves to the status of the 
 * location service. Returns true if the service is running, false otherwise.
 *
 * @throws {Error} - Throws an error if settings are invalid or if saving 
 * settings fails.
 */

async function startTracking() {
  try {
    const user = store.getState()?.user?.data;

    const userId = user?.id;
    const baseURL = env.baseURL;
    const token = user?.token;
    const clockinDate = moment().format('YYYY-MM-DD');
    const locationFetchInterval = 5;
    const locationSubmitInterval = 3600;
    const locationMinUpdateDistance = 3;

    if (userId && baseURL && token && clockinDate && locationFetchInterval && locationSubmitInterval && locationMinUpdateDistance) {

      // Check background location permission
      const checkPermissions = await hasBackgroundPermission();
      if (!checkPermissions) {
        return false;
      }

      // Stop location service
      await new Promise(reslove => {
        LocationModule.stopLocationService()
        setTimeout(() => reslove(true), 1000)
      });

      // Save details for native module            
      const saveUserId = await database.setSetting(constants.settingsTable.USER_ID, String(userId))
      const saveBaseURL = await database.setSetting(constants.settingsTable.API_BASE_URL, String(baseURL))
      const saveToken = await database.setSetting(constants.settingsTable.API_AUTH_TOKEN, String(token))
      const saveClockinDate = await database.setSetting(constants.settingsTable.CLOCKIN_DATE, String(clockinDate));
      const saveFetchDelay = await database.setSetting(constants.settingsTable.LOCATION_FETCH_INTERVAL, String(locationFetchInterval));
      const savePostDelay = await database.setSetting(constants.settingsTable.LOCATION_SUBMIT_INTERVAL, String(locationSubmitInterval));
      const saveMinUpdateDistance = await database.setSetting(constants.settingsTable.LOCATION_MIN_UPDATE_DISTANCE, String(locationMinUpdateDistance));

      if (saveUserId && saveBaseURL && saveToken && saveClockinDate && saveFetchDelay && savePostDelay && saveMinUpdateDistance) {
        LocationModule.startLocationService();
        const status = await LocationModule.isRunning();
        console.log('Location service status - ', status);
        return status;
      } else {
        throw new Error("Failed to save settings.");
      }
    } {
      throw new Error("Invalid settings.");
    }
  } catch (error) {
    console.log("START_TRACKING_ERROR : ", error.message);
  }
  return false;
}


/**
 * Restarts location tracking service.
 *
 * @returns {Promise<boolean>} - A promise that resolves to the status of the
 * location service. Returns true if the service is running, false otherwise.
 */
async function restartTracking() {
  try {
    // Stop monitoring & location services
    await new Promise(reslove => {
      LocationModule.stopLocationService()
      setTimeout(() => {
        reslove(true)
      }, 1000)
    });

    LocationModule.startLocationService();
    const status = await LocationModule.isRunning();
    console.log('Location service restarted.');

    return status;
  } catch (error) {
    console.log("RESTART_TRACKING_ERROR : ", error.message);
  }
  return false;
}


/**
 * Stops the location tracking service.
 *
 * @returns {Promise<boolean>} - A promise that resolves to the status of the
 * location service. Returns true if the service is stopped, false otherwise.
 */
async function stopTracking() {
  LocationModule.stopLocationService();
  const isRunning = await LocationModule.isRunning();
  return !isRunning;
}

/**
 * Check location tracking status
 */
async function isRunning() {
  const isRunning = await LocationModule.isRunning();
  return isRunning;
}

/**
 * Open the Location Services settings screen in Android.
 */
function openServiceSettings() {
  LocationModule.openServiceSettings();
}

async function hasBackgroundPermission() {
  if (!(await hasPermissions())) {
    return false;
  }
  // Check permission for android <= 8
  if (Platform.OS === 'android' && Platform.Version <= 28) {
    return true;
  }
  const locationPermission = Platform.select({
    ios: PERMISSIONS.IOS.LOCATION_ALWAYS,
    android: PERMISSIONS.ANDROID.ACCESS_BACKGROUND_LOCATION,
  });
  const result = await check(locationPermission);
  if (result === RESULTS.GRANTED) {
    return true;
  } else {
    store.dispatch(setLocationPermissionModal(true));
    hidePopup();
    return false;
  }
};


const location = {
  hasPermissions,
  getLocation,
  getCurrentLocation,
  getDistanceFromCurrentLocation,
  hasBackgroundPermission,
  openServiceSettings,
  restartTracking,
  startTracking,
  stopTracking,
  isRunning
}

export default location;