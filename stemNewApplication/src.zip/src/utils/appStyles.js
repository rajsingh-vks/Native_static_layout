import {StyleSheet} from 'react-native';
import appColors from './appColors';

// VkStrap v1.0 ---> based on concept of Bootstrap 5
// Don't change anything here

const appStyles = StyleSheet.create({
  // -------------- Overflow -------------------
  overflowHidden: {overflow: 'hidden'},
  // -------------- Text Styles -------------------
  lineHeight: {lineHeight: 22},
  textCenter: {textAlign: 'center'},
  textEnd: {textAlign: 'right'},
  textCapitalize: {textTransform: 'capitalize'},
  textUppercase: {textTransform: 'uppercase'},
  textLowercase: {textTransform: 'lowercase'},
  textLineThrough: {textDecorationLine: 'line-through'},
  // -------------- Text Colors --------------------
  textPrimary: {color: appColors.dark400, fontFamily: 'Roboto-Regular'},
  textSecondary: {color: appColors.dark700, fontFamily: 'Roboto-Regular'},
  textSuccess: {color: appColors.green, fontFamily: 'Roboto-Regular'},
  textDanger: {color: appColors.red, fontFamily: 'Roboto-Regular'},

  // -------------- Background Colors --------------------
  bgWhite: {backgroundColor: 'white'},
  bgTheme: {backgroundColor: appColors.themeColor},

  // ------------- Text Inputs -------------
  textArea: {
    verticalAlign: 'top',
    paddingHorizontal: 10,
    borderRadius: 10,
    color: appColors.dark400,
    backgroundColor: '#fff',
    fontWeight: '500',
    height: '100%',
    flex: 1,
    fontSize:16
  },
  textInput: {
    height: 43,
    verticalAlign: 'middle',
    paddingHorizontal: 15,
    borderRadius: 5,
    borderColor: appColors.borderColor,
    borderWidth: 1,
    color: appColors.dark400,
    backgroundColor: '#fff',
    fontSize: 15,
    flex: 1,
  },
  // --------------- Margins ---------------
  m0: {margin: 0},
  m1: {margin: 3},
  m2: {margin: 8},
  m3: {margin: 13},
  m4: {margin: 18},
  m5: {margin: 23},

  mt1: {marginTop: 3},
  mt2: {marginTop: 8},
  mt3: {marginTop: 13},
  mt4: {marginTop: 18},
  mt5: {marginTop: 23},

  mb1: {marginBottom: 3},
  mb2: {marginBottom: 8},
  mb3: {marginBottom: 13},
  mb4: {marginBottom: 18},
  mb5: {marginBottom: 23},

  ms1: {marginStart: 3},
  ms2: {marginStart: 8},
  ms3: {marginStart: 13},
  ms4: {marginStart: 18},
  ms5: {marginStart: 23},

  me1: {marginRight: 3},
  me2: {marginRight: 8},
  me3: {marginRight: 13},
  me4: {marginRight: 18},
  me5: {marginRight: 23},

  mx1: {marginHorizontal: 3},
  mx2: {marginHorizontal: 8},
  mx3: {marginHorizontal: 13},
  mx4: {marginHorizontal: 18},
  mx5: {marginHorizontal: 23},

  my1: {marginVertical: 3},
  my2: {marginVertical: 8},
  my3: {marginVertical: 13},
  my4: {marginVertical: 18},
  my5: {marginVertical: 23},

  // --------------- Paddings ------------------
  p0: {padding: 0},
  p1: {padding: 3},
  p2: {padding: 8},
  p3: {padding: 13},
  p4: {padding: 18},
  p5: {padding: 23},

  py1: {paddingVertical: 3},
  py2: {paddingVertical: 8},
  py3: {paddingVertical: 13},
  py4: {paddingVertical: 18},
  py5: {paddingVertical: 23},

  px1: {paddingHorizontal: 3},
  px2: {paddingHorizontal: 8},
  px3: {paddingHorizontal: 13},
  px4: {paddingHorizontal: 18},
  px5: {paddingHorizontal: 23},

  ps1: {paddingLeft: 3},
  ps2: {paddingLeft: 8},
  ps3: {paddingLeft: 13},
  ps4: {paddingLeft: 18},
  ps5: {paddingLeft: 23},

  pe1: {paddingRight: 3},
  pe2: {paddingRight: 8},
  pe3: {paddingRight: 13},
  pe4: {paddingRight: 18},
  pe5: {paddingRight: 23},

  pb1: {paddingBottom: 3},
  pb2: {paddingBottom: 8},
  pb3: {paddingBottom: 13},
  pb4: {paddingBottom: 18},
  pb5: {paddingBottom: 23},

  pt1: {paddingTop: 3},
  pt2: {paddingTop: 8},
  pt3: {paddingTop: 13},
  pt4: {paddingTop: 18},
  pt5: {paddingTop: 23},

  // ---------------- Modal ---------------------
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
  },
  modalBottomContainer: {
    padding: 0,
    margin: 0,
    flexDirection: 'column',
    justifyContent: 'flex-end',
  },
  modalHeader: {
    paddingLeft: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  modalClose: {
    padding: 3,
    borderRadius: 50,
  },
  modalBox: {
    padding: 10,
    borderRadius: 15,
    minWidth: 200,
    minHeight: 100,
    backgroundColor: 'white',
  },
  modalBottomBox: {
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    width: '100%',
    backgroundColor: 'white',
  },
  modalTitle: {
    textAlign: 'center',
    fontSize: 16,
    color: appColors.dark400,
    fontWeight: 600,
    marginBottom: 10,    
  },

  // ----------------- Flex styles ------------------
  flexCenter: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  flex1: {
    flex: 1,
  },
  justifyContentCenter: {
    justifyContent: 'center',
  },
  justifyContentBetween: {
    justifyContent: 'space-between',
  },
  justifyContentAround: {
    justifyContent: 'space-around',
  },
  justifyContentEnd: {
    justifyContent: 'flex-end',
  },
  alignItemsCenter: {
    alignItems: 'center',
  },
  alignSelfCenter: {
    alignSelf: 'center',
  },

  // ------------------- Row & Columns -------------------
  row: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  col: {
    flexDirection: 'column',
    flexWrap: 'wrap',
  },

  // ---------------- Width -------------------------
  w10: {width: '10%'},
  w20: {width: '20%'},
  w30: {width: '30%'},
  w40: {width: '40%'},
  w50: {width: '50%'},
  w60: {width: '60%'},
  w70: {width: '70%'},
  w80: {width: '80%'},
  w90: {width: '90%'},
  w100: {width: '100%'},

  // ---------------- Width -------------------------
  h10: {height: '10%'},
  h20: {height: '20%'},
  h30: {height: '30%'},
  h40: {height: '40%'},
  h50: {height: '50%'},
  h60: {height: '60%'},
  h70: {height: '70%'},
  h80: {height: '80%'},
  h90: {height: '90%'},
  h100: {height: '100%'},

  // --------------- Font Size -----------------
  fs1: {fontSize: 10},
  fs2: {fontSize: 13},
  fs3: {fontSize: 16},
  fs4: {fontSize: 19},
  fs5: {fontSize: 22},
  fs6: {fontSize: 25},

  // ----------------- Font Family ------------------

  ff_Roboto_Thin: {fontFamily: 'Roboto-Thin'},
  ff_Roboto_Light: {fontFamily: 'Roboto-Light'},
  ff_Roboto_Regular: {fontFamily: 'Roboto-Regular'},
  ff_Roboto_Medium: {fontFamily: 'Roboto-Medium'},
  ff_Roboto_Bold: {fontFamily: 'Roboto-Bold'},

  ff_Poppins_Thin: {fontFamily: 'Poppins-Thin'},
  ff_Poppins_Light: {fontFamily: 'Poppins-Light'},
  ff_Poppins_Regular: {fontFamily: 'Poppins-Regular'},
  ff_Poppins_Medium: {fontFamily: 'Poppins-Medium'},
  ff_Poppins_Bold: {fontFamily: 'Poppins-Bold'},
  ff_Poppins_SemiBold: {fontFamily: 'Poppins-SemiBold'},

  ff_Nunito_Bold: {fontFamily: 'Nunito-Bold'},
  ff_Nunito_ExtraBold: {fontFamily: 'Nunito-ExtraBold'},
  ff_Nunito_Light: {fontFamily: 'Nunito-Light'},
  ff_Nunito_Medium: {fontFamily: 'Nunito-Medium'},
  ff_Nunito_Regular: {fontFamily: 'Nunito-Regular'},

  fw500: {fontWeight: '500'},
  fw600: {fontWeight: '600'},
  fw700: {fontWeight: '700'},
  fw900: {fontWeight: '900'},

  // ------------------ Border Radius ----------------
  rounded: {borderRadius: 6},
  rounded2: {borderRadius: 8},
  rounded3: {borderRadius: 10},
  rounded4: {borderRadius: 12},
  rounded5: {borderRadius: 14},
  rounded6: {borderRadius: 16},
  rounded7: {borderRadius: 18},

  roundedCircle: {borderRadius: 50},
  roundedTop: {
    borderTopStartRadius: 6,
    borderTopEndRadius: 6,
  },
  roundedBottom: {
    borderBottomLeftRadius: 6,
    borderBottomRightRadius: 6,
  },

  // ----------------- Buttons -----------------
  btn: {
    flexDirection: 'row',
    borderRadius: 5,
    color: 'white',
    backgroundColor: appColors.green,
    justifyContent: 'center',
    alignItems: 'center',
    height: 35,
    width: 90,
  },
  btnTxt: {
    textAlign: 'center',
    fontSize: 16,
    color: 'white',
  },

  // Shadow
  shadow1: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 2,
  },
  shadow2: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
  },

  // Opacity
  opacity0: {
    opacity: 0,
  },
  opacity30: {
    opacity: 0.3,
  },
  opacity50: {
    opacity: 0.5,
  },
  opacity100: {
    opacity: 1,
  },

  // borders
  borderColor: {borderColor: appColors.borderColor},
  border: {
    borderColor: appColors.borderColor,
    borderWidth: 1,
  },
  borderTop: {
    borderColor: appColors.borderColor,
    borderTopWidth: 1,
  },
  borderBottom: {
    borderColor: appColors.borderColor,
    borderBottomWidth: 1,
  },
  borderVertical: {
    borderColor: appColors.borderColor,
    borderTopWidth: 1,
    borderBottomWidth: 1,
  },
  borderHorizontal: {
    borderColor: appColors.borderColor,
    borderStartWidth: 1,
    borderLeftWidth: 1,
    borderEndWidth: 1,
    borderRightWidth: 1,
  },

  // Poisitions
  positionAbsolute: {
    position: 'absolute',
  },
  positionFixed: {
    position: 'fixed',
  },
  positionRelative: {
    position: 'relative',
  },
  overlaySheet: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    zIndex: 2,
  },
});

export default appStyles;
