const appColors = {
  // Theme colors
  themeColor: '#359c71',
  themeColorBg: '#f0fff4',
  themeColor600: 'rgba(53, 156, 113, 0.6)',
  themeColor300: 'rgba(53, 156, 113, 0.3)',
  themeColor200: 'rgba(53, 156, 113, 0.2)',
  themeColor100: 'rgba(53, 156, 113, 0.1)',
  themeColor50: 'rgba(161, 222, 248, 0.1)',
  
  themeBlueText: 'rgb(0, 26, 102)', //0, 26, 102
  // Ripple bg color
  rippleBgColor: 'rgba(53, 156, 113, 0.2)',

  // Light colors
  light: '#FFFFFF',
  grayScreen: '#f5f6f1',
  themeSuccess:"#5DB85C",
  themedanger:"#C9352C",

  // Black colors
  dark100: '#000000',
  dark200: '#171717',
  dark300: '#2E2E2E',
  dark400: '#454545',
  dark500: '#5C5C5C',
  dark600: '#737373',
  dark700: '#8A8A8A',

  
  placeholderColor: '#CDCDCD',
  borderColor: '#ccc',

  white: '#fff',
  info: '#00FFFF',
  lightgray: 'rgb(245, 246, 246)',
  gray: 'rgb(166, 168, 169)',
  lightgreen:'rgb(233, 250, 234)',
  green: 'rgb(13, 146, 22)',
  lightred: 'rgb(253, 234, 239)',
  red: 'rgb(255, 0, 0)', //'#cf4236',
  lightYellow: 'rgb(250, 245, 190)',
  yellow: 'rgb(189, 175, 11)',
  lightBlue: 'rgb(210, 234, 252)',
  blue: 'rgb(35, 96, 251)',
  lightOrange: 'rgb(252, 236, 204)',
  orange: 'rgb(255, 165, 0)',
  curDate: 'rgb(86, 139, 180)',

  mred: 'rgb(251, 112, 112)',
  morange: 'rgb(250, 187, 72)',
  mgreen: 'rgb(109, 192, 115)',
  
  blueHeader: 'rgba(8, 29, 110, 0.9)', //#081d6e'
  iconColor: 'rgba(37, 52, 99, 0.9)', //#001a66
  labelColor: 'rgba(37, 52, 99, 0.9)', //#001a66
  activeColor: 'rgba(8, 29, 110, 0.9)', //#001a66
};

export default appColors;
