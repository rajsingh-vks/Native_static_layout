
const Dropdown = {
  hour: Array.from({ length: 25 }, (_, i) => ({
    label: i.toString().padStart(2, '0'),
    value: i.toString().padStart(2, '0'),
  })),
  minute: Array.from({ length: 60 }, (_, i) => ({
    label: i.toString().padStart(2, '0'),
    value: i.toString().padStart(2, '0'),
  })),

  priorityItems: [
    { label: 'Low', value: 1 },
    { label: 'Medium', value: 2 },
    { label: 'High', value: 3 },
  ],

  remindList: [
    { label: '30 Minutes Before', value: 30 },
    { label: '1 Hour Before', value: 60 },
    { label: '2 Hours Before', value: 120 },
    { label: '4 Hours Before', value: 240 },
    { label: '8 Hours Before', value: 480 },
    { label: '1 Day Before', value: 1440 },
    { label: '2 Days Before', value: 2880 },
    { label: '4 Days Before', value: 5760 },
    { label: '8 Days Before', value: 11520 },
  ],
  reasonItems: [
    { label: 'Leave', value: 1 },
    { label: 'Sick', value: 2 },
    { label: 'Vacation', value: 3 },
    { label: 'Other', value: 4 },
  ],
  leaveItems: [
    { label: 'Paid', value: 1 },
    { label: 'Unpaid', value: 2 },
    ],

};

export default Dropdown;
