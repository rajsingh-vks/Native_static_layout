import { NativeModules } from "react-native"
const { DatabaseModule } = NativeModules;

const refreshTables = async () => {
    return await DatabaseModule.refreshTables();
}

const setSetting = async (name, value) => {
    return await DatabaseModule.setSetting(name, value)
}

const getSetting = async (name) => {
    return await DatabaseModule.getSetting(name)
}


export default database = {
    refreshTables,
    setSetting,
    getSetting,
}