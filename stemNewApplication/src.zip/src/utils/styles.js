import {Dimensions, StyleSheet} from 'react-native';
import appStyles from './appStyles';
import appColors from './appColors';
const {width, height} = Dimensions.get('window');

const styles = StyleSheet.create({
  // Common
  // Container
  container: {
    flex:1, 
    justifyContent: 'flex-start',
    paddingHorizontal:15, 
    paddingTop:20
  },
  sectionHeader: {
    color:'#001a66',
    fontSize:17, 
    fontWeight:'700', 
  },
  section: {
    backgroundColor: appColors.white,
    borderRadius: 6,
    marginVertical:10,
    padding: 15,
    paddingHorizontal:10, 
    width:'100%',
  },
  btnContainer: {
    justifyContent:'center',
    height: 50, 
    marginHorizontal:15,
    bottom: 20, // Distance from the bottom edge
    marginTop:10,
  },
  content: {
    flexGrow: 1,
    alignItems: 'center',
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 16,
  },

  defaultBg: {
    backgroundColor: appColors.blueHeader
  },
  
  overlayLayout: {
    width: width,
    height: height,
  },
  activityWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
    height: height,
    backgroundColor: 'rgba(75, 112, 141, 0.3)',
  },
  loaderIcon: {
    height: 160,
    width: 160,
  },

  disabledBtn: {
    flex: 1,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: appColors.gray,
  },

  noRecordsContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 50,
  },
  noRecordsImage: {
    width: 100,
    height: 100,
    resizeMode: 'contain',
  },
  noRecordsText: {
    marginTop: 10,
    fontSize: 16,
    color: '#A6A8A9',
  },

  roundedGrey: {
    backgroundColor: appColors.lightgray,
    borderRadius:15,
    padding:5
  }, 
  roundedBlue: {
    width: 5,
    height: 5,
    backgroundColor: appColors.blueHeader,
    borderRadius:15,
    padding:4,
    marginTop: 6,
    marginHorizontal: 5
  }, 
  greenDot: {
    position: 'absolute',
    height: 15,
    width: 15,
    right: 0,
    bottom: 0,
    backgroundColor:appColors.green,
    borderColor: appColors.white,
    borderWidth: 2,
    borderRadius: '50%'
  }, 
  greenTag: {
    backgroundColor:appColors.lightgreen, 
    borderRadius:5, 
    color:'green', 
    // fontWeight:'700',
    paddingHorizontal:10, 
    paddingVertical:3, 
  },
  redTag: {
    backgroundColor:appColors.lightred, 
    borderRadius:5, 
    color:'red', 
    // fontWeight:'900',
    paddingHorizontal:10, 
    paddingVertical:3, 
  },
  yellowTag: {
    backgroundColor:appColors.lightYellow, 
    borderRadius:5, 
    color:'red', 
    fontWeight:'900',
    paddingHorizontal:10, 
    paddingVertical:3, 
  },




  // OnBoarding
  OnboardingContainer: {
    flex: 1,
  },
  OnboardingContainerImage: {
    flex: 1,
  },
  OnBoardingSlideContainer: {
    alignItems: 'center'
  },
  OnBoardingImage: {
    height: '75%',
    width,
    resizeMode: 'contain'
  },
  OnBoardingtitle: {
    color: appColors.white,
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 20,
    maxWidth: '90%',
    textAlign: 'center',
    lineHeight: 32,
  },
  OnBoardingsubtitle: {
    color: appColors.white,
    fontSize: 14,
    marginTop: 20,
    maxWidth: '90%',
    textAlign: 'center',
    lineHeight: 20,
  },
  indicator: {
    height: 2.5,
    width: 10,
    backgroundColor: 'grey',
    marginHorizontal: 3,
    borderRadius: 2,
  },
  OnBoardingfooter: {
    height: height * 0.15,
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },
  IndicatorWrapper: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  OnBoardingbtn: {
    flex: 1,
    height: 50,
    borderRadius: 5,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  OnBoardingbtntext: {
    fontWeight: 'bold',
    fontSize: 15
  },
  // OnBoarding

  // Login
  authContainer: {
    flex: 1,
    padding: 15,
    backgroundColor: appColors.white
  },
  authImageWrapper: {
    height: '35%',
    alignItems: 'center'
  },
  authImage: {
    height: '100%',
    resizeMode: 'contain'
  },
  auth: {
    marginTop: 20
  },
  authTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    lineHeight: 32,
    color: appColors.themeBlueText
  },
  authsubtitle: {
    fontSize: 15,
    marginTop: 10,
  },
  radioWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginVertical: 10
  },
  radio: {
    height: 20,
    width: 20,
    borderColor: appColors.dark100,
    borderWidth: 2,
    borderRadius: 20,
    margin: 10
  },
  radioBg: {
    backgroundColor: appColors.themeBlueText,
    height: 10,
    width: 10,
    borderRadius: 30,
    margin: 3,
  },
  label: {
    color: appColors.labelColor,
    fontSize: 16,
    fontWeight: 'bold',
    color: appColors.themeBlueText,
    textAlign: 'left',
    marginVertical: 5
  },
  inputwrapper: {
    height: 50,
    // borderColor: appColors.gray,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 8,
  },
  inputArea: {
    flex: 1,
    borderColor: 'rgba(166, 168, 169, 0.1)',
    paddingHorizontal: 10,
    color: appColors.dark400,
    fontSize:16,
  },
  textareaLarge: {
    height: 100, 
    borderColor: appColors.gray,
    borderWidth: 1,
    padding: 15,
    borderRadius: 10,
    textAlignVertical: "top",
  },
  Authbtn: {
    flex: 1,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: appColors.activeColor,
    // marginHorizontal:5,
  },
  greenbtn: {
    flex: 1,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: appColors.themeSuccess,
  },
  redbtn: {
    flex: 1,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: appColors.themedanger,
  },
  Authbtntext: {
    color: appColors.white,
    fontWeight: 'bold',
    fontSize: 16
  },

  authBottom: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'center',
    marginVertical: '15'
  },
  // Login

  // DrawerLayout
  drawerLayout: {
    backgroundColor: appColors.white,
    position: 'relative'
  },
  drawerHeader: {
    borderBottomColor: '#eee',
    borderBottomWidth: 1,
    paddingBottom: 25
  },
  drawerClose: {
    position: 'absolute',
    right: 0,
    zIndex: 1
  },
  drawerNavigation: {
    paddingVertical: 15
  },
  navigation: {
    flexDirection: 'row',
    flex: 1
  },
  // DrawerLayout

  // Header
  header: {
    backgroundColor:appColors.blueHeader,
    flexDirection: 'row',
    paddingHorizontal: 10,
    paddingVertical: 10
  },
  drawerTouch: {
    // backgroundColor: '#2c3f83',
    width: 40,
    height: 40,
    borderRadius: 6,
  },
  drawerIcon: {
    color: appColors.white,
    fontSize: 23,
    textAlign: 'center',
    margin: 'auto',
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: 5,
  },
  headerTitle: {
    fontSize: 17,
    color: appColors.white,
  },
  headerSubTitle: {
    fontSize: 11,
    color: appColors.gray
  },
  headerRight: {
    flexDirection: 'row'
  },
  // Header

  // Dashboard
  dashboard: {
    flex: 1,
    backgroundColor: appColors.grayScreen,
    // borderTopLeftRadius: 10,
    // borderTopRightRadius: 10,
    paddingHorizontal: 5,
    paddingVertical: 15
  },
  dashboardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginHorizontal: 10,
  },
  dashboardSubTitle: {
    color: appColors.gray,
    fontSize: 16,
    fontWeight: 'bold',
    marginHorizontal: 10,
    marginTop: 15,
    marginBottom: 5
  },
  // New Dashboard Layout 
  imgAndTxt: {
    width: 65,
    height: 65,
    borderRadius: 50
  },
  userDetails: {
    flex: 1,
    justifyContent: 'center',
    marginLeft: 12,
  },
  userDetailsTitle: {
    fontSize: 18,
    fontWeight: '500',
  },
  fingerPrint: {
    alignItems: 'center',
    backgroundColor: 'rgba(36, 128, 195, 0.35)',
    borderRadius: 50,
    padding: 10,
    borderColor: 'rgba(36, 128, 195, 0.15)',
    borderWidth: 5,
  },
  fingerPrint2: {
    alignItems: 'center',
    backgroundColor: '#ea4335db',
    borderRadius: 50,
    padding: 10,
    borderColor: '#ea433545',
    borderWidth: 5,
  },
  checkinoutcard: {
    flex: 1,
    margin: 10,
    borderRadius: 10,
    padding: 15,
    // backgroundColor: '#EAF3FF', 
    // borderColor: '#3478F6', 
    // borderWidth: 1, 
    flexDirection: 'row'
  },
  tbodyBold: {
    fontWeight: 'bold',
    fontSize: 15,
    color: '#585a61',
  },
  timerBackground: {
    // backgroundColor: appColors.curDate,
    backgroundColor: appColors.placeholderColor,
    paddingVertical: 5,
    paddingHorizontal: 7,
    borderRadius: 4,
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
    margin: 1, alignSelf:'center'
  },
  // New Dashboard Layout 
  cardWrapper: {
    flexDirection: 'row'
  },
  cardFirst: {
    borderRadius: 10,
  },
  card: {
    flex: 1,
    margin: 10,
    borderRadius: 10,
    backgroundColor: appColors.red,
    height: 110,
    padding: 15,
    position: 'relative'
  },
  iconCircle: {
    backgroundColor: appColors.white,
    borderRadius: '50%',
    width: 50,
    height: 50,
    justifyContent:'center',
    alignItems:'center'
  },
  iconCard: {
    textAlign: 'center',
    flex: 1,
    verticalAlign: 'middle',
  },
  cardTitle: {
    fontWeight: 'bold',
    fontSize: 16,
    marginTop: 10
  },
  absoluteLeftLine: {
    borderTopRightRadius: 10,
    borderBottomRightRadius: 10,
    height: '60%', 
    justifyContent: 'center',
    position: 'absolute',
    left: '0', 
    top: '30%',
    width: 4,
  },
  absoluteLine: {
    position: 'absolute',
    right: '0%',
    top: '15',
    justifyContent: 'center',
    width: 4,
    height: '100%',
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10
  },
  horizontalLine: {
    backgroundColor: appColors.lightgray,
    justifyContent: 'center',
    width: '100%',
    height: 2,
    marginVertical: 5
  },
  subCard: {
    flexDirection: 'row',
    height: 'auto'
  },
  subCartTitle: {
    marginLeft: 20,
    fontSize: 20
  },
  adminCardWrapper: {
    backgroundColor: appColors.white,
    borderRadius: 10,
    margin: 10,
  },
  notification: {
    flexDirection: 'row',
    padding: 15
  },
  notificationBanner: {
    marginTop: 15,
    height: 200,
    width: '100%'
  },
  // Dashboard

  // Profile
  profileDashboard: {
    // marginTop: 60,
    backgroundColor: appColors.grayScreen,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    paddingHorizontal: 5,
    paddingVertical: 15,
    // position: 'relative',
    // height: '100%',
  },
  profilePicture: {
    position: 'absolute',
    top: -40,
    zIndex: 1,
    borderRadius: 40,
    alignSelf: 'center',
    backgroundColor: appColors.white,
    width: 80,
    height: 80
  },
  profileTitle: {
    textAlign: 'center',
    marginTop: 40,
    fontWeight: '600',
    fontSize: 16
  },
  profilePictureIcon: {
    fontSize: 45,
    textAlign: 'center',
    margin: 'auto',
    color: appColors.dark700,
  },
  profileDetails: {
    flex: 1,
  },
  profileDetailTitle: {
    color: appColors.activeColor,
    fontSize: 14,
    fontWeight: 'bold'
  },
  profileDetailSubTitle: {
    fontSize: 14,
    color: appColors.dark500,
    fontWeight: 'bold'
  },

  card_template:{
    width: '90%',
    borderRadius: 6,
    boxShadow: "1px 1px 10px 0px rgba(0,0,0,0.15)",
    margin: 'auto',
    marginTop: 25,
    backgroundColor: appColors.white,
    padding: 15,
  },
  card_title: {
    color: appColors.blue,
    fontWeight: 'bold'
  },
  profileInputWrapper: {
    flexDirection: 'row',
    borderBottomColor: '#bfc8e5',
    paddingTop: 15,
    paddingBottom: 5
  },
  iconWrapper: {
    backgroundColor: 'rgba(37, 52, 99, 0.1)',//'#e2e8ff',
    width: 35,
    height: 35,
    borderRadius: 30,
  },
  personalInfoIcon: {
    fontSize: 20,
    color: appColors.blue,
    margin: 'auto',
    textAlign: 'center'
  },
  
  cardSubtitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#b3b3b3',
    marginTop: 5,
  },
  // profile
  inputField: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    marginVertical: 8,
    backgroundColor: '#fff',
  },

  // Company
  companyRow: {
    flexDirection: 'row',
    marginBottom: 5,
    width: '100%',
  },
  companyName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1E3A8A',
  },
  companyEmail: {
    fontSize: 14,
    color: '#555',
  },
  companyAddress: {
    fontSize: 12,
    color: '#777',
  },
  companyDetails: {
    flex: 1,
  },
  companyTab: {
    backgroundColor: appColors.white,
    flexDirection:'column', 
    justifyContent:'center',
    borderRadius: 6,
    color: '#353439',
    fontSize: 18,
    padding: 15,
    marginTop:0, 
    width:'100%', 
  },
  companyHeader: {
    justifyContent:'center', 
    alignItems:'center', 
    marginBottom:15
  },
  companyLogo: {
    fontSize:60, 
    color:'#2E2E2E',
    margin: 'auto',
    textAlign: 'center',
  },
  companyDetailName: {
    color:'#2E2E2E', 
    fontSize:20,
    fontWeight: 'bold',
    margin: 'auto',
    textAlign: 'center',
  },
  companyTitle: {
    fontSize: 15,
    fontWeight: '500',
    color: '#9a999e'
  },
  companyWrapper: {
    flexDirection: 'row',
    borderBottomColor: '#bfc8e5',
    paddingVertical:10,
    justifyContent:'center'
  },
  companyInfoIcon: {
    fontSize: 20,
    color: '#2E2E2E',
    margin: 'auto',
    textAlign: 'center'
  },
  companyInfoDetails: {
    flex:1, 
  },
  companyTabTitle: {
    flex: 1,
    color: '#39383d',
    // color: appColors.themeBlueText,
    fontSize: 16,
    fontWeight: '500',
    marginLeft: 15
  },
  badgeGreen: {
    backgroundColor: '#28A745',
    borderRadius: 5,
    paddingHorizontal: 10,
    paddingVertical: 2,
    // alignSelf: 'flex-end',
    // marginTop: 5,
  },
  badgeText: {
    fontSize: 10,
    // fontWeight: 'bold',
    color: '#fff',
  },
  selectButton: {
    backgroundColor: '#1E90FF',
    paddingVertical: 4,
    paddingHorizontal: 12,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  leaveButton: {
    backgroundColor: '#FF6B6B',
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 4,
    alignSelf: 'flex-end',
  },
  selectButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 4,
    alignSelf: 'flex-end',
  },
  leavebuttonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },

  // Post
  postDashboard: {
    paddingHorizontal: 15,
  },
  postWrapper: {
    backgroundColor: appColors.white,
    boxShadow: "1px 1px 10px 0px rgba(0,0,0,0.15)",
    borderRadius: 6,
    flexDirection: 'row',
    padding: 5,
    marginBottom: 15,
  },
  postIconWrapper: {
    backgroundColor: '#e2e8ff',
    width: 100,
    height: 100,
    borderRadius: 6,
  },
  postIcon: {
    fontSize: 70,
    color: '#235ffb',
    margin: 'auto',
    textAlign: 'center'
  },
  postDetail: {
    flex: 1,
    paddingHorizontal: 15
  },
  postTitle: {
    color: appColors.dark100,
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    marginTop: 10
  },
  postSubTitle: {
    color: appColors.gray,
    fontSize: 13,
    fontWeight: '400',
    borderBottomColor: '#235ffb',
    borderBottomWidth: 1,
    paddingBottom: 10
  },
  mapMaker: {
    color: '#235ffb',
    fontSize: 13,
    fontWeight: '400'
  },
  viewDetails: {
    color: '#235ffb',
    fontSize: 13,
    fontWeight: '500',
    marginTop: 5
  },

  // Join Company
  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 24,
  },
  inputBox: {
    width: 48,
    height: 48,
    marginHorizontal: 4,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    textAlign: 'center',
    fontSize: 18,
    backgroundColor: '#FFF',
    color: '#333',
  },
  submitButton: {
    position: 'absolute',
    bottom: 16,
    left: 16,
    right: 16,
    backgroundColor: '#333',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  submitText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },

  // Setting
  settingContainer: {
    padding: 16
  },
  settingTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#9a999e'
  },
  settingTab: {
    backgroundColor: appColors.white,
    flexDirection: 'row',
    padding: 15,
    marginTop: 6,
    borderRadius: 6,
    color: '#353439',
    fontSize: 18
  },
  primaryIcon: {
    // color: '#39383d',
    // color: appColors.themeBlueText,
    color: 'rgb(45, 61, 108)',
  },
  settingTabTitle: {
    fontSize: 16,
    // color: '#39383d',
    color: appColors.themeBlueText,
    fontWeight: '500',
    flex: 1,
    marginTop: 4,
    marginLeft: 15
  },
  secondaryIcon: {
    color: appColors.gray,
    margin: 'auto'
  },

  // Schedule
  shiftCalendar: {
    borderWidth: 1,
    borderRadius:10,
    borderColor: 'rgb(237, 238, 240)',
  },
  shiftTab: { 
    flexDirection: 'row',
    backgroundColor: appColors.white,
    borderWidth:1,
    borderColor:'rgb(215, 217, 219)',
    borderRadius:10, 
    color: '#353439',
    fontSize: 18,
    marginVertical:5,
    paddingHorizontal: 15,
    paddingVertical:10
  },
  shiftDataRow: {
    borderBottomWidth:1, 
    borderBottomColor:appColors.lightgray,
    flexDirection: 'row',
    justifyContent:'space-between', 
    // marginBottom: 5,
    paddingVertical:10,
    width: '100%',
  },

  // Cards
  cardTab: {
    backgroundColor: appColors.white,
    borderRadius: 6,
    color: '#353439',
    flexDirection: 'row',
    fontSize: 18,
    paddingHorizontal: 15,
    paddingVertical:10,
    marginTop: 5,
  },
  tabDetails: {
    flex: 1,
  },
  tabViewDetails: {
    color:appColors.dark500, 
    fontSize: 14, 
    fontWeight:'400', 
    marginRight:5
  },
  tabHeader: {
    flexDirection:'row', 
    justifyContent: 'space-between'
  },
  tabHeaderTitle: {
    color:'#000e42',
    fontSize: 18, 
    fontWeight:'500',
    padding:5, 
  },
  tabStatus: {
    borderRadius:5,
    padding:8, 
    paddingHorizontal:8, 
  },
  tabIconCircle: {
    alignItems:'center',
    backgroundColor: appColors.white,
    borderRadius: '50%',
    height: 35,
    justifyContent:'center',
    width: 35,
  },
  tabIconLabel: {
    color:'#4d4d4d',
    fontSize: 16, 
    marginLeft: 5, 
  },
  tabIconTitle: {
    fontSize: 14, 
    fontWeight:'500',
    marginTop: 0, 
    marginLeft: 5,
  },
  ackStatus: {
    borderRadius:0,
    padding:5,
    justifyContent:'center',
    paddingHorizontal:8, 
  },
  ackStatusText: {
    fontSize:16,
    color:'#FFF',
  },

  iconPlus: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    backgroundColor: '#4285F4', // Gmail's blue color
    width: 45,
    height: 45,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2, // Shadow effect
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
  },
  // Shift Bottom Modal //
  shiftModal: {
    justifyContent: "flex-end",
    margin: 0,
    position: 'relative'
  },
  shiftModalContent: {
    backgroundColor: appColors.light,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    alignItems: "left",
    padding: 25
  },
  shiftModalText: {
    fontSize: 20,
    fontWeight: 600,
    marginBottom: 20,
    color: '#000E42'
  },
  modalButton: {
    position: 'absolute',
    right: 10,
    top: 10,
    borderColor: "#2360FB",
    borderWidth: 3,
    borderRadius: 30,
    padding: 2
  },
  // Shift Bottom Modal //

  // Chat Box //
  chatContainer: {
    flex: 1,
    backgroundColor: "#f0f0f0",
  },
  chatContainerWrapper: {
    flexGrow: 1,
    paddingTop:20,
    paddingHorizontal: 15
  },
  message: {
    maxWidth: "75%",
    padding: 15,
    marginVertical: 10,
    borderRadius: 10,
    borderTopLeftRadius: 0
  },
  myMessage: {
    alignSelf: "flex-end",
    backgroundColor: "#E4ECFF", // Light Blue
    borderTopLeftRadius: 10,
    borderTopRightRadius: 0
  },
  timeText: {
    fontSize: 12,
    color: "#555",
    alignSelf: "flex-end",
    marginTop: 5,
  },
  otherMessage: {
    alignSelf: "flex-start",
    backgroundColor: "white",
  },
  messageText: {
    fontSize: 16,
  },
  chatinputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "white",
    borderTopWidth: 1,
    borderColor: "#ddd",
  },
  chatInput: {
    flex: 1,
    height: 70,
    paddingHorizontal: 20,
    fontSize: 16
  },
  sendBtn: {
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: "#2360FB",
    height: 70,
    paddingHorizontal: 20
  },
  // Chat Box //
});

export default styles;
