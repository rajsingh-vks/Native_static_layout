import { Text, StyleSheet } from 'react-native';
import moment from "moment-timezone";

import store from '../redux/store';
import { setPopupModal, setProgressBar, setSpinner,} from '../redux/appSlice';
import { setRefresh } from '../redux/refreshSlice';
import env from '../services/env';
import appColors from './appColors';

// Refresh
const refresh = component_name => {
  store.dispatch(setRefresh(component_name));
};

// Show Overlay Screen Loading
const showLoading = (visible = false) => {
  store.dispatch(setSpinner(visible));
};

// Show error toast
const showErrorToast = (message = '') => {
  store.dispatch(
    setPopupModal({ visible: true, message: message, type: 'error' }),
  );
};

// Show success toast
const showSuccessToast = (message = '', navigate = false) => {
  store.dispatch(
    setPopupModal({ visible: true, message: message, type: 'success', navigate: navigate }),
  );
};

// Show & Hide Popup Modal
const showPopup = (type = 'success', message = '') => {
  store.dispatch(setPopupModal({ visible: true, message: message, type: type }));
};

const hidePopup = () => {
  store.dispatch(setPopupModal({ visible: false, message: '', type: '' }));
  store.dispatch(setProgressBar({ visible: false, completed: 0 }));
};

// Check user's settings & permissions
// const checkUserSettings = async setting_name => {
//   return await user
//     .getUserSettings()
//     .then(res => {
//       if (
//         res?.success &&
//         res?.data &&
//         parseInt(res?.data[setting_name] || 0) === 1
//       ) {
//         return true;
//       } else {
//         return false;
//       }
//     })
//     .catch(function (error) {
//       return false;
//     });
// };

// const getUserSettings = async params => {
//   try {
//     const res = await user.getUserSettings(params);
//     return res;
//   } catch (error) {
//     showErrorToast(strings.errorNetwork)
//   }
// };

const modalProps = {
  zoom: {
    animationIn: 'zoomIn',
    animationOut: 'zoomOut',
    useNativeDriverForBackdrop: true,
  },
};

const scrollViewProps = {
  vertical: true,
  showsHorizontalScrollIndicator: false,
};

export {
  refresh,
  showLoading,
  showErrorToast,
  showSuccessToast,
  showPopup,
  hidePopup,
  modalProps,
};


// Cut a paragraph/string on given lenth
const maxChar = (string_value, max_length, postfix = '...') => {
  if (string_value.length > max_length) {
    return `${string_value.slice(0, max_length)}${postfix}`;
  }
  return string_value;
};

// Get color code according to status
const getStatusColor = (status = '') => {
  switch (status.toLowerCase()) {
    case 1:
      return appColors.orange;
      break;
    case 2:
      return appColors.green;
      break;
    case 3:
      return appColors.red;
      break;

    default:
      return appColors.gray;
      break;
  }
};

// Function to generate a color based on the user's name
const generateColorByName = name => {
  // Define a list of colors
  const colors = [
    '#D32F2F',
    '#C2185B',
    '#7B1FA2',
    '#512DA8',
    '#303F9F',
    '#1976D2',
    '#0288D1',
    '#0097A7',
    '#00796B',
    '#388E3C',
    '#689F38',
    '#AFB42B',
    '#FBC02D',
    '#FFA000',
    '#F57C00',
    '#E64A19',
  ];

  // Calculate a color index based on the ASCII values of the characters in the name
  const nameASCII = name
    .split('')
    .map(char => char.charCodeAt(0))
    .reduce((sum, value) => sum + value, 0);

  // Use the calculated index to get a color from the list
  const colorIndex = nameASCII % colors.length;

  return colors[colorIndex];
};

const extractFileNameFromPath = path => {
  const parts = path.split('/');
  return parts[parts.length - 1];
};

export const createFileObjectFromPath = filePath => {
  const fileName = extractFileNameFromPath(filePath);
  const uri = filePath.startsWith('file://') ? filePath : 'file://' + filePath;
  return {
    uri,
    name: fileName,
    fileName: fileName,
    type: 'image/jpeg',
  };
};

// create image url by db image path
const getImageURL = (image_path = null) => {
  return image_path ? env.baseURL + '/' + image_path : null;
};

const isImageFile = filePath => {
  try {
    const fileExtension = filePath.split('.').pop().toLowerCase();
    const imageExtensions = ['jpg', 'jpeg', 'png'];
    return imageExtensions.includes(fileExtension);
  } catch {
    return false;
  }
};

const pathJoin = (...parts) => {
  return parts.join('/').replace(/\/+/g, '/');
};

const apiPath = (path = null) => {
  return store.getState()?.user?.data?.url + pathJoin(path);
};

const getMimeTypeByExtension = extension => {
  const mimeTypes = {
    txt: 'text/plain',
    html: 'text/html',
    css: 'text/css',
    js: 'application/javascript',
    json: 'application/json',
    xml: 'application/xml',
    pdf: 'application/pdf',
    doc: 'application/msword',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xls: 'application/vnd.ms-excel',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ppt: 'application/vnd.ms-powerpoint',
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    png: 'image/png',
    jpg: 'image/jpeg',
    jpeg: 'image/jpeg',
    gif: 'image/gif',
    bmp: 'image/bmp',
    tiff: 'image/tiff',
    svg: 'image/svg+xml',
    mp3: 'audio/mpeg',
    mp4: 'video/mp4',
    zip: 'application/zip',
    rar: 'application/x-rar-compressed',
  };

  // Check if the provided extension is in the mimeTypes dictionary
  if (mimeTypes.hasOwnProperty(extension)) {
    return mimeTypes[extension];
  }

  // If the extension is not found in the dictionary, return a default MIME type
  return 'application/octet-stream'; // Default binary MIME type
};

const getMimeTypeFromFilePath = filePath => {
  const fileExtension = filePath.split('.').pop().toLowerCase();
  const mimeType = getMimeTypeByExtension(fileExtension);
  return mimeType;
};

export const formatTime = (time) => {
  if (!time) return '00:00'; 
  return time.replace(/:00$/, ''); 
};


/* Common Helper functions for App */
export const convertUTCToLocal = (utcDate, format = "MM/DD/YYYY HH:mm", tzone = true) => {
  if (!utcDate) return "";

  const timezone = moment.tz.guess();
  const timezoneAbbreviation = moment.tz(timezone).zoneAbbr();

  if(tzone){
    return `${moment.utc(utcDate).local().format(format)} (${timezoneAbbreviation})`;
  }else{
    return `${moment.utc(utcDate).local().format(format)}`;
  }
};

export const PriorityStatus = (priority) => {
  switch (priority) {
    case "1":
      return <Text style={styles.low}>LOW</Text>;
    case "2":
      return <Text style={styles.medium}>MEDIUM</Text>;
    case "3":
      return <Text style={styles.high}>HIGH</Text>;
    default:
      return null; 
  }
};

export const CheckListStatus = (Status) => {
  
  switch (Status) {
    case "Completed":
      return <Text style={styles.low}>COMPLETED</Text>;
    case "Pending":
      return <Text style={styles.medium}>PENDING</Text>;
    
    default:
      return null;
  }
};


export const TagStatus = (tagId) => {
  
  switch (tagId) {
    case 1:
      return <Text style={styles.low}>QR_TAGS</Text>;
    case 2:
      return <Text style={styles.low}>NFC_TAGS</Text>;
      case 3:
        return <Text style={styles.low}>VIRTUAL_TAGS</Text>;
    
    default:
      return null;
  }
};

export const WeekDayNameString = (day) => {
  switch (day) {
    case "0":
      return "MON";
    case "1":
      return "TUE";
    case "2":
      return "WED";
    case "3":
      return "THU";
    case "4":
      return "FRI";
    case "5":
      return "SAT";
    case "6":
      return "SUN";
    default:
      return "Invalid day";
  }
};

export const WeekDayName = (day) => {
  switch (day) {
    case "0":
      return <Text style={styles.monday}>MON</Text>;
    case "1":
      return <Text style={styles.tuesday}>TUE</Text>;
    case "2":
      return <Text style={styles.wednesday}>WED</Text>;
    case "3":
      return <Text style={styles.thursday}>THU</Text>;
    case "4":
      return <Text style={styles.friday}>FRI</Text>;
    case "5":
      return <Text style={styles.saturday}>SAT</Text>;
    case "6":
      return <Text style={styles.sunday}>SUN</Text>;
    default:
      return null;
  }
};

export const WeekDaysNames = (scheduleDays) => {
  const daysArray = scheduleDays?.split(","); 
  const dayNames = daysArray?.map((day) => WeekDayNameString(day)); 
  return dayNames?.join(" | "); 
};


export const reminderStatus = (status) => {
  switch (status) {
    case "P":
      return <Text style={styles.medium}>PENDING</Text>;
      break;
    
      default:
      return <Text style={styles.low}>APPROVED</Text>;
  }
};

export const passwordStrength = (password) => {
  let strength = 0;
  const passwordRules = [
    { label: "At least 8 characters", regex: /.{8,}/ },
    { label: "At least one uppercase letter", regex: /[A-Z]/ },
    { label: "At least one lowercase letter", regex: /[a-z]/ },
    { label: "At least one number", regex: /\d/ },
    { label: "At least one special character (@$!%*?&)", regex: /[@$!%*?&]/ },
  ];

  const met = passwordRules.filter((rule) => rule.regex.test(password));

  strength = met.length / passwordRules.length

  return strength;
}


// export const formatTime = (time) => {
//   if (!time) return '00:00'; 
//   const date = new Date(`1970-01-01T${time}:00Z`);
//   return date.toISOString().substr(11, 5);
// };


const styles = StyleSheet.create({
  low: {
    color: 'green', 
    fontWeight: 'bold',
  },
  medium: {
    color: 'orange', 
    fontWeight: 'bold',
  },
  high: {
    color: 'red', 
    fontWeight: 'bold',
  },
});