import {createSlice} from '@reduxjs/toolkit';

export const logoutSlice = createSlice({
  name: 'logout',
  initialState: {
    logout: false,
  },
  reducers: {
    setLogout: (state, action) => {
      state.logout = action.payload;
    },
  },
});

export const {setLogout} = logoutSlice.actions;

export const getLogout = (state) => {
  return state.logout?.logout;
}

export default logoutSlice.reducer;
