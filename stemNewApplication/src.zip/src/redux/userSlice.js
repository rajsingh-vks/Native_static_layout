import AsyncStorage from '@react-native-async-storage/async-storage';
import {createSlice} from '@reduxjs/toolkit';
import constants from '../utils/constants';

export const userSlice = createSlice({
  name: 'user',
  initialState: {
    data:{}
  },
  reducers: {
    setUser: (state, action) => {
      state.data = {...state.data,...action.payload};
      AsyncStorage.setItem(constants.storageKeys.USER, JSON.stringify(state.data));
    },
    updateCompanyId: (state, action) => {
      if (state.data) {
        state.data.company_id = action.payload; // Update only the company_id
      }
    },
    removeUser: state => {
      AsyncStorage.removeItem('user')
      state.data = {};
    },
  },
});

export const {setUser, removeUser,updateCompanyId} = userSlice.actions;

// Get User data from redux store
export const getUser = (state) => {
  return state.user?.data
}

export default userSlice.reducer;
