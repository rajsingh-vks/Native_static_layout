import { configureStore } from '@reduxjs/toolkit';
import userReducer from './userSlice';
import appReducer from './appSlice';
import refreshReducer from './refreshSlice';
import logoutReducer from './logoutSlice';
import companyReducer from './companySlice'
import modalReducer from './modalSlice';
// import modalReducer from './modalSlice';
// import dashboardReducer from './dashboardSlice';
// import permissionsReducer from './permissionsSlice';

export default configureStore({
  reducer: {
    user: userReducer,
    app: appReducer,
    refresh: refreshReducer,
    logout: logoutReducer,
    company: companyReducer,
    modal: modalReducer,
    // dashboard: dashboardReducer,
    // permissions: permissionsReducer,
  },
});
