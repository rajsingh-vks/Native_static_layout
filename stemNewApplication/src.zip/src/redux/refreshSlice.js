import {createSlice} from '@reduxjs/toolkit';

export const refreshSlice = createSlice({
  name: 'refresh',
  initialState: {
    data: {
      dashboard: 0,
      postsites: 0,
      companies: 0,      
      reminders: 0,
      timeRequests: 0,
      shifts: 0,
      activities: 0,
      messages:0,
      postOrders:0,
      availabilities:0,
      licenses:0,
      tasks:0,
      siteTours:0,
      visitors:0,
    },
  },
  reducers: {
    setRefresh: (state, action) => {
      state.data[action.payload] = Math.floor(Math.random() * 100);
    },
  },
});

export const {setRefresh} = refreshSlice.actions;

// Get refresh
export const getRefresh = (state, keyName) => {
  return state.refresh?.data[keyName];
}

export default refreshSlice.reducer;
