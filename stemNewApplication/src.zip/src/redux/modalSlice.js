import { createSlice } from '@reduxjs/toolkit';

export const modalSlice = createSlice({
  name: 'modal',
  initialState: {
    location_service_modal: false,
    location_permission_modal: false,
    location_att_modal: false,
    tracking_msg_modal: false,
  },
  reducers: {
    setLocationPermissionModal: (state, action) => {
      state.location_permission_modal = action.payload
    },
    setLocationServiceModal: (state, action) => {
      state.location_service_modal = action.payload
    },
    setLocationAttModal: (state, action) => {
      state.location_att_modal = action.payload
    },
    setTrackingMsgModal: (state, action) => {
      state.tracking_msg_modal = action.payload
    }
  },
});

export const {
  setLocationPermissionModal,
  setLocationServiceModal,
  setLocationAttModal,
  setTrackingMsgModal
} = modalSlice.actions;

export const getLocationPermissionModal = state => state.modal?.location_permission_modal;
export const getLocationServiceModal = state => state.modal?.location_service_modal;
export const getLocationAttModal = state => state.modal?.location_att_modal;
export const getTrackingMsgModal = state => state.modal?.tracking_msg_modal;

export default modalSlice.reducer;
