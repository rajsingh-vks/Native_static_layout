import AsyncStorage from '@react-native-async-storage/async-storage';
import {createSlice} from '@reduxjs/toolkit';
import constants from '../utils/constants';

export const companySlice = createSlice({
  name: 'company',
  initialState: {
    data:{}
  },
  reducers: {
    setCompany: (state, action) => {
      state.data = {...state.data,...action.payload};
      AsyncStorage.setItem(constants.storageKeys.USER, JSON.stringify(state.data));
    },
   
  },
});

export const {setCompany} = companySlice.actions;

// Get company data from redux store
export const getCompany = (state) => {
  return state.company?.data
}

export default companySlice.reducer;
